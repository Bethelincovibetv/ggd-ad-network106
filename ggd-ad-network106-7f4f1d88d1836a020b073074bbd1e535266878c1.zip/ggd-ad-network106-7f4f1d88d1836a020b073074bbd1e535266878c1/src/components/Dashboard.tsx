import React, { useState, useEffect, useRef, lazy, Suspense } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Edit, Eye, BarChart3, Key, Copy, Code, LogOut, Upload, Loader2, ExternalLink, Crown, Wallet, MessageCircle, Shield, Briefcase, Users, Store, ArrowRight, Megaphone, Coins, Banknote } from "lucide-react";
import { toast } from "sonner";
import { supabase, SUPABASE_URL } from "@/integrations/supabase/client";
import { useFeatureToggles } from "@/hooks/useFeatureToggles";
import { ensureUserProfileAndReferral } from "@/services/referralService";
import { syncPendingTransfersForUser } from "@/services/transferService";
import { getCurrentUser } from "@/services/authService";

import MobileFooterMenu from "@/components/MobileFooterMenu";
import NotificationBell from "@/components/NotificationBell";
import BusinessGrowthDashboard from "@/components/BusinessGrowthDashboard";
import SlideCarousel from "@/components/SlideCarousel";
import TaskList from "@/components/TaskList";
import SupportPage from "@/components/SupportPage";
import SideNavMenu from "@/components/SideNavMenu";
import { SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import BusinessTaskCreator from "@/components/BusinessTaskCreator";
import SyndicateDashboard from "@/components/SyndicateDashboard";
import SyndicateWallet from "@/components/SyndicateWallet";
import UpgradePage from "@/components/UpgradePage";
import PremiumUpgrade from "@/components/PremiumUpgrade";
import CreditFunding from "@/components/CreditFunding";
import CreditTransfer from "@/components/CreditTransfer";
import WalletHub from "@/components/WalletHub";
import CreditRedeemAirtime from "@/components/CreditRedeemAirtime";
import SyndicateApplicationForm from "@/components/SyndicateApplicationForm";
import AboutPage from "@/components/AboutPage";
import SetupWizard from "@/components/SetupWizard";
import PromotionalContent from "@/components/PromotionalContent";
import PremiumRenewalBanner from "@/components/PremiumRenewalBanner";
const VixoraCreatorApp = lazy(() => import('@/vixora/VixoraCreatorApp'));

import AdDisplayPreview from "@/components/AdDisplayPreview";
import MarketingAppsMarketplace from "@/components/MarketingAppsMarketplace";
import BusinessStorefront from "@/components/BusinessStorefront";
import BusinessDirectory from "@/components/BusinessDirectory";
import UserGuide from "@/components/UserGuide";
import NotificationsPage from "@/components/NotificationsPage";
import ApiDocumentation from "@/components/ApiDocumentation";

import BusinessGuide from "@/components/BusinessGuide";
import SyndicateGuide from "@/components/SyndicateGuide";
import UserProfilePage from "@/components/UserProfilePage";
import LinkShortener from "@/components/LinkShortener";
import ReferralsPage from "@/components/ReferralsPage";
import CampaignAnalytics from "@/components/CampaignAnalytics";
import SyndicatePayouts from "@/components/SyndicatePayouts";
import GGDInbox from "@/components/GGDInbox";
import CampaignsHub from "@/components/CampaignsHub";
import CreateFab from "@/components/CreateFab";
import ExtendAdvertModal from "@/components/ExtendAdvertModal";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart2, Clock, RefreshCw } from "lucide-react";

import { usePremiumSettings } from "@/hooks/usePremiumSettings";
import ggdLogo from '@/assets/ggd-logo.png';
import GlobalSearchBar from "@/components/GlobalSearchBar";
import HomeDashboard from "@/components/HomeDashboard";
import BusinessProfileWizard from "@/components/BusinessProfileWizard";
import CommunityFeed from "@/components/CommunityFeed";
import AdminEmailStudio from "@/components/admin/AdminEmailStudio";
import ContactGainHub from "@/components/ContactGainHub";
import { FavoritesQuickButton } from "@/components/favorites/FavoritesQuickButton";
import { FavoritesPage } from "@/components/favorites/FavoritesPage";
import { HeaderWallets } from "@/components/wallet/HeaderWallets";
import { GuidedTourModal, hasSeenWalkthrough } from "@/components/GuidedTourModal";
import { useScrollNavVisibility } from "@/hooks/useScrollNavVisibility";

interface Ad {
  id: string;
  title: string;
  description: string;
  image_url: string | null;
  target_url: string;
  is_active: boolean;
  impressions: number;
  clicks: number;
  created_at: string;
  expires_at: string | null;
}

interface ApiKey {
  id: string;
  api_key: string;
  name: string;
  domain: string | null;
  is_active: boolean;
  requests_count: number;
  created_at: string;
}

interface DashboardProps {
  onLogout: () => void;
  userEmail: string;
}

const AvatarMenuButton = ({ avatarUrl, displayName, email }: { avatarUrl: string | null; displayName: string; email: string }) => {
  const { toggleSidebar } = useSidebar();
  const initial = (displayName || email || 'U').trim().charAt(0).toUpperCase();
  return (
    <button
      onClick={toggleSidebar}
      aria-label="Open menu"
      className="rounded-full ring-2 ring-orange-500/30 hover:ring-orange-500 transition-all"
    >
      <Avatar className="h-8 w-8">
        {avatarUrl ? <AvatarImage src={avatarUrl} alt={displayName || 'User'} /> : null}
        <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-600 text-white text-xs font-bold">
          {initial}
        </AvatarFallback>
      </Avatar>
    </button>
  );
};

const Dashboard = ({ onLogout, userEmail }: DashboardProps) => {
  const navigate = useNavigate();
  const [ads, setAds] = useState<Ad[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingAd, setEditingAd] = useState<Ad | null>(null);
  const [republishFrom, setRepublishFrom] = useState<{ approved: boolean } | null>(null);
  const [loading, setLoading] = useState(true);
  const [newAd, setNewAd] = useState({ title: '', description: '', image_url: '', target_url: '', is_active: true, duration: '7' });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyDomain, setNewKeyDomain] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [currentTier, setCurrentTier] = useState<number>(0);
  const [premiumExpiresAt, setPremiumExpiresAt] = useState<string | null>(null);
  const [isBusiness, setIsBusiness] = useState(false);
  const [isSyndicate, setIsSyndicate] = useState(false);
  const [credits, setCredits] = useState(0);
  const [walletBalance, setWalletBalance] = useState(0);
  const [adCostCredits, setAdCostCredits] = useState(5);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      const tabParam = urlParams.get('tab');
      if (tabParam) return tabParam === 'ads-create' ? 'campaigns' : tabParam;
      const saved = localStorage.getItem('ggd_active_tab');
      if (saved) return saved;
    }
    return 'ads';
  });
  const [adsFilter, setAdsFilter] = useState<'active' | 'expired' | 'inactive'>('active');
  const [analyticsAdId, setAnalyticsAdId] = useState<string | null>(null);
  const [extendingAd, setExtendingAd] = useState<Ad | null>(null);
  
  // YouTube-like scroll behavior: header and mobile footer hide on scroll down, reveal on scroll up
  const { isVisible: isNavVisible, showNav } = useScrollNavVisibility({ resetOnDeps: [activeTab] });
  const scrollToBannerForm = () => {
    setTimeout(() => {
      document.getElementById('banner-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  };
  const startCreateAd = () => { setIsCreating(true); scrollToBannerForm(); };
  const handleTabChange = (tab: string) => {
    if (tab === 'ads-create') {
      setActiveTab('campaigns');
      if (typeof window !== 'undefined') {
        try {
          localStorage.setItem('ggd_active_tab', 'campaigns');
          const url = new URL(window.location.href);
          url.searchParams.set('tab', 'campaigns');
          window.history.replaceState(null, '', url.toString());
        } catch {}
      }
      startCreateAd();
      return;
    }
    setActiveTab(tab);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('ggd_active_tab', tab);
        const url = new URL(window.location.href);
        url.searchParams.set('tab', tab);
        window.history.replaceState(null, '', url.toString());
      } catch {}
    }
  };
  const { isEnabled } = useFeatureToggles();
  const [isTourOpen, setIsTourOpen] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  const [profileSetupComplete, setProfileSetupComplete] = useState<boolean | null>(null);
  const [whatsappGroupLink, setWhatsappGroupLink] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState<string>('');
  const premium = usePremiumSettings();
  // Premium subscription is considered active if not expired
  const subscriptionActive = !premiumExpiresAt || new Date(premiumExpiresAt) > new Date();
  const effectiveTier = subscriptionActive ? currentTier : 0;
  const maxAdDays = (premium.tiers.find(t => t.tier === effectiveTier)?.days) || premium.freeAdDays;
  // Effective premium (paid): master toggle off, admin, or active paid tier (1-4)
  const effectivePremium = !premium.enabled || isAdmin || (subscriptionActive && currentTier >= 1);

  const supabaseUrl = SUPABASE_URL;
  const dailyLoginCheckedUsersRef = useRef<Set<string>>(new Set());

  useEffect(() => { initDashboard(); }, []);

  // Real-time synchronization for task_wallets (₦ cash) and profiles (credits)
  useEffect(() => {
    let subChannel: any = null;
    let isMounted = true;
    (async () => {
      try {
        const user = await getCurrentUser();
        if (!user || !isMounted) return;
        subChannel = supabase
          .channel(`dashboard-wallet-sync-${user.id}`)
          .on(
            'postgres_changes',
            { event: '*', schema: 'public', table: 'task_wallets', filter: `user_id=eq.${user.id}` },
            (payload: any) => {
              if (payload.new && typeof payload.new.balance === 'number' && isMounted) {
                setWalletBalance(payload.new.balance);
              }
            }
          )
          .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `user_id=eq.${user.id}` },
            (payload: any) => {
              if (payload.new && typeof payload.new.credits === 'number' && isMounted) {
                setCredits(payload.new.credits);
              }
            }
          )
          .subscribe();
      } catch (err) {
        console.warn("Real-time channel init skipped:", err);
      }
    })();

    return () => {
      isMounted = false;
      if (subChannel) {
        try {
          supabase.removeChannel(subChannel);
        } catch {}
      }
    };
  }, []);

  const [searchParams] = useSearchParams();

  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam) {
      handleTabChange(tabParam);
    }
  }, [searchParams]);

  useEffect(() => {
    const handler = (e: any) => { if (e?.detail) handleTabChange(e.detail); };
    window.addEventListener('ggd-nav', handler);
    return () => window.removeEventListener('ggd-nav', handler);
  }, []);

  useEffect(() => {
    const tourHandler = () => setIsTourOpen(true);
    window.addEventListener('ggd-launch-tour', tourHandler);

    // Prompt first-time visitors after short pause
    if (typeof window !== 'undefined') {
      const seen = hasSeenWalkthrough();
      if (!seen) {
        const timer = setTimeout(() => {
          setIsTourOpen(true);
        }, 1600);
        return () => {
          window.removeEventListener('ggd-launch-tour', tourHandler);
          clearTimeout(timer);
        };
      }
    }

    return () => window.removeEventListener('ggd-launch-tour', tourHandler);
  }, []);

  const initDashboard = async () => {
    try {
      const user = await getCurrentUser();
      if (!user) {
        setLoading(false);
        return;
      }
      setCurrentUserId(user.id);
      setDisplayName(user.user_metadata?.display_name || user.email?.split('@')[0] || 'GGD Member');

      // Securely ensure task wallet exists & load latest balance
      try {
        let { data: tw } = await supabase.from('task_wallets').select('*').eq('user_id', user.id).maybeSingle();
        if (!tw) {
          await supabase.from('task_wallets').insert({ user_id: user.id, balance: 0, total_funded: 0 } as any);
          const { data: createdTw } = await supabase.from('task_wallets').select('*').eq('user_id', user.id).maybeSingle();
          tw = createdTw;
        }
        setWalletBalance(Number(tw?.balance || 0));
      } catch (e) {
        console.warn('Dashboard task wallet sync:', e);
      }

      try {
        const [rolesRes, synProfRes, synAppRes] = await Promise.all([
          supabase.from('user_roles').select('role, premium_tier, premium_expires_at').eq('user_id', user.id),
          supabase.from('syndicate_profiles').select('id, is_suspended').eq('user_id', user.id).maybeSingle(),
          supabase.from('syndicate_applications').select('status').eq('user_id', user.id).maybeSingle(),
        ]);

        const userRoles = (rolesRes.data || []).map(r => r.role);
        setIsAdmin(userRoles.includes('admin') || user.email === 'goodgiftdigital@gmail.com' || user.email === 'accessa787@gmail.com');
        setIsPremium(userRoles.includes('premium'));
        const premRow: any = (rolesRes.data || []).find((r: any) => r.role === 'premium');
        if (premRow) {
          setCurrentTier(premRow.premium_tier ?? 0);
          setPremiumExpiresAt(premRow.premium_expires_at ?? null);
        }
        setIsBusiness(true);
        const hasSyndicateAccess = userRoles.includes('syndicate') || 
          Boolean(synProfRes.data && !synProfRes.data.is_suspended) ||
          synAppRes.data?.status === 'approved';
        setIsSyndicate(hasSyndicateAccess);
      } catch (err) {
        console.warn('Roles fetch non-blocking:', err);
      }

      // Automatically sync any pending incoming transfers from credit_transfers
      try {
        const syncResult = await syncPendingTransfersForUser(user.id);
        if (syncResult.credited && syncResult.totalAdded > 0) {
          toast.success(`🎉 +${syncResult.totalAdded} credits received from transfer!`);
        }
      } catch {
        // Non-blocking sync
      }

      let profile: any = null;
      try {
        const { data: p } = await (supabase.from('profiles')
          .select('credits, last_credit_date, referral_code, avatar_url, display_name, business_name, business_phone, business_slug, profile_setup_complete, login_bonus_credits, syndicate_status')
          .eq('user_id', user.id)
          .maybeSingle() as any);
        profile = p;
      } catch {}

      if (!profile) {
        try {
          const ensured = await ensureUserProfileAndReferral(user);
          profile = (ensured as any)?.profile || ensured;
        } catch {}
      }
      if (profile?.syndicate_status === 'active') {
        setIsSyndicate(true);
      }

      // Check if user already has an active business storefront or ads
      let hasExistingBusinessProfile = false;
      try {
        const { data: bp } = await (supabase.from('business_profiles') as any)
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();
        if (bp?.id) hasExistingBusinessProfile = true;
      } catch {}

      let hasExistingAds = false;
      try {
        const { count } = await supabase
          .from('ads')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id);
        if (count && count > 0) hasExistingAds = true;
      } catch {}

      const isAlreadyActivated = 
        Boolean((profile as any)?.profile_setup_complete) ||
        Boolean((profile as any)?.business_name && (profile as any).business_name.trim().length > 0) ||
        Boolean((profile as any)?.business_phone && (profile as any).business_phone.trim().length > 0) ||
        Boolean((profile as any)?.business_slug && (profile as any).business_slug.trim().length > 0) ||
        Boolean((profile as any)?.syndicate_status === 'active') ||
        hasExistingBusinessProfile ||
        hasExistingAds ||
        localStorage.getItem('ggd_wizard_seen') === 'true' ||
        localStorage.getItem(`ggd_wizard_seen_${user.id}`) === 'true' ||
        localStorage.getItem('ggd_profile_setup_complete') === 'true' ||
        localStorage.getItem(`ggd_profile_activated_${user.id}`) === 'true';

      setProfileSetupComplete(isAlreadyActivated);

      try {
        const { data: settings } = await supabase.from('app_settings').select('*');
        const loginCreditsAmount = parseInt(settings?.find(s => s.key === 'login_credits')?.value || '10');
        const adCost = parseInt(settings?.find(s => s.key === 'ad_cost_credits')?.value || '5');
        setAdCostCredits(adCost);
        const waGroup = settings?.find(s => s.key === 'whatsapp_group_link')?.value || '';
        setWhatsappGroupLink(waGroup);
      } catch {}

      setShowWizard(false);

      if (profile) {
        setAvatarUrl(profile.avatar_url || null);
        setDisplayName(profile.display_name || profile.business_name || user.email || '');
        setCredits(profile.credits || 10);
      }

      // Check and display activity notifications upon user entry
      if (typeof window !== 'undefined' && !sessionStorage.getItem('ggd_entry_activities_checked')) {
        sessionStorage.setItem('ggd_entry_activities_checked', 'true');
        setTimeout(async () => {
          try {
            const [notifRes, tasksRes] = await Promise.all([
              supabase.from('notifications').select('id, title, message').eq('user_id', user.id).eq('is_read', false).limit(3),
              (supabase.from as any)('credit_tasks').select('id', { count: 'exact', head: true }).eq('is_active', true),
            ]);
            const unreadCount = notifRes.data?.length || 0;
            const taskCount = tasksRes.count || 0;
            if (unreadCount > 0) {
              const latest = notifRes.data![0];
              toast(`🔔 ${latest.title || 'New Activity Notification'}`, {
                description: latest.message || `You have ${unreadCount} unread update${unreadCount > 1 ? 's' : ''}`,
                action: {
                  label: 'View',
                  onClick: () => handleTabChange('notifications'),
                },
              });
            } else if (taskCount > 0) {
              toast.info(`⚡ ${taskCount} active credit tasks are ready to earn rewards today!`, {
                action: {
                  label: 'View Tasks',
                  onClick: () => handleTabChange('tasks'),
                },
              });
            }
          } catch (actErr) {
            console.warn('Dashboard entry activity check:', actErr);
          }
        }, 1200);
      }

      await fetchAds();
      await fetchApiKeys();
    } catch (criticalErr) {
      console.warn('initDashboard non-blocking error handled:', criticalErr);
    } finally {
      setLoading(false);
    }
  };

  const fetchAds = async () => {
    try {
      const user = await getCurrentUser();
      if (!user) return;
      const { data } = await supabase.from('ads').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
      setAds(data || []);
    } catch (e) {
      console.warn('fetchAds non-blocking:', e);
    } finally {
      setLoading(false);
    }
  };

  const fetchApiKeys = async () => {
    try {
      const { data } = await supabase.from('api_keys').select('*').order('created_at', { ascending: false });
      setApiKeys(data || []);
    } catch (e) {
      console.warn('fetchApiKeys non-blocking:', e);
    }
  };

  const uploadAdImage = async (file: File): Promise<string | null> => {
    try {
      setUploadingImage(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const ext = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('ad-images').upload(fileName, file, { upsert: true });
      if (error) { toast.error("Failed to upload image"); return null; }
      const { data: { publicUrl } } = supabase.storage.from('ad-images').getPublicUrl(fileName);
      return publicUrl;
    } catch {
      toast.error("Image upload failed");
      return null;
    } finally {
      setUploadingImage(false);
    }
  };

  const handleNewAdImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadAdImage(file);
    if (url) setNewAd(prev => ({ ...prev, image_url: url }));
  };

  const handleEditAdImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadAdImage(file);
    if (url && editingAd) setEditingAd(prev => prev ? { ...prev, image_url: url } : null);
  };

  const createAd = async () => {
    if (!newAd.title.trim() || !newAd.target_url.trim()) { toast.error("Title and target URL are required"); return; }
    const duration = parseInt(newAd.duration);
    if (duration > maxAdDays && !isAdmin) {
      toast.error(`Your plan allows ads up to ${maxAdDays} days. Upgrade for longer campaigns.`);
      setActiveTab('premium');
      return;
    }
    if (!isAdmin && credits < adCostCredits) { toast.error(`Not enough credits. Need ${adCostCredits}, have ${credits}`); return; }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + duration);

    // Republished campaigns go live immediately once paid — they were
    // already reviewed during their first run.
    const goLiveNow = !!republishFrom?.approved;

    const { error } = await supabase.from('ads').insert({
      user_id: user.id, title: newAd.title, description: newAd.description || '',
      image_url: newAd.image_url || null, target_url: newAd.target_url,
      is_active: isAdmin || goLiveNow, approved: isAdmin || goLiveNow,
      expires_at: expiresAt.toISOString(),
    });
    if (error) { toast.error("Failed to create ad"); return; }
    if (!isAdmin) {
      const newCredits = credits - adCostCredits;
      await supabase.from('profiles').update({ credits: newCredits }).eq('user_id', user.id);
      setCredits(newCredits);
    }
    toast.success(goLiveNow ? "Campaign republished and live!" : "Ad created!");
    setNewAd({ title: '', description: '', image_url: '', target_url: '', is_active: true, duration: '7' });
    setRepublishFrom(null);
    setIsCreating(false);
    fetchAds();
  };

  const updateAd = async () => {
    if (!editingAd) return;
    const { error } = await supabase.from('ads').update({
      title: editingAd.title, description: editingAd.description, image_url: editingAd.image_url,
      target_url: editingAd.target_url, is_active: editingAd.is_active,
    }).eq('id', editingAd.id);
    if (error) { toast.error("Failed to update ad"); return; }
    toast.success("Ad updated!");
    setEditingAd(null);
    fetchAds();
  };

  const deleteAd = async (id: string) => {
    if (!confirm("Delete this ad?")) return;
    await supabase.from('ads').delete().eq('id', id);
    toast.success("Ad deleted!");
    fetchAds();
  };

  const republishAd = (ad: Ad) => {
    setEditingAd(null);
    setRepublishFrom({ approved: (ad as any).approved !== false });
    setNewAd({
      title: ad.title,
      description: ad.description || '',
      image_url: ad.image_url || '',
      target_url: ad.target_url,
      is_active: true,
      duration: String(Math.min(7, maxAdDays)),
    });
    setIsCreating(true);
    toast.info("Details loaded — pick a new duration and pay; the campaign goes live immediately.");
    scrollToBannerForm();
  };

  const convertAdToTask = async (ad: Ad) => {
    const { error } = await supabase.from('tasks').insert({
      title: `Share: ${ad.title}`,
      description: ad.description || `Share this ad and earn credits!`,
      reward_credits: 5,
      task_type: 'share',
      share_url: ad.target_url,
    });
    if (error) { toast.error("Failed to convert ad to task"); return; }
    toast.success("Ad converted to task! Users can now earn credits by sharing it.");
  };

  const createApiKey = async () => {
    if (!isPremium && !isAdmin) { toast.error("Upgrade to Premium to create API keys"); return; }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from('api_keys').insert({ user_id: user.id, name: newKeyName || 'Default', domain: newKeyDomain || null });
    if (error) { toast.error("Failed to create API key"); return; }
    toast.success("API key created!");
    setNewKeyName('');
    setNewKeyDomain('');
    fetchApiKeys();
  };

  const deleteApiKey = async (id: string) => {
    await supabase.from('api_keys').delete().eq('id', id);
    toast.success("API key deleted!");
    fetchApiKeys();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied!");
  };

  const getEmbedCode = (apiKey: string) => {
    return `<!-- GGD Ad Network -->
<div id="ggd-ad-container"></div>
<script>
(function() {
  var API_KEY = "${apiKey}";
  var API_URL = "${supabaseUrl}/functions/v1/serve-ads";
  var container = document.getElementById("ggd-ad-container");
  var ads = [], currentIndex = 0;
  function fetchAds() {
    fetch(API_URL + "?api_key=" + API_KEY)
      .then(function(r) { return r.json(); })
      .then(function(data) { if (data.ads && data.ads.length > 0) { ads = data.ads; displayAd(); } })
      .catch(function(e) { console.error("GGD:", e); });
  }
  function trackEvent(adId, type) {
    fetch(API_URL, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ad_id: adId, event_type: type, api_key: API_KEY, referrer: window.location.href })
    }).catch(function() {});
  }
  function displayAd() {
    if (!ads.length) return;
    var ad = ads[currentIndex];
    trackEvent(ad.id, "impression");
    var html = '<div style="max-width:100%;margin:10px auto;border-radius:12px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,0.12);font-family:system-ui,sans-serif;cursor:pointer;background:#fff" onclick="window.open(\\''+ad.target_url+'\\',\\'_blank\\')">';
    if (ad.image_url) html += '<img loading="lazy" src="'+ad.image_url+'" style="width:100%;display:block" alt="'+ad.title+'">';
    if (ad.title) {
      html += '<div style="padding:10px 14px"><h3 style="margin:0;font-size:15px;font-weight:700;color:#1a1a1a">'+ad.title+'</h3>';
      if (ad.description) html += '<p style="margin:4px 0 0;font-size:12px;color:#666">'+ad.description+'</p>';
      html += '</div>';
    }
    html += '<div style="background:#f9f9f9;padding:3px;text-align:center;font-size:9px;color:#bbb">Ad by GGD AD NETWORK</div></div>';
    container.innerHTML = html;
    currentIndex = (currentIndex + 1) % ads.length;
  }
  fetchAds();
  setInterval(function() { displayAd(); }, 8000);
})();
</script>`;
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  const handleUpgraded = () => { initDashboard(); };

  const isExpired = (ad: Ad) => ad.expires_at ? new Date(ad.expires_at) < new Date() : false;
  const daysLeft = (ad: Ad) => {
    if (!ad.expires_at) return null;
    const diff = new Date(ad.expires_at).getTime() - Date.now();
    return diff <= 0 ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  if (loading) return <div className="flex items-center justify-center min-h-[400px]"><Loader2 className="h-8 w-8 animate-spin text-orange-500" /></div>;

  // MANDATORY: business profile setup must be completed before any other UI is shown.
  if (profileSetupComplete === false) {
    return (
      <BusinessProfileWizard
        onComplete={() => {
          setProfileSetupComplete(true);
          setShowWizard(false);
          try {
            localStorage.setItem('ggd_wizard_seen', 'true');
            localStorage.setItem('ggd_profile_setup_complete', 'true');
          } catch {}
          initDashboard();
        }}
      />
    );
  }

  if (showWizard && profileSetupComplete !== true) {
    // Allow admin to switch off the wizard
    if (!isEnabled('setup_wizard')) {
      // Skip wizard entirely
    } else {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50 pb-20">
        <header className="bg-card/80 backdrop-blur border-b sticky top-0 z-50">
          <div className="container mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <img loading="lazy" src={ggdLogo} alt="GGD" className="h-7 w-7 rounded-lg" />
              <h1 className="text-lg font-black bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">GGD Ad Network</h1>
            </div>
          </div>
        </header>
        <div className="container mx-auto px-4 py-4">
          <SetupWizard onComplete={() => { setShowWizard(false); localStorage.setItem('ggd_wizard_seen', 'true'); }} onNavigate={setActiveTab} />
        </div>
      </div>
    );
    }
  }

  const renderContent = () => {
    const disabled = <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;
    switch (activeTab) {
      case 'ads':
        if (analyticsAdId) {
          return <CampaignAnalytics adId={analyticsAdId} onBack={() => setAnalyticsAdId(null)} />;
        }
        return (
          <div className="space-y-4">
            {/* Slider directly under the search bar */}
            {isEnabled('slides') && <SlideCarousel />}

            <HomeDashboard credits={credits} walletBalance={walletBalance} isAdmin={isAdmin} onNavigate={handleTabChange} />

            {/* Ad Display Preview */}
            {isEnabled('ads') && <AdDisplayPreview />}
          </div>
        );

      case 'advertising':
      case 'campaigns':
        if (!isEnabled('nav_campaigns') && !isEnabled('ads')) {
          return <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;
        }
        if (analyticsAdId) {
          return <CampaignAnalytics adId={analyticsAdId} onBack={() => setAnalyticsAdId(null)} />;
        }
        return (
          <div className="space-y-4">
            <CampaignsHub onNavigate={handleTabChange} />

            {isEnabled('ads') && (<>
            {/* My Campaigns - compact pro-style */}
            <div className="flex justify-between items-center pt-1">
              <h2 className="text-base font-black text-foreground">My Campaigns</h2>
            </div>

            {/* Category filter tabs — default Active */}
            {ads.length > 0 && (
              <Tabs value={adsFilter} onValueChange={v => setAdsFilter(v as any)}>
                <TabsList className="w-full grid grid-cols-3">
                  <TabsTrigger value="active" className="text-xs">
                    Active ({ads.filter(a => a.is_active && !isExpired(a)).length})
                  </TabsTrigger>
                  <TabsTrigger value="expired" className="text-xs">
                    Expired ({ads.filter(a => isExpired(a)).length})
                  </TabsTrigger>
                  <TabsTrigger value="inactive" className="text-xs">
                    Inactive ({ads.filter(a => !a.is_active && !isExpired(a)).length})
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            )}

            {isCreating && (
              <Card id="banner-form" className="border-orange-200">
                <CardContent className="p-3 -mb-2">
                  <div className="rounded-lg bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 p-2.5 text-xs text-orange-800">
                    <strong>Banner ad cost:</strong> {isAdmin ? 'Free for admins' : `${adCostCredits} credits per day`} · You'll be charged based on duration selected.
                  </div>
                </CardContent>
              </Card>
            )}
            {isCreating && (
              <Card className="border-orange-200">
                <CardContent className="p-4 space-y-3">
                  <Input placeholder="Ad Title *" value={newAd.title} onChange={e => setNewAd({ ...newAd, title: e.target.value })} />
                  <Textarea placeholder="Description (optional)" value={newAd.description} onChange={e => setNewAd({ ...newAd, description: e.target.value })} rows={2} />
                  <Input placeholder="Target URL * (https://...)" value={newAd.target_url} onChange={e => setNewAd({ ...newAd, target_url: e.target.value })} />
                  {(isEnabled('ad_duration_settings') || isAdmin) && (
                  <div>
                    <Label className="text-xs font-medium">Duration</Label>
                    <Select value={newAd.duration} onValueChange={v => setNewAd({ ...newAd, duration: v })}>
                      <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Day</SelectItem>
                        <SelectItem value="3">3 Days</SelectItem>
                        <SelectItem value="7">7 Days</SelectItem>
                        {(isPremium || isAdmin) && <SelectItem value="14">14 Days</SelectItem>}
                        {(isPremium || isAdmin) && <SelectItem value="30">30 Days</SelectItem>}
                      </SelectContent>
                    </Select>
                  </div>
                  )}
                  <div className="space-y-2">
                    <Label className="text-xs font-medium">Banner Image</Label>
                    <input type="file" id="newAdImageUpload" accept="image/*" onChange={handleNewAdImageUpload} className="hidden" />
                    <Button variant="outline" className="w-full h-9 text-xs" disabled={uploadingImage}
                      onClick={() => document.getElementById('newAdImageUpload')?.click()}>
                      {uploadingImage ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                      {uploadingImage ? 'Uploading...' : 'Upload Banner'}
                    </Button>
                    {newAd.image_url && (
                      <div className="relative">
                        <img loading="lazy" src={newAd.image_url} alt="Banner preview" className="w-full rounded-lg" />
                        <Button size="icon" variant="destructive" className="absolute top-1 right-1 h-6 w-6" onClick={() => setNewAd({ ...newAd, image_url: '' })}>
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={newAd.is_active} onCheckedChange={c => setNewAd({ ...newAd, is_active: c })} />
                    <Label className="text-xs">Active</Label>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={createAd} className="flex-1 bg-gradient-to-r from-orange-500 to-red-600 text-white text-xs">
                      Create ({isAdmin ? 'Free' : `${adCostCredits} credits`})
                    </Button>
                    <Button onClick={() => setIsCreating(false)} variant="outline" className="flex-1 text-xs">Cancel</Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {editingAd && (
              <Card className="border-blue-200">
                <CardHeader className="pb-2"><CardTitle className="text-sm">Edit Ad</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  <Input value={editingAd.title} onChange={e => setEditingAd({ ...editingAd, title: e.target.value })} />
                  <Textarea placeholder="Description" value={editingAd.description} onChange={e => setEditingAd({ ...editingAd, description: e.target.value })} rows={2} />
                  <Input value={editingAd.target_url} onChange={e => setEditingAd({ ...editingAd, target_url: e.target.value })} />
                  <input type="file" id="editAdImageUpload" accept="image/*" onChange={handleEditAdImageUpload} className="hidden" />
                  <Button variant="outline" className="w-full h-9 text-xs" disabled={uploadingImage}
                    onClick={() => document.getElementById('editAdImageUpload')?.click()}>
                    {uploadingImage ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                    {editingAd.image_url ? 'Change Banner' : 'Upload Banner'}
                  </Button>
                  {editingAd.image_url && (
                    <div className="relative">
                      <img loading="lazy" src={editingAd.image_url} alt="Banner" className="w-full rounded-lg" />
                      <Button size="icon" variant="destructive" className="absolute top-1 right-1 h-6 w-6" onClick={() => setEditingAd({ ...editingAd, image_url: null })}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Switch checked={editingAd.is_active} onCheckedChange={c => setEditingAd({ ...editingAd, is_active: c })} />
                    <Label className="text-xs">Active</Label>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={updateAd} className="flex-1 text-xs">Update</Button>
                    <Button onClick={() => setEditingAd(null)} variant="outline" className="flex-1 text-xs">Cancel</Button>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="space-y-2.5">
              {ads
                .filter(ad => {
                  const exp = isExpired(ad);
                  if (adsFilter === 'expired') return exp;
                  if (adsFilter === 'active') return ad.is_active && !exp;
                  return !ad.is_active && !exp;
                })
                .map(ad => {
                const expired = isExpired(ad);
                const remaining = daysLeft(ad);
                const ctr = ad.impressions > 0 ? ((ad.clicks / ad.impressions) * 100).toFixed(1) : '0.0';
                return (
                  <Card key={ad.id} className={`overflow-hidden border rounded-2xl transition-all hover:shadow-md ${expired ? 'opacity-60 border-destructive/30' : 'border-border/50'}`}>
                    <CardContent className="p-2.5">
                      <div className="flex gap-3 items-center">
                        <div className="h-14 w-14 rounded-xl overflow-hidden bg-gradient-to-br from-orange-100 to-yellow-100 flex-shrink-0 flex items-center justify-center">
                          {ad.image_url ? (
                            <img loading="lazy" src={ad.image_url} alt={ad.title} className="h-full w-full object-cover" />
                          ) : (
                            <Megaphone className="h-6 w-6 text-orange-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <h3 className="font-bold text-[13px] text-foreground truncate">{ad.title}</h3>
                            {expired ? (
                              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-red-500/15 text-red-500 shrink-0">EXPIRED</span>
                            ) : ad.is_active ? (
                              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-green-500/15 text-green-600 shrink-0">LIVE</span>
                            ) : (
                              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground shrink-0">OFF</span>
                            )}
                          </div>
                          <p className="text-[10px] text-muted-foreground truncate">{ad.target_url}</p>
                        </div>
                        <div className="flex flex-col gap-0.5 flex-shrink-0">
                          <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full" onClick={() => setEditingAd(ad)}><Edit className="h-3 w-3" /></Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 rounded-full text-destructive" onClick={() => deleteAd(ad.id)}><Trash2 className="h-3 w-3" /></Button>
                        </div>
                      </div>

                      <div className="mt-2.5 pt-2.5 border-t border-border/30 flex items-center justify-between gap-2">
                        <div className="flex gap-3 text-[10px] text-muted-foreground">
                          <span><b className="text-foreground">{ad.impressions}</b> views</span>
                          <span><b className="text-blue-500">{ad.clicks}</b> clicks</span>
                          <span><b className="text-purple-500">{ctr}%</b> CTR</span>
                          {remaining !== null && <span><b className="text-orange-500">{remaining}d</b> left</span>}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-[10px] rounded-full border-orange-500/40 text-orange-600 hover:bg-orange-500/10"
                          onClick={() => setAnalyticsAdId(ad.id)}
                        >
                          <BarChart2 className="h-3 w-3 mr-1" /> Analytics
                        </Button>
                      </div>

                      {!premium.autoConvertAds && isEnabled('tasks') && (
                        <>
                        <Button size="sm" variant="ghost" className="w-full mt-2 text-[11px] h-7 text-orange-500 hover:bg-orange-500/10 rounded-xl"
                          onClick={() => convertAdToTask(ad)}>
                          <ArrowRight className="h-3 w-3 mr-1" />Convert to Earn-Task
                        </Button>
                        </>
                      )}

                      {expired && (
                        <Button size="sm" className="w-full mt-2 text-[12px] h-9 rounded-xl bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold shadow-sm"
                          onClick={() => setExtendingAd(ad)}>
                          <Clock className="h-3.5 w-3.5 mr-1.5" />Extend Advert
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
              {ads.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p className="text-sm">No ads yet. Create your first campaign!</p>
                </div>
              )}
            </div>
            </>)}
          </div>
        );

      case 'tasks':
        return <TaskList onCreditsUpdate={setCredits} credits={credits} onNavigate={handleTabChange} />;

      case 'redeem':
      case 'redeem-airtime':
      case 'airtime':
        return (
          <CreditRedeemAirtime
            currentCredits={credits}
            onCreditsUpdated={(c) => setCredits(c)}
            onNavigate={handleTabChange}
          />
        );

      case 'fund-credits':
      case 'transfer':
      case 'task-wallet':
      case 'wallet':
        return (
          <WalletHub
            credits={credits}
            onCreditsUpdate={setCredits}
            onWalletUpdate={(bal) => setWalletBalance(bal)}
            isPremium={isPremium}
            initialTab={activeTab === 'transfer' ? 'transfer' : (activeTab === 'fund-credits' ? 'buy' : 'task-wallet')}
          />
        );

      case 'premium':
        return isEnabled('premium_upgrade') ? <PremiumUpgrade onUpgraded={handleUpgraded} credits={credits} isPremium={isPremium} /> : <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;

      case 'marketplace':
        return isEnabled('marketing_apps') && isEnabled('marketplace') ? <MarketingAppsMarketplace /> : disabled;

      case 'share-earn':
      case 'promo':
      case 'referrals':
        return isEnabled('promotional_content') || isEnabled('referral_system')
          ? <PromotionalContent initialTab={activeTab === 'promo' ? 'flyers' : (activeTab === 'referrals' ? 'referrals' : 'referrals')} />
          : <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;

      case 'guide':
      case 'user-guide':
      case 'business-guide':
      case 'syndicate-guide':
      case 'quick_guide':
      case 'guide_step_completion':
      case 'step_1':
      case 'step_2':
      case 'step_3':
      case 'step_4':
      case 'step_5':
      case 'step_6':
      case 'step_7':
      case 'step_8':
      case 'step_9':
      case 'step_10':
        return <UserGuide />;

      case 'notifications':
      case 'all-notifications':
      case 'notification':
        return <NotificationsPage onNavigate={handleTabChange} />;


      case 'wizard':
        return isEnabled('setup_wizard')
          ? <SetupWizard onComplete={() => setActiveTab('ads')} onNavigate={(tab) => { setActiveTab(tab); }} />
          : disabled;

      case 'about':
        return isEnabled('nav_about') ? <AboutPage /> : disabled;

      case 'business-tasks':
        return isEnabled('business_tasks') ? <BusinessTaskCreator /> : <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;

      case 'profile':
        return isEnabled('nav_profile') || isAdmin ? <UserProfilePage /> : disabled;

      case 'smart-links':
        return isEnabled('link_shortener') ? <LinkShortener /> : <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;

      case 'business':
      case 'my-business':
      case 'storefront':
      case 'business-storefront':
      case 'business-site':
      case 'business-website':
      case 'store':
      case 'biz':
      case 'my-biz':
      case 'business-hub':
        return (isEnabled('nav_my_business') || isEnabled('business_sites') || isBusiness || isAdmin) 
          ? <BusinessStorefront onNavigate={handleTabChange} /> 
          : disabled;

      case 'inbox':
        return isEnabled('p2p_chat') ? <GGDInbox /> : <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;

      case 'vixora':
      case 'vixora-creator':
      case 'creator':
      case 'vixora-studio':
        if (!isEnabled('vixora_ai') && !isAdmin) {
          return disabled;
        }
        return (
          <Suspense fallback={
            <div className="flex flex-col items-center justify-center p-12 space-y-3">
              <div className="animate-spin h-9 w-9 border-4 border-orange-500 border-t-transparent rounded-full" />
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Loading Vixora AI Creator Studio...</p>
            </div>
          }>
            <VixoraCreatorApp
              embedded={true}
              onBackToDashboard={() => setActiveTab('ads')}
              userEmail={userEmail}
            />
          </Suspense>
        );

      case 'favorites':
      case 'saved':
      case 'wishlist':
      case 'bookmarks':
        return <FavoritesPage onNavigateTab={handleTabChange} />;

      case 'directory':
        return isEnabled('directory') ? <BusinessDirectory isBusiness={isBusiness} /> : disabled;

      case 'syndicate':
        if (!isEnabled('syndicate')) return <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;
        if (!isSyndicate && !isAdmin) return <SyndicateApplicationForm onApplied={() => initDashboard()} />;
        return <SyndicateDashboard onNavigate={handleTabChange} />;

      case 'syndicate-join':
        return isEnabled('syndicate') ? <SyndicateApplicationForm onApplied={() => initDashboard()} /> : disabled;

      case 'syndicate-wallet':
        if (!isEnabled('syndicate')) return <div className="text-center py-8 text-muted-foreground">This feature is currently disabled.</div>;
        if (!isSyndicate && !isAdmin) return <SyndicateApplicationForm onApplied={() => initDashboard()} />;
        return <SyndicateWallet />;

      case 'upgrade':
        return isEnabled('premium_upgrade') || isEnabled('co_owner_upgrade')
          ? <UpgradePage onUpgraded={handleUpgraded} credits={credits} onNavigate={setActiveTab} />
          : disabled;

      case 'api-keys':
        return !isEnabled('api_keys') ? disabled : (
          <div className="space-y-4">
            {!isPremium && !isAdmin ? (
              <Card className="border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50">
                <CardContent className="p-6 text-center space-y-3">
                  <Crown className="h-10 w-10 mx-auto text-yellow-500" />
                  <h3 className="font-bold text-foreground">Premium Feature</h3>
                  <p className="text-sm text-muted-foreground">API keys and embed codes are available for Premium users.</p>
                  <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white" onClick={() => setActiveTab('premium')}>
                    <Crown className="h-4 w-4 mr-2" />Upgrade to Premium
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-sm">Generate API Key</CardTitle></CardHeader>
                  <CardContent className="space-y-3">
                    <Input placeholder="Key name (e.g. My Blog)" value={newKeyName} onChange={e => setNewKeyName(e.target.value)} className="h-9 text-sm" />
                    <Input placeholder="Domain (optional)" value={newKeyDomain} onChange={e => setNewKeyDomain(e.target.value)} className="h-9 text-sm" />
                    <Button onClick={createApiKey} className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white text-xs">
                      <Key className="h-4 w-4 mr-1" />Generate Key
                    </Button>
                  </CardContent>
                </Card>
                <div className="space-y-3">
                  {apiKeys.map(key => (
                    <Card key={key.id}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between gap-2">
                          <div className="min-w-0">
                            <h3 className="font-semibold text-foreground text-xs">{key.name}</h3>
                            <code className="text-[11px] text-orange-600 bg-orange-50 px-2 py-0.5 rounded block truncate">{key.api_key}</code>
                            {key.domain && <p className="text-[10px] text-muted-foreground mt-1">{key.domain}</p>}
                            <p className="text-[10px] text-muted-foreground">{key.requests_count} requests</p>
                          </div>
                          <div className="flex gap-1 flex-shrink-0">
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => copyToClipboard(key.api_key)}><Copy className="h-3 w-3" /></Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => deleteApiKey(key.id)}><Trash2 className="h-3 w-3" /></Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <Card>
                  <CardHeader><CardTitle className="text-sm">Embed Code</CardTitle></CardHeader>
                  <CardContent className="space-y-4">
                    {apiKeys.length === 0 ? (
                      <p className="text-center py-6 text-sm text-muted-foreground">Create an API key first</p>
                    ) : (
                      apiKeys.map(key => (
                        <div key={key.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label className="font-semibold text-xs">{key.name}</Label>
                            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => copyToClipboard(getEmbedCode(key.api_key))}>
                              <Copy className="h-3 w-3 mr-1" />Copy
                            </Button>
                          </div>
                          <div className="bg-gray-950 rounded-lg p-3 overflow-x-auto">
                            <pre className="text-[10px] text-green-400 whitespace-pre-wrap">{getEmbedCode(key.api_key)}</pre>
                          </div>
                        </div>
                      ))
                    )}
                  </CardContent>
                </Card>

                {/* API Documentation */}
                <ApiDocumentation />
              </>
            )}
          </div>
        );

      case 'feed':
        return isEnabled('community') ? <CommunityFeed onNavigate={handleTabChange} /> : disabled;

      case 'contact-gain':
      case 'contacts':
      case 'contact_gain':
        return isEnabled('contact_gain') 
          ? <ContactGainHub userId={currentUserId || undefined} userEmail={userEmail} onNavigateTab={handleTabChange} />
          : disabled;

      case 'growth':
        return <BusinessGrowthDashboard onNavigate={handleTabChange} />;

      case 'syndicate-payouts':
        return isEnabled('syndicate') && isEnabled('business_pays_syndicate') ? <SyndicatePayouts /> : disabled;

      case 'support':
        return <SupportPage userEmail={userEmail} onNavigate={handleTabChange} />;

      case 'email-studio':
        return <AdminEmailStudio />;

      case 'admin':
        return null;

      default:
        if (activeTab?.startsWith('step_') || activeTab?.toLowerCase().includes('guide')) {
          return <UserGuide />;
        }
        if (activeTab?.toLowerCase().includes('notif')) {
          return <NotificationsPage onNavigate={handleTabChange} />;
        }
        return <BusinessGrowthDashboard onNavigate={handleTabChange} />;
    }
  };


  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-gray-50 to-orange-50">
        <SideNavMenu
          activeTab={activeTab}
          onTabChange={handleTabChange}
          isBusiness={isBusiness}
          isSyndicate={isSyndicate}
          isAdmin={isAdmin}
          isPremium={isPremium}
          onLogout={handleLogout}
        />

        <div className="flex-1 flex flex-col min-w-0">
          <header
            onFocusCapture={showNav}
            className={`bg-white/95 dark:bg-card/95 backdrop-blur-md border-b border-border sticky top-0 z-40 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] will-change-transform ${
              isNavVisible ? 'translate-y-0 shadow-xs' : '-translate-y-full shadow-none pointer-events-none'
            }`}
          >
            <div className="px-2.5 sm:px-4 py-2 sm:py-2.5 flex flex-col gap-2 max-w-7xl mx-auto w-full">
              <div className="flex items-center justify-between gap-2 min-w-0">
                {/* Left Brand & Sidebar Trigger Zone */}
                <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-shrink">
                  <SidebarTrigger className="flex-shrink-0 h-9 w-9 sm:h-11 sm:w-11 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 text-white shadow-md hover:shadow-lg hover:from-orange-600 hover:to-red-700 [&_svg]:h-5 sm:[&_svg]:h-6 [&_svg]:w-5 sm:[&_svg]:w-6 [&_svg]:text-white transition-all active:scale-95" />
                  <img loading="lazy" src={ggdLogo} alt="GGD" className="h-6 w-6 sm:h-7 sm:w-7 rounded-lg flex-shrink-0 md:hidden" />
                  <h1 className="text-xs sm:text-base md:text-lg font-black bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent truncate hidden min-[360px]:inline">
                    GGD AD NETWORK
                  </h1>
                </div>

                {/* Right Utility & Wallets Zone */}
                <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
                  {/* Structured Responsive Cash & Credit Wallets */}
                  <HeaderWallets
                    walletBalance={walletBalance}
                    credits={credits}
                    isAdmin={isAdmin}
                    isPremium={isPremium}
                    isBusiness={isBusiness}
                    isSyndicate={isSyndicate}
                    onNavigate={handleTabChange}
                  />

                  {/* Saved & Favorites Quick Drawer/Modal Trigger */}
                  <FavoritesQuickButton onNavigateTab={(tab) => handleTabChange(tab)} />

                  {/* Notifications */}
                  <NotificationBell />

                  {/* User Profile Avatar Menu */}
                  <AvatarMenuButton avatarUrl={avatarUrl} displayName={displayName} email={userEmail} />
                </div>
              </div>
              {activeTab !== 'feed' && <GlobalSearchBar />}
            </div>
          </header>

          <main className={`flex-1 px-3 sm:px-4 py-4 ${activeTab === 'feed' || activeTab === 'directory' ? 'pb-12 md:pb-24' : 'pb-40 md:pb-24'} max-w-5xl w-full mx-auto`}>
            {isPremium && (
              <PremiumRenewalBanner
                expiresAt={premiumExpiresAt}
                currentTier={currentTier}
                onRenew={async () => {
                  const { error } = await supabase.rpc('self_upgrade_premium', { _tier: currentTier });
                  if (error) { toast.error(error.message || 'Renewal failed'); return; }
                  toast.success('🎉 Subscription renewed for another month!');
                  initDashboard();
                }}
                onUpgrade={() => handleTabChange('premium')}
              />
            )}
            {renderContent()}
          </main>

          {activeTab !== 'feed' && activeTab !== 'directory' && (
            <MobileFooterMenu
              activeTab={activeTab}
              onTabChange={handleTabChange}
              isAdmin={isAdmin}
              isBusiness={isBusiness}
              isSyndicate={isSyndicate}
              isVisible={isNavVisible}
            />
          )}
          <CreateFab onNavigate={handleTabChange} />

          <ExtendAdvertModal
            ad={extendingAd}
            open={!!extendingAd}
            onOpenChange={(open) => { if (!open) setExtendingAd(null); }}
            userCredits={credits}
            onCreditsUpdate={(newCredits) => setCredits(newCredits)}
            onSuccess={(updatedAd) => {
              setAds(prev => prev.map(a => a.id === updatedAd.id ? { ...a, ...updatedAd } : a));
              fetchAds();
            }}
          />

          {/* Interactive Guided Walkthrough Tour Modal */}
          <GuidedTourModal
            isOpen={isTourOpen}
            onClose={() => setIsTourOpen(false)}
            onComplete={() => setIsTourOpen(false)}
          />
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Dashboard;
