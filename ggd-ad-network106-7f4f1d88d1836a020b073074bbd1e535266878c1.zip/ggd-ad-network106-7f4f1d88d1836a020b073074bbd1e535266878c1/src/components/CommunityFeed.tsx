import React, { useEffect, useMemo, useRef, useState } from 'react';
import CommunitySearchResults from "@/components/CommunitySearchResults";
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import {
  Image as ImageIcon, Link2, Video, Loader2, Send, Trash2,
  MessageCircle, ThumbsUp, X, Palette, Search, Heart,
  Coins, Gift, Youtube, Share2, ArrowRight, ArrowLeft, PenLine, Megaphone, ExternalLink,
  Store, BookOpen, MoreHorizontal, Edit3, Copy, Eye, Crown, ShoppingBag, Reply, Sparkles,
  ChevronDown, ChevronUp, MessageSquare, CornerDownRight
} from 'lucide-react';
import { toast } from 'sonner';
import { POST_TEMPLATES, TEMPLATE_CATEGORIES, findTemplate, extractHashtags } from '@/lib/postTemplates';
import EmojiReactionBar from '@/components/EmojiReactionBar';
import GifPickerPopover from '@/components/chat/GifPickerPopover';
import { getOrCreateTaskShareUrl } from '@/lib/taskShare';
import { useFeatureToggles } from '@/hooks/useFeatureToggles';
import CreditTaskComposer, { type CreditTaskPrefill } from '@/components/feed/CreditTaskComposer';
import SponsoredAdCard from '@/components/feed/SponsoredAdCard';
import FeaturedListingCard from '@/components/feed/FeaturedListingCard';
import YouTubeTaskPlayer, { youtubeId } from '@/components/feed/YouTubeTaskPlayer';
import { isYouTubeGoal, findGoal } from '@/components/feed/creditTaskGoals';
import { playRewardSound } from '@/lib/soundEffects';
import { parseBlogPost, CommunityBlogPostData } from '@/types/blog';
import BlogFeedCard from '@/components/feed/BlogFeedCard';
import BlogArticleComposer from '@/components/feed/BlogArticleComposer';
import EditPostModal from '@/components/feed/EditPostModal';
import FeedLinkPreview from '@/components/feed/FeedLinkPreview';
import ContactGainFeedCard from '@/components/feed/ContactGainFeedCard';
import { recordPostView, formatViewsCount } from '@/lib/postViews';
import SendGiftModal from '@/components/feed/SendGiftModal';
import SupportersModal from '@/components/feed/SupportersModal';
import { getPostGifts, PostGiftRecord } from '@/services/postGiftService';

type FeedFilter = 'all' | 'tasks' | 'featured' | 'products' | 'sponsored' | 'ads' | 'promotions' | 'blogs';

const FEED_FILTERS: { key: FeedFilter; label: string }[] = [
  { key: 'all', label: 'All Posts' },
  { key: 'blogs', label: '📰 Blog Articles' },
  { key: 'tasks', label: 'Credit Tasks' },
  { key: 'featured', label: 'Featured Listings' },
  { key: 'products', label: 'Products' },
  { key: 'sponsored', label: 'Sponsored Posts' },
  { key: 'ads', label: 'Banner Adverts' },
  { key: 'promotions', label: 'Business Promotions' },
];

/** Required watch seconds parsed from the task description, default 30s. */
const requiredWatchSeconds = (task: any) => {
  const m = String(task?.description || '').match(/at least (\d+) seconds/i);
  return m ? parseInt(m[1]) : 30;
};

type Reaction = 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';

const REACTIONS: { key: Reaction; emoji: string; label: string }[] = [
  { key: 'like',  emoji: '👍', label: 'Like' },
  { key: 'love',  emoji: '❤️', label: 'Love' },
  { key: 'haha',  emoji: '😂', label: 'Haha' },
  { key: 'wow',   emoji: '😮', label: 'Wow' },
  { key: 'sad',   emoji: '😢', label: 'Sad' },
  { key: 'angry', emoji: '😡', label: 'Angry' },
];

const reactionEmoji = (r: Reaction | null) => REACTIONS.find(x => x.key === r)?.emoji || '👍';

interface PostAuthor {
  user_id: string;
  display_name: string | null;
  business_name: string | null;
  business_logo_url: string | null;
  avatar_url: string | null;
  business_slug: string | null;
}
interface Post {
  id: string;
  user_id: string;
  content: string | null;
  image_url: string | null;
  link_url: string | null;
  video_url: string | null;
  background_template: string | null;
  tags: string[] | null;
  created_at: string;
  author?: PostAuthor;
  reactions: Record<Reaction, number>;
  myReaction: Reaction | null;
  commentCount: number;
}

const ytEmbed = (url: string) => {
  try {
    const u = new URL(url);
    if (u.hostname.includes('youtu.be')) return `https://www.youtube.com/embed/${u.pathname.slice(1)}`;
    if (u.hostname.includes('youtube.com')) {
      const id = u.searchParams.get('v');
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (u.hostname.includes('vimeo.com')) return `https://player.vimeo.com/video${u.pathname}`;
  } catch {}
  return null;
};

const timeAgo = (iso: string) => {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60); if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60); if (h < 24) return `${h}h`;
  const d = Math.floor(h / 24); if (d < 30) return `${d}d`;
  return new Date(iso).toLocaleDateString();
};

// Share destinations reused for Credit Task posts inside the feed.
const FEED_SHARE_PLATFORMS = [
  { key: 'whatsapp', label: 'WhatsApp', build: (text: string, url: string) => `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}` },
  { key: 'facebook', label: 'Facebook', build: (_t: string, url: string) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
  { key: 'telegram', label: 'Telegram', build: (text: string, url: string) => `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}` },
  { key: 'twitter', label: 'X / Twitter', build: (text: string, url: string) => `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
];

// Render content with hashtags as clickable chips.
const RichContent: React.FC<{ text: string; onTagClick: (tag: string) => void; className?: string }> = ({ text, onTagClick, className }) => {
  const parts = text.split(/(#[\p{L}0-9_]{2,40})/gu);
  return (
    <span className={className}>
      {parts.map((p, i) => {
        if (p.startsWith('#')) {
          const tag = p.slice(1);
          return (
            <button
              key={i}
              onClick={(e) => { e.stopPropagation(); onTagClick(tag.toLowerCase()); }}
              className="text-orange-600 font-semibold hover:underline"
            >
              #{tag}
            </button>
          );
        }
        return <React.Fragment key={i}>{p}</React.Fragment>;
      })}
    </span>
  );
};

interface CommunityFeedProps {
  onNavigate?: (tab: string) => void;
}

const CommunityFeed: React.FC<CommunityFeedProps> = ({ onNavigate }) => {
  const { isEnabled } = useFeatureToggles();
  const [me, setMe] = useState<{ id: string; profile?: PostAuthor } | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [taskPosts, setTaskPosts] = useState<any[]>([]);
  const [featuredListings, setFeaturedListings] = useState<any[]>([]);
  const [bannerAds, setBannerAds] = useState<any[]>([]);
  const [feedFilter, setFeedFilter] = useState<FeedFilter>('all');
  const [taskComposerOpen, setTaskComposerOpen] = useState(false);
  const [taskPrefill, setTaskPrefill] = useState<CreditTaskPrefill | null>(null);
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>([]);
  const [credits, setCredits] = useState(0);
  const [shareTarget, setShareTarget] = useState<any | null>(null);
  const [verifyingTaskId, setVerifyingTaskId] = useState<string | null>(null);
  const [composerOpen, setComposerOpen] = useState(false);
  const [composerMode, setComposerMode] = useState<'normal' | 'blog'>('normal');
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState('');
  const [linkUrl, setLinkUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [showLink, setShowLink] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [posting, setPosting] = useState(false);
  const [templateId, setTemplateId] = useState<string | null>(null);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);
  const [activeTplCategory, setActiveTplCategory] = useState<string>(TEMPLATE_CATEGORIES[0]);
  const [filterQuery, setFilterQuery] = useState('');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [editingPost, setEditingPost] = useState<any | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handlePostUpdated = (updatedPost: any) => {
    setPosts(prev => prev.map(p => p.id === updatedPost.id ? { ...p, ...updatedPost } : p));
  };

  useEffect(() => { init(); }, []);

  // Global "Create" button hooks
  useEffect(() => {
    const openPost = () => { setComposerMode('normal'); setComposerOpen(true); };
    const openBlog = () => { setComposerMode('blog'); setComposerOpen(true); };
    const openTask = () => { setTaskPrefill(null); setTaskComposerOpen(true); };
    window.addEventListener('ggd-open-composer', openPost);
    window.addEventListener('ggd-open-blog-composer', openBlog);
    window.addEventListener('ggd-open-task-composer', openTask);
    return () => {
      window.removeEventListener('ggd-open-composer', openPost);
      window.removeEventListener('ggd-open-blog-composer', openBlog);
      window.removeEventListener('ggd-open-task-composer', openTask);
    };
  }, []);

  const init = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('user_id, display_name, business_name, business_logo_url, avatar_url, business_slug, credits')
        .eq('user_id', user.id)
        .maybeSingle();
      setMe({ id: user.id, profile: (profile as any) || undefined });
      setCredits((profile as any)?.credits || 0);
    }
    await loadFeed(user?.id);
    await loadTasks(user?.id);
    await loadFeaturedListings();
    await loadBannerAds();
  };

  // Existing Featured Listings surfaced as native feed posts.
  const loadFeaturedListings = async () => {
    const { data } = await supabase
      .from('business_listings')
      .select('*')
      .eq('is_active', true)
      .eq('is_featured', true)
      .order('created_at', { ascending: false })
      .limit(15);
    const list = data || [];
    const live = list.filter((l: any) => !l.featured_until || new Date(l.featured_until) > new Date());
    const userIds = Array.from(new Set(live.map((l: any) => l.user_id)));
    const { data: profs } = userIds.length
      ? await supabase.from('profiles').select('user_id, business_name, display_name').in('user_id', userIds)
      : { data: [] as any[] };
    const map = new Map((profs || []).map((p: any) => [p.user_id, p]));
    setFeaturedListings(live.map((l: any) => ({
      ...l,
      business_name: map.get(l.user_id)?.business_name || map.get(l.user_id)?.display_name || null,
    })));
  };

  // Active, approved and unexpired Banner Adverts shown as sponsored posts.
  const loadBannerAds = async () => {
    const { data } = await supabase
      .from('ads')
      .select('*')
      .eq('is_active', true)
      .eq('approved', true)
      .order('created_at', { ascending: false })
      .limit(15);
    const live = (data || []).filter((a: any) => !a.expires_at || new Date(a.expires_at) > new Date());
    setBannerAds(live);
  };

  // Credit Tasks are surfaced inside the community feed while remaining in the
  // Task Feed. Reuses the existing tasks table / rules (no new task system).
  const loadTasks = async (userId?: string) => {
    if (!userId) { setTaskPosts([]); return; }
    const { data } = await supabase
      .from('tasks')
      .select('*')
      .eq('is_active', true)
      .neq('creator_id', userId)
      .order('created_at', { ascending: false })
      .limit(30);
    setTaskPosts(data || []);
    const { data: comps } = await supabase.from('task_completions').select('task_id').eq('user_id', userId);
    setCompletedTaskIds((comps || []).map((c: any) => c.task_id));
  };

  // Shared reward path — identical rules to the Task Feed engine.
  const awardTask = async (task: any): Promise<boolean> => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;
    const { error } = await supabase.from('task_completions').insert({ task_id: task.id, user_id: user.id });
    if (error) {
      if (error.code === '23505') { toast.info('Already completed!'); return false; }
      toast.error('Failed to complete task');
      return false;
    }
    await supabase.from('tasks').update({ completions_count: (task.completions_count || 0) + 1 }).eq('id', task.id);
    if (task.max_completions && (task.completions_count || 0) + 1 >= task.max_completions) {
      await supabase.from('tasks').update({ is_active: false }).eq('id', task.id);
    }
    const updated = credits + (task.reward_credits || 0);
    await supabase.from('profiles').update({ credits: updated }).eq('user_id', user.id);
    setCredits(updated);
    setCompletedTaskIds(prev => [...prev, task.id]);
    playRewardSound();
    toast.success(`🎉 Earned ${task.reward_credits} credits!`);
    return true;
  };

  // YouTube / website tasks complete natively in the feed once monitored
  // requirements (watch duration, completion) are satisfied.
  const completeInFeedTask = async (task: any) => {
    setVerifyingTaskId(task.id);
    await awardTask(task);
    setVerifyingTaskId(null);
  };

  // Same share → verify → reward flow used by the Task Feed.
  const startTaskVerification = async (task: any, platformKey: string) => {
    const platform = FEED_SHARE_PLATFORMS.find(p => p.key === platformKey);
    setShareTarget(null);
    if (!platform) return;
    const smartUrl = (await getOrCreateTaskShareUrl(task.id)) || task.share_url || '';
    const text = `${task.title}${task.description ? ` — ${task.description}` : ''}`;
    window.open(platform.build(text, smartUrl), '_blank', 'noopener,noreferrer');

    setVerifyingTaskId(task.id);
    toast.info('⏳ Sharing... Verifying in 15 seconds. Stay on the share page!', { duration: 15000 });
    setTimeout(async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setVerifyingTaskId(null); return; }
      const { error } = await supabase.from('task_completions').insert({ task_id: task.id, user_id: user.id });
      if (error) {
        setVerifyingTaskId(null);
        if (error.code === '23505') { toast.info('Already completed!'); return; }
        toast.error('Failed to complete task');
        return;
      }
      await supabase.from('tasks').update({ completions_count: (task.completions_count || 0) + 1 }).eq('id', task.id);
      if (task.max_completions && (task.completions_count || 0) + 1 >= task.max_completions) {
        await supabase.from('tasks').update({ is_active: false }).eq('id', task.id);
      }
      const updated = credits + (task.reward_credits || 0);
      await supabase.from('profiles').update({ credits: updated }).eq('user_id', user.id);
      setCredits(updated);
      setCompletedTaskIds(prev => [...prev, task.id]);
      setVerifyingTaskId(null);
      toast.success(`🎉 Earned ${task.reward_credits} credits!`);
      loadTasks(user.id);
    }, 15000);
  };

  const loadFeed = async (userId?: string) => {
    setLoading(true);
    const { data: rawPosts } = await supabase
      .from('community_posts')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    const list = rawPosts || [];
    const ids = list.map(p => p.id);
    const userIds = Array.from(new Set(list.map(p => p.user_id)));

    const [{ data: authors }, { data: reactions }, { data: comments }] = await Promise.all([
      userIds.length
        ? supabase.from('profiles')
            .select('user_id, display_name, business_name, business_logo_url, avatar_url, business_slug')
            .in('user_id', userIds)
        : Promise.resolve({ data: [] as any[] }),
      ids.length
        ? supabase.from('post_reactions').select('post_id, user_id, reaction').in('post_id', ids)
        : Promise.resolve({ data: [] as any[] }),
      ids.length
        ? supabase.from('post_comments').select('post_id').in('post_id', ids)
        : Promise.resolve({ data: [] as any[] }),
    ]);

    const authorMap = new Map((authors || []).map((a: any) => [a.user_id, a]));
    const enriched: Post[] = list.map((p: any) => {
      const counts: Record<Reaction, number> = { like: 0, love: 0, haha: 0, wow: 0, sad: 0, angry: 0 };
      let mine: Reaction | null = null;
      (reactions || []).filter((r: any) => r.post_id === p.id).forEach((r: any) => {
        counts[r.reaction as Reaction] = (counts[r.reaction as Reaction] || 0) + 1;
        if (userId && r.user_id === userId) mine = r.reaction;
      });
      return {
        ...p,
        author: authorMap.get(p.user_id),
        reactions: counts,
        myReaction: mine,
        commentCount: (comments || []).filter((c: any) => c.post_id === p.id).length,
      };
    });

    setPosts(enriched);
    setLoading(false);
  };

  const onPickImage = (f: File | null) => {
    if (!f) { setImageFile(null); setImagePreview(null); return; }
    if (f.size > 5 * 1024 * 1024) { toast.error('Image must be under 5MB'); return; }
    setImageFile(f);
    setImagePreview(URL.createObjectURL(f));
    // Disable template when an image is attached — templates are for text posts.
    setTemplateId(null);
  };

  const submitPost = async () => {
    if (!me) { toast.error('Please sign in to post'); return; }
    const text = content.trim();
    const hasMedia = Boolean(imageFile || imagePreview || linkUrl.trim() || videoUrl.trim());
    if (!text && !hasMedia) {
      toast.error('Add some text, a GIF, an image, a link or a video');
      return;
    }
    setPosting(true);
    try {
      let image_url: string | null = null;
      if (imageFile) {
        const ext = imageFile.name.split('.').pop() || 'jpg';
        const path = `${me.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage
          .from('community-posts').upload(path, imageFile, { upsert: false });
        if (upErr) throw upErr;
        image_url = supabase.storage.from('community-posts').getPublicUrl(path).data.publicUrl;
      } else if (imagePreview && (imagePreview.startsWith('http://') || imagePreview.startsWith('https://') || imagePreview.startsWith('data:'))) {
        image_url = imagePreview;
      }
      const tags = extractHashtags(text);
      const { error } = await supabase.from('community_posts').insert({
        user_id: me.id,
        content: text || null,
        image_url,
        link_url: linkUrl.trim() || null,
        video_url: videoUrl.trim() || null,
        background_template: image_url ? null : templateId,
        tags,
      });
      if (error) throw error;
      setContent(''); setLinkUrl(''); setVideoUrl('');
      setShowLink(false); setShowVideo(false);
      setTemplateId(null);
      setImageFile(null);
      setImagePreview(null);
      toast.success('Posted!');
      await loadFeed(me.id);
    } catch (e: any) {
      toast.error(e.message || 'Failed to post');
    } finally {
      setPosting(false);
    }
  };

  const react = async (post: Post, reaction: Reaction) => {
    if (!me) { toast.error('Please sign in to react'); return; }
    const same = post.myReaction === reaction;

    setPosts(prev => prev.map(p => {
      if (p.id !== post.id) return p;
      const counts = { ...p.reactions };
      if (p.myReaction) counts[p.myReaction] = Math.max(0, counts[p.myReaction] - 1);
      if (!same) counts[reaction] = (counts[reaction] || 0) + 1;
      return { ...p, reactions: counts, myReaction: same ? null : reaction };
    }));

    if (same) {
      await supabase.from('post_reactions').delete().eq('post_id', post.id).eq('user_id', me.id);
    } else {
      await supabase.from('post_reactions').upsert(
        { post_id: post.id, user_id: me.id, reaction },
        { onConflict: 'post_id,user_id' },
      );
    }
  };

  const deletePost = async (post: Post) => {
    if (!confirm('Delete this post?')) return;
    const { error } = await supabase.from('community_posts').delete().eq('id', post.id);
    if (error) return toast.error(error.message);
    setPosts(prev => prev.filter(p => p.id !== post.id));
    toast.success('Post deleted');
  };

  const visiblePosts = useMemo(() => {
    let list = posts;
    if (activeTag) list = list.filter(p => (p.tags || []).map(t => t.toLowerCase()).includes(activeTag));
    const q = filterQuery.trim().toLowerCase();
    if (q) {
      list = list.filter(p =>
        (p.content || '').toLowerCase().includes(q) ||
        (p.tags || []).some(t => t.toLowerCase().includes(q)) ||
        (p.author?.business_name || p.author?.display_name || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [posts, filterQuery, activeTag]);

  const visibleTasks = useMemo(() => {
    if (activeTag) return [];
    const q = filterQuery.trim().toLowerCase();
    if (!q) return taskPosts;
    return taskPosts.filter(t =>
      (t.title || '').toLowerCase().includes(q) || (t.description || '').toLowerCase().includes(q));
  }, [taskPosts, filterQuery, activeTag]);

  const visibleListings = useMemo(() => {
    if (activeTag) return [];
    const q = filterQuery.trim().toLowerCase();
    if (!q) return featuredListings;
    return featuredListings.filter(l =>
      (l.title || '').toLowerCase().includes(q) ||
      (l.description || '').toLowerCase().includes(q) ||
      (l.business_name || '').toLowerCase().includes(q));
  }, [featuredListings, filterQuery, activeTag]);

  const visibleAds = useMemo(() => {
    if (activeTag) return [];
    const q = filterQuery.trim().toLowerCase();
    if (!q) return bannerAds;
    return bannerAds.filter(a =>
      (a.title || '').toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q));
  }, [bannerAds, filterQuery, activeTag]);

  // Merged chronological feed: community posts + credit tasks + featured
  // listings + sponsored banner adverts, filtered by the active feed tab.
  const feedItems = useMemo(() => {
    const wantPosts = feedFilter === 'all';
    const wantBlogsOnly = feedFilter === 'blogs';
    const wantTasks = feedFilter === 'all' || feedFilter === 'tasks' || feedFilter === 'promotions';
    const wantListings =
      feedFilter === 'all' || feedFilter === 'featured' || feedFilter === 'products' || feedFilter === 'promotions';
    const wantAds = feedFilter === 'all' || feedFilter === 'sponsored' || feedFilter === 'ads';

    const listings = feedFilter === 'products'
      ? visibleListings.filter(l => (l.listing_type || 'product') === 'product')
      : visibleListings;

    const postsToInclude = wantBlogsOnly
      ? visiblePosts.filter(p => parseBlogPost(p.content) !== null)
      : (wantPosts ? visiblePosts : []);

    const items: { kind: 'post' | 'task' | 'listing' | 'ad'; created_at: string; data: any }[] = [
      ...postsToInclude.map(p => ({ kind: 'post' as const, created_at: p.created_at, data: p })),
      ...(wantTasks ? visibleTasks.map(t => ({ kind: 'task' as const, created_at: t.created_at, data: t })) : []),
      ...(wantListings ? listings.map(l => ({ kind: 'listing' as const, created_at: l.created_at, data: l })) : []),
      ...(wantAds ? visibleAds.map(a => ({ kind: 'ad' as const, created_at: a.created_at, data: a })) : []),
    ];
    return items.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }, [visiblePosts, visibleTasks, visibleListings, visibleAds, feedFilter]);

  const myAvatar = me?.profile?.business_logo_url || me?.profile?.avatar_url;
  const myName = me?.profile?.business_name || me?.profile?.display_name || 'You';
  const activeTpl = findTemplate(templateId);

  return (
    <div className="max-w-2xl mx-auto space-y-3 sm:space-y-4">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={filterQuery}
          onChange={e => setFilterQuery(e.target.value)}
          placeholder="Search posts, people, businesses, products, #hashtags…"
          className="pl-9 h-10 rounded-full bg-muted/40 border-0"
        />
        {activeTag && (
          <button
            onClick={() => setActiveTag(null)}
            className="absolute right-2 top-1/2 -translate-y-1/2 inline-flex items-center gap-1 text-[11px] font-bold text-orange-600 bg-orange-100 dark:bg-orange-900/30 px-2 py-1 rounded-full"
          >
            #{activeTag} <X className="h-3 w-3" />
          </button>
        )}
      </div>

      <CommunitySearchResults query={filterQuery} />

      {/* Composer (Facebook-style Default Open Box with Top Action Bar) */}
      {me ? (
        <Card className="border border-border/80 shadow-sm overflow-hidden bg-card rounded-2xl">
          {/* Top Post Type Selector Bar */}
          <div className="flex items-center justify-between border-b border-border/60 bg-muted/20 px-3 py-2">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                onClick={() => setComposerMode('normal')}
                className={`flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
                  composerMode === 'normal'
                    ? 'bg-orange-500 text-white shadow-sm'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'
                }`}
              >
                <PenLine className="h-3.5 w-3.5" />
                <span>Create Post</span>
              </button>

              <button
                type="button"
                onClick={() => setComposerMode('blog')}
                className={`flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
                  composerMode === 'blog'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-purple-600 dark:text-purple-400 hover:bg-purple-500/10'
                }`}
              >
                <BookOpen className="h-3.5 w-3.5" />
                <span>Blog Article</span>
                <span className={`inline-flex items-center gap-0.5 text-[9px] font-black uppercase tracking-wider px-1.5 py-0.2 rounded-full ${
                  composerMode === 'blog' ? 'bg-amber-400 text-amber-950' : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-2xs'
                }`}>
                  <Crown className="h-2.5 w-2.5 fill-current" />
                  VIP
                </span>
              </button>

              <button
                type="button"
                onClick={() => { setTaskPrefill(null); setTaskComposerOpen(true); }}
                className="flex items-center gap-2 text-xs font-bold px-3 py-1.5 rounded-xl text-green-700 dark:text-green-400 hover:bg-green-500/10 transition-colors"
              >
                <Coins className="h-3.5 w-3.5" />
                <span>Credit Task</span>
                <span className="text-[9px] font-black uppercase tracking-wider bg-green-600 text-white px-1.5 py-0.2 rounded-full">
                  Earn
                </span>
              </button>
            </div>

            {composerMode === 'blog' && (
              <button
                type="button"
                onClick={() => setComposerMode('normal')}
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 font-medium"
              >
                <ArrowLeft className="h-3.5 w-3.5" /> Quick Post
              </button>
            )}
          </div>

          <CardContent className="p-3 sm:p-4 space-y-3">
            {composerMode === 'blog' ? (
              <BlogArticleComposer
                userId={me.id}
                authorProfile={me.profile}
                onSuccess={() => {
                  setComposerMode('normal');
                  loadFeed(me.id);
                }}
                onCancel={() => setComposerMode('normal')}
              />
            ) : (
              <>
                <div className="flex gap-3 items-start">
                  <Avatar className="h-10 w-10 flex-shrink-0 ring-2 ring-border/50">
                    {myAvatar && <AvatarImage src={myAvatar} alt={myName} />}
                    <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-600 text-white text-sm font-bold">
                      {myName[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>

                  {activeTpl && !imagePreview ? (
                    <div
                      className={`flex-1 rounded-2xl flex items-center justify-center min-h-[140px] p-4 relative overflow-hidden shadow-inner ${activeTpl.isAnimated ? 'animated-post-bg' : ''}`}
                      style={{ background: activeTpl.background }}
                    >
                      <textarea
                        value={content}
                        onChange={e => setContent(e.target.value)}
                        placeholder="Type something inspiring…"
                        rows={3}
                        maxLength={300}
                        className={`w-full bg-transparent border-0 outline-none text-center font-bold text-lg sm:text-xl resize-none placeholder:opacity-70 ${activeTpl.textColor}`}
                      />
                      <button
                        onClick={() => setTemplateId(null)}
                        type="button"
                        className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white rounded-full p-1 transition-colors"
                        aria-label="Remove template"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <Textarea
                      value={content}
                      onChange={e => setContent(e.target.value)}
                      placeholder={`What's on your mind, ${myName.split(' ')[0]}? Share updates, tips, offers or #hashtags...`}
                      rows={2}
                      className="flex-1 resize-none border-border/70 bg-muted/20 focus-visible:bg-background rounded-xl text-sm"
                      maxLength={2000}
                    />
                  )}
                </div>

                {imagePreview && (
                  <div className="relative rounded-2xl overflow-hidden border border-border/70 shadow-sm group">
                    <img loading="lazy" src={imagePreview} alt="Attached upload" className="w-full max-h-80 object-cover" />
                    <button
                      onClick={() => onPickImage(null)}
                      className="absolute top-2 right-2 bg-black/70 hover:bg-black text-white rounded-full p-1.5 transition-colors shadow"
                      type="button"
                      aria-label="Remove image"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}

                {showLink && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 bg-muted/40 p-2 rounded-xl border border-border/60">
                      <Link2 className="h-4 w-4 text-blue-600 shrink-0" />
                      <Input
                        placeholder="https://your-website.com or article link"
                        value={linkUrl}
                        onChange={e => setLinkUrl(e.target.value)}
                        className="h-8 text-xs bg-background"
                      />
                      <button type="button" onClick={() => { setShowLink(false); setLinkUrl(''); }} className="text-muted-foreground p-1">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    {linkUrl.trim().length > 3 && (
                      <FeedLinkPreview url={linkUrl.trim()} isInteractive={false} className="border border-blue-500/40 shadow-xs" />
                    )}
                  </div>
                )}

                {showVideo && (
                  <div className="flex items-center gap-2 bg-muted/40 p-2 rounded-xl border border-border/60">
                    <Video className="h-4 w-4 text-red-600 shrink-0" />
                    <Input
                      placeholder="YouTube / Vimeo video URL"
                      value={videoUrl}
                      onChange={e => setVideoUrl(e.target.value)}
                      className="h-8 text-xs bg-background"
                    />
                    <button type="button" onClick={() => { setShowVideo(false); setVideoUrl(''); }} className="text-muted-foreground p-1">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}

                {/* Template picker */}
                {showTemplatePicker && !imagePreview && (
                  <div className="border border-border/60 rounded-2xl p-3 bg-muted/30 space-y-2">
                    <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                      {TEMPLATE_CATEGORIES.map(cat => (
                        <button
                          key={cat}
                          onClick={() => setActiveTplCategory(cat)}
                          className={`flex-shrink-0 text-[11px] font-bold px-3 py-1 rounded-full transition-colors ${
                            activeTplCategory === cat
                              ? 'bg-orange-500 text-white'
                              : 'bg-background text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      <button
                        onClick={() => setTemplateId(null)}
                        className={`aspect-square rounded-xl border-2 flex items-center justify-center text-[10px] font-bold transition-all ${
                          !templateId ? 'border-orange-500 text-orange-500 bg-orange-500/10' : 'border-border text-muted-foreground'
                        }`}
                      >
                        Standard
                      </button>
                      {POST_TEMPLATES.filter(t => t.category === activeTplCategory).map(t => (
                        <button
                          key={t.id}
                          onClick={() => setTemplateId(t.id)}
                          className={`aspect-square rounded-xl border-2 overflow-hidden relative transition-transform hover:scale-105 ${
                            templateId === t.id ? 'border-orange-500 ring-2 ring-orange-300' : 'border-transparent'
                          }`}
                          style={{ background: t.background }}
                          title={t.name}
                        >
                          <span className={`absolute inset-x-0 bottom-0 text-[9px] font-bold py-0.5 bg-black/40 text-center ${t.textColor}`}>
                            {t.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Facebook-style Action Toolbar */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/60 flex-wrap">
                  <div className="flex items-center gap-1 flex-wrap">
                    <input
                      type="file"
                      ref={fileRef}
                      accept="image/*,image/gif,.gif"
                      className="hidden"
                      onChange={e => onPickImage(e.target.files?.[0] || null)}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2.5 rounded-xl hover:bg-green-500/10 text-foreground"
                      onClick={() => fileRef.current?.click()}
                    >
                      <ImageIcon className="h-4 w-4 mr-1.5 text-green-600" />
                      <span className="text-xs font-semibold">Photo</span>
                    </Button>
                    <GifPickerPopover
                      onSelectGif={(gifUrl) => {
                        setImagePreview(gifUrl);
                        setImageFile(null);
                        setTemplateId(null);
                        toast.success('Animated GIF attached!');
                      }}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2.5 rounded-xl hover:bg-orange-500/10 text-foreground"
                      onClick={() => {
                        if (onNavigate) {
                          onNavigate('directory');
                        } else {
                          window.location.href = '/directory';
                        }
                      }}
                      title="Explore products, services & verified merchants"
                    >
                      <Store className="h-4 w-4 mr-1.5 text-orange-600" />
                      <span className="text-xs font-semibold">Marketplace</span>
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2.5 rounded-xl hover:bg-fuchsia-500/10 text-foreground"
                      onClick={() => setShowTemplatePicker(s => !s)}
                    >
                      <Palette className="h-4 w-4 mr-1.5 text-fuchsia-500" />
                      <span className="text-xs font-semibold">Color Theme</span>
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2.5 rounded-xl hover:bg-blue-500/10 text-foreground"
                      onClick={() => setShowLink(s => !s)}
                    >
                      <Link2 className="h-4 w-4 mr-1.5 text-blue-600" />
                      <span className="text-xs font-semibold">Link</span>
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2.5 rounded-xl hover:bg-red-500/10 text-foreground"
                      onClick={() => setShowVideo(s => !s)}
                    >
                      <Video className="h-4 w-4 mr-1.5 text-red-600" />
                      <span className="text-xs font-semibold">Video</span>
                    </Button>
                  </div>

                  <Button
                    onClick={submitPost}
                    disabled={posting || (!content.trim() && !imagePreview && !linkUrl && !videoUrl)}
                    size="sm"
                    className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white font-bold rounded-full px-5 shadow-sm h-8"
                  >
                    {posting ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="h-3.5 w-3.5 mr-1.5" /> Post</>}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4 text-center text-sm text-muted-foreground">
            Sign in to share posts with the community.
          </CardContent>
        </Card>
      )}

      {/* Feed filters */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 scrollbar-none">
        {FEED_FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFeedFilter(f.key)}
            className={`shrink-0 px-3.5 h-9 rounded-full text-[12px] font-bold border transition-colors ${
              feedFilter === f.key
                ? 'bg-gradient-to-r from-orange-500 to-red-600 text-white border-transparent'
                : 'bg-muted/40 text-muted-foreground border-border/60 hover:border-orange-500/50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Daily Contact Gain Spotlight Card */}
      {feedFilter === 'all' && isEnabled('contact_gain') && (
        <ContactGainFeedCard onOpenContactHub={() => onNavigate?.('contact-gain')} />
      )}

      {/* Feed */}
      {loading ? (
        <div className="text-center py-12"><Loader2 className="h-6 w-6 animate-spin mx-auto text-orange-500" /></div>
      ) : feedItems.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-8 text-center text-muted-foreground text-sm">
            {filterQuery || activeTag ? 'No posts match your search.' : 'No posts yet. Be the first to share!'}
          </CardContent>
        </Card>
      ) : (
        feedItems.map(item => item.kind === 'listing' ? (
          <FeaturedListingCard key={`listing-${item.data.id}`} listing={item.data} />
        ) : item.kind === 'ad' ? (
          <SponsoredAdCard key={`ad-${item.data.id}`} ad={item.data} currentUserId={me?.id || null} />
        ) : item.kind === 'post' ? (
          (() => {
            const blogData = parseBlogPost(item.data.content);
            if (blogData) {
              return (
                <BlogFeedCard
                  key={item.data.id}
                  post={item.data}
                  blog={blogData}
                  currentUserId={me?.id || null}
                  onReact={react}
                  onDelete={deletePost}
                  onEdit={(p) => setEditingPost(p)}
                  onPromote={(p) => {
                    setTaskPrefill({
                      title: (blogData.title || 'Promote my blog').slice(0, 80),
                      description: blogData.subtitle || blogData.title || '',
                      url: '',
                      flyer_url: blogData.cover_image || p.image_url || null,
                      goal: 'share',
                    });
                    setTaskComposerOpen(true);
                  }}
                  timeAgoStr={timeAgo(item.data.created_at)}
                />
              );
            }
            return (
              <PostCard
                key={item.data.id}
                post={item.data}
                currentUserId={me?.id || null}
                currentUserCredits={credits}
                currentUserName={myName}
                currentUserAvatar={myAvatar}
                onCreditsUpdated={(newBal) => setCredits(newBal)}
                onNavigateToFunding={() => onNavigate?.('funding')}
                onReact={react}
                onDelete={deletePost}
                onEdit={(p) => setEditingPost(p)}
                onTagClick={(t) => { setActiveTag(t); setFilterQuery(''); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                onImageOpen={(url) => setLightboxUrl(url)}
                onPromote={(p) => {
                  setTaskPrefill({
                    title: (p.content || 'Promote my post').slice(0, 80),
                    description: p.content || '',
                    url: p.link_url || p.video_url || '',
                    flyer_url: p.image_url || null,
                    goal: p.video_url ? 'youtube_views' : p.link_url ? 'website_visit' : 'share',
                  });
                  setTaskComposerOpen(true);
                }}
              />
            );
          })()
        ) : (
          <TaskFeedCard
            key={`task-${item.data.id}`}
            task={item.data}
            completed={completedTaskIds.includes(item.data.id)}
            verifying={verifyingTaskId === item.data.id}
            onStart={(t) => setShareTarget(t)}
            onNativeComplete={completeInFeedTask}
          />
        ))
      )}

      {/* Inline Credit Task creation from the feed */}
      <CreditTaskComposer
        open={taskComposerOpen}
        onClose={() => setTaskComposerOpen(false)}
        credits={credits}
        prefill={taskPrefill}
        onCreated={(c) => { setCredits(c); init(); }}
      />

      {/* Share platform picker for credit tasks opened from the feed */}
      <Dialog open={!!shareTarget} onOpenChange={(o) => !o && setShareTarget(null)}>
        <DialogContent className="max-w-sm">
          <div className="space-y-3">
            <div>
              <p className="text-sm font-bold text-foreground">Share to earn</p>
              <p className="text-[11px] text-muted-foreground">{shareTarget?.title}</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {FEED_SHARE_PLATFORMS.map(p => (
                <Button
                  key={p.key}
                  variant="outline"
                  className="h-11 rounded-xl text-xs font-bold"
                  onClick={() => startTaskVerification(shareTarget, p.key)}
                >
                  <Share2 className="h-4 w-4 mr-1.5" />{p.label}
                </Button>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image lightbox */}
      <Dialog open={!!lightboxUrl} onOpenChange={(o) => !o && setLightboxUrl(null)}>
        <DialogContent className="max-w-5xl p-0 bg-black border-0">
          {lightboxUrl && (
            <img loading="lazy" src={lightboxUrl} alt="" className="w-full h-auto max-h-[90vh] object-contain" />
          )}
        </DialogContent>
      </Dialog>

      {/* Post & Blog Editor Modal */}
      <EditPostModal
        open={!!editingPost}
        onOpenChange={(open) => {
          if (!open) setEditingPost(null);
        }}
        post={editingPost}
        onPostUpdated={handlePostUpdated}
      />
    </div>
  );
};

interface PostCardProps {
  post: Post;
  currentUserId: string | null;
  currentUserCredits?: number;
  currentUserName?: string;
  currentUserAvatar?: string | null;
  onCreditsUpdated?: (newBalance: number) => void;
  onNavigateToFunding?: () => void;
  onReact: (p: Post, r: Reaction) => void;
  onDelete: (p: Post) => void;
  onEdit?: (p: Post) => void;
  onTagClick: (tag: string) => void;
  onImageOpen: (url: string) => void;
  /** Convert this community post into a paid Credit Task. */
  onPromote?: (post: Post) => void;
}

interface TaskFeedCardProps {
  task: any;
  completed: boolean;
  verifying: boolean;
  onStart: (task: any) => void;
  /** Called when native in-feed requirements (watch duration) are met. */
  onNativeComplete?: (task: any) => void;
}

const TaskFeedCard: React.FC<TaskFeedCardProps> = ({ task, completed, verifying, onStart, onNativeComplete }) => {
  const vid = task.share_url ? youtubeId(task.share_url) : null;
  const isYouTube = (isYouTubeGoal(task.task_type) || !!vid) && !!vid;
  const goal = findGoal(task.task_type);
  const needSecs = requiredWatchSeconds(task);
  const [eligible, setEligible] = React.useState(false);
  return (
    <Card className="border border-green-500/30 shadow-sm overflow-hidden rounded-xl">
      <CardContent className="p-0">
        <div className="px-3 pt-3 pb-2 flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            {isYouTube ? <Youtube className="h-4 w-4 text-white" /> : <Gift className="h-4 w-4 text-white" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="font-bold text-[13px] truncate">{task.title}</p>
              <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-green-500/15 text-green-600 shrink-0">EARN CREDITS</span>
            </div>
            <p className="text-[11px] text-muted-foreground">
              {timeAgo(task.created_at)} · +{task.reward_credits} credits{goal ? ` · ${goal.label}` : ''}
            </p>
          </div>
        </div>
        {task.description && (
          <p className="px-3 pb-2 text-[14px] whitespace-pre-wrap break-words leading-snug">{task.description}</p>
        )}
        {isYouTube && vid ? (
          <YouTubeTaskPlayer
            videoId={vid}
            requiredSeconds={needSecs}
            disabled={completed}
            onEligible={() => setEligible(true)}
          />
        ) : task.flyer_url ? (
          <img loading="lazy" src={task.flyer_url} alt={task.title} className="w-full max-h-[420px] object-cover" />
        ) : null}
        <div className="p-3">
          <Button
            className="w-full h-11 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 font-bold"
            disabled={completed || verifying || (isYouTube && !eligible)}
            onClick={() => (isYouTube ? onNativeComplete?.(task) : onStart(task))}
          >
            {completed
              ? '✅ Completed'
              : verifying
                ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" />Verifying…</>
                : isYouTube && !eligible
                  ? <><Youtube className="h-4 w-4 mr-1.5" />Watch {needSecs}s to unlock reward</>
                  : <><Coins className="h-4 w-4 mr-1.5" />Claim {task.reward_credits} credits</>}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

const PostCard: React.FC<PostCardProps> = ({
  post,
  currentUserId,
  currentUserCredits = 0,
  currentUserName,
  currentUserAvatar,
  onCreditsUpdated,
  onNavigateToFunding,
  onReact,
  onDelete,
  onEdit,
  onTagClick,
  onImageOpen,
  onPromote,
}) => {
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<any[]>([]);
  const [commentText, setCommentText] = useState('');
  const [loadingComments, setLoadingComments] = useState(false);
  const [commentCount, setCommentCount] = useState(post.commentCount);
  const [heartBurst, setHeartBurst] = useState(false);
  const [viewsCount, setViewsCount] = useState<number>(0);
  const lastTapRef = useRef<number>(0);

  // Virtual Gifting & Real-time Supporter State
  const [giftModalOpen, setGiftModalOpen] = useState(false);
  const [supportersModalOpen, setSupportersModalOpen] = useState(false);
  const [giftCelebration, setGiftCelebration] = useState<{ emoji: string; name: string; amount: number; senderName: string } | null>(null);
  const [postGiftsState, setPostGiftsState] = useState<{
    gifts: PostGiftRecord[];
    totalCredits: number;
    topSupporter?: { name: string; amount: number; avatar?: string | null };
  }>({ gifts: [], totalCredits: 0 });

  const [replyingTo, setReplyingTo] = useState<{ id: string; name: string; parentCommentId?: string } | null>(null);
  const [inlineReplyCommentId, setInlineReplyCommentId] = useState<string | null>(null);
  const [inlineReplyText, setInlineReplyText] = useState('');
  const [expandedThreads, setExpandedThreads] = useState<Record<string, boolean>>({});
  const [activeThreadModalComment, setActiveThreadModalComment] = useState<any | null>(null);
  const [threadModalReplyText, setThreadModalReplyText] = useState('');

  const commentInputRef = useRef<HTMLInputElement>(null);
  const inlineInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const v = recordPostView(post);
    setViewsCount(v);
  }, [post.id]);

  // Load gifts on mount
  useEffect(() => {
    const data = getPostGifts(post.id);
    setPostGiftsState(data);
  }, [post.id]);

  const handleGiftSent = (giftRecord: PostGiftRecord, newBalance: number) => {
    onCreditsUpdated?.(newBalance);
    const updated = getPostGifts(post.id);
    setPostGiftsState(updated);
    setGiftCelebration({
      emoji: giftRecord.giftEmoji,
      name: giftRecord.giftName,
      amount: giftRecord.amount,
      senderName: giftRecord.senderName,
    });
    setTimeout(() => {
      setGiftCelebration(null);
    }, 4500);
  };

  const author = post.author;
  const authorName = author?.business_name || author?.display_name || 'GGD User';
  const authorAvatar = author?.business_logo_url || author?.avatar_url;
  const authorHref = author?.business_slug ? `/b/${author.business_slug}` : `/user/${post.user_id}`;
  const isOwner = currentUserId === post.user_id;
  const totalReactions = Object.values(post.reactions).reduce((a, b) => a + b, 0);
  const topReactions = (Object.entries(post.reactions) as [Reaction, number][])
    .filter(([, c]) => c > 0).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k]) => k);
  const embed = post.video_url ? ytEmbed(post.video_url) : null;
  const template = findTemplate(post.background_template);

  const loadComments = async () => {
    setLoadingComments(true);
    const { data: cs } = await supabase
      .from('post_comments').select('*').eq('post_id', post.id).order('created_at', { ascending: true });
    const userIds = Array.from(new Set((cs || []).map((c: any) => c.user_id)));
    const { data: profs } = userIds.length
      ? await supabase.from('profiles').select('user_id, display_name, business_name, business_logo_url, avatar_url, business_slug').in('user_id', userIds)
      : { data: [] as any[] };
    const map = new Map((profs || []).map((p: any) => [p.user_id, p]));
    setComments((cs || []).map((c: any) => ({ ...c, author: map.get(c.user_id) })));
    setLoadingComments(false);
  };

  const toggleComments = async () => {
    const next = !showComments;
    setShowComments(next);
    if (next && comments.length === 0) await loadComments();
  };

  const handleStartReply = (commentItem: any) => {
    const authorName = commentItem.author?.business_name || commentItem.author?.display_name || 'User';
    setReplyingTo({ id: commentItem.id, name: authorName, parentCommentId: commentItem.id });
    setInlineReplyCommentId(commentItem.id);
    setInlineReplyText(`@${authorName} `);
    setTimeout(() => {
      if (inlineInputRef.current) inlineInputRef.current.focus();
    }, 50);
  };

  const submitComment = async (customText?: string, parentId?: string) => {
    if (!currentUserId) { toast.error('Please sign in'); return; }
    const text = (customText !== undefined ? customText : (parentId ? inlineReplyText : commentText)).trim();
    if (!text) return;

    const { error } = await supabase.from('post_comments').insert({
      post_id: post.id,
      user_id: currentUserId,
      content: text,
    });
    if (error) return toast.error(error.message);

    setCommentText('');
    setInlineReplyText('');
    setReplyingTo(null);
    setInlineReplyCommentId(null);
    setCommentCount(c => c + 1);
    await loadComments();

    if (parentId) {
      setExpandedThreads(prev => ({ ...prev, [parentId]: true }));
    }
  };

  const submitThreadModalReply = async (customText?: string) => {
    if (!currentUserId) { toast.error('Please sign in'); return; }
    const text = (customText !== undefined ? customText : threadModalReplyText).trim();
    if (!text) return;

    const { error } = await supabase.from('post_comments').insert({
      post_id: post.id,
      user_id: currentUserId,
      content: text,
    });
    if (error) return toast.error(error.message);

    setThreadModalReplyText('');
    setCommentCount(c => c + 1);
    await loadComments();
  };

  const deleteComment = async (id: string) => {
    const { error } = await supabase.from('post_comments').delete().eq('id', id);
    if (error) return toast.error(error.message);
    setComments(prev => prev.filter(c => c.id !== id));
    setCommentCount(c => Math.max(0, c - 1));
    if (activeThreadModalComment?.id === id) {
      setActiveThreadModalComment(null);
    }
  };

  const toggleThreadReplies = (commentId: string) => {
    setExpandedThreads(prev => ({
      ...prev,
      [commentId]: !prev[commentId],
    }));
  };

  // Group comments into structured threads (top-level vs replies)
  const { topLevelComments, repliesByParent } = useMemo(() => {
    const topLevel: any[] = [];
    const repliesMap: Record<string, any[]> = {};

    comments.forEach(c => {
      // Check if comment is a tagged reply or regular comment
      const match = typeof c.content === 'string' && c.content.match(/^@([a-zA-Z0-9_\s]+?)\s/);
      if (match && topLevel.length > 0) {
        // Find matching parent or associate with previous root comment
        const taggedName = match[1].toLowerCase().trim();
        const parent = topLevel.find(t => {
          const tName = (t.author?.business_name || t.author?.display_name || '').toLowerCase().trim();
          return tName && (tName.includes(taggedName) || taggedName.includes(tName));
        }) || topLevel[topLevel.length - 1];

        if (parent) {
          if (!repliesMap[parent.id]) repliesMap[parent.id] = [];
          repliesMap[parent.id].push(c);
          return;
        }
      }
      topLevel.push(c);
    });

    return { topLevelComments: topLevel, repliesByParent: repliesMap };
  }, [comments]);

  const handleImageTap = (url: string) => {
    const now = Date.now();
    const since = now - lastTapRef.current;
    lastTapRef.current = now;
    if (since < 300) {
      // Double tap → like + heart burst
      if (post.myReaction !== 'love') onReact(post, 'love');
      setHeartBurst(true);
      setTimeout(() => setHeartBurst(false), 700);
    } else {
      // Single tap with delay → open lightbox
      setTimeout(() => {
        if (Date.now() - lastTapRef.current >= 290) onImageOpen(url);
      }, 300);
    }
  };

  return (
    <Card className="border-0 shadow-sm overflow-hidden rounded-xl">
      <CardContent className="p-0">
        {/* Header */}
        <div className="px-3 pt-3 pb-2 flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <Link to={authorHref} className="group shrink-0">
              <Avatar className="h-10 w-10 ring-2 ring-transparent group-hover:ring-orange-500 transition-all cursor-pointer">
                {authorAvatar && <AvatarImage src={authorAvatar} alt={authorName} />}
                <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-600 text-white text-xs font-bold">
                  {authorName[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </Link>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <Link to={authorHref} className="font-bold text-[13px] text-foreground hover:text-orange-600 hover:underline truncate">
                  {authorName}
                </Link>
                {author?.business_name && (
                  <Link to={authorHref} className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 dark:text-orange-400 text-[10px] font-bold border border-orange-500/20 transition">
                    <Store className="h-2.5 w-2.5" />
                    <span>Store</span>
                  </Link>
                )}
              </div>
              <div className="flex items-center gap-2 text-[11px] text-muted-foreground flex-wrap">
                <span>{timeAgo(post.created_at)}</span>
                {(post as any).updated_at && new Date((post as any).updated_at).getTime() > new Date(post.created_at).getTime() + 5000 && (
                  <span className="text-[10px] text-muted-foreground/80 italic font-medium">(edited)</span>
                )}
                <span>•</span>
                <span className="flex items-center gap-1 font-semibold text-muted-foreground">
                  <Eye className="h-3 w-3" />
                  {formatViewsCount(viewsCount)} views
                </span>
              </div>
            </div>
          </div>

          {/* Facebook-style 3-Dot Manage Menu */}
          <div className="flex items-center gap-1 shrink-0">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 rounded-full hover:bg-muted text-muted-foreground transition"
                  title="Post options"
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-48 p-1.5 rounded-xl shadow-lg border border-border bg-popover z-50">
                {isOwner && onEdit && (
                  <button
                    onClick={() => onEdit(post)}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg hover:bg-muted transition text-foreground text-left"
                  >
                    <Edit3 className="h-3.5 w-3.5 text-blue-600" />
                    Edit Post
                  </button>
                )}
                {isOwner && onPromote && (
                  <button
                    onClick={() => onPromote(post)}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg hover:bg-muted transition text-foreground text-left"
                  >
                    <Megaphone className="h-3.5 w-3.5 text-green-600" />
                    Promote Post
                  </button>
                )}
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.origin + authorHref);
                    toast.success('Post link copied to clipboard!');
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg hover:bg-muted transition text-foreground text-left"
                >
                  <Copy className="h-3.5 w-3.5 text-muted-foreground" />
                  Copy Link
                </button>
                {isOwner && (
                  <button
                    onClick={() => onDelete(post)}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg hover:bg-destructive/10 text-destructive transition text-left"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Delete Post
                  </button>
                )}
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* Templated text post */}
        {template && !post.image_url ? (
          <div
            className={`mx-3 mb-2 rounded-xl flex items-center justify-center min-h-[180px] p-5 ${template.isAnimated ? 'animated-post-bg' : ''}`}
            style={{ background: template.background }}
          >
            <p className={`text-center font-extrabold text-lg sm:text-xl leading-snug whitespace-pre-wrap break-words ${template.textColor}`}>
              {post.content && <RichContent text={post.content} onTagClick={onTagClick} />}
            </p>
          </div>
        ) : (
          post.content && (
            <p className="px-3 pb-2 text-[14px] whitespace-pre-wrap break-words leading-snug">
              <RichContent text={post.content} onTagClick={onTagClick} />
            </p>
          )
        )}

        {/* Image with double-tap-to-like */}
        {post.image_url && (
          <div
            className="relative cursor-pointer select-none bg-muted"
            onClick={() => handleImageTap(post.image_url!)}
          >
            <img loading="lazy" src={post.image_url} alt="" className="w-full max-h-[480px] object-cover" />
            {heartBurst && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Heart className="h-24 w-24 text-white fill-red-500 drop-shadow-2xl animate-scale-in" />
              </div>
            )}
          </div>
        )}

        {embed && (
          <div className="aspect-video bg-black">
            <iframe src={embed} className="w-full h-full" allowFullScreen title="video" />
          </div>
        )}

        {post.video_url && !embed && (
          <a href={post.video_url} target="_blank" rel="noopener noreferrer"
             className="block px-3 py-2 text-xs text-blue-600 hover:underline truncate">
            <Video className="h-3.5 w-3.5 inline mr-1" />{post.video_url}
          </a>
        )}

        {post.link_url && (
          <div className="mx-3 mb-3">
            <FeedLinkPreview
              url={post.link_url}
              title={post.content ? (post.content.length > 80 ? post.content.slice(0, 80) + '...' : post.content) : null}
            />
          </div>
        )}

        {/* Tag chips */}
        {(post.tags && post.tags.length > 0) && (
          <div className="px-3 pb-2 flex flex-wrap gap-1">
            {post.tags.slice(0, 6).map(t => (
              <button
                key={t}
                onClick={() => onTagClick(t.toLowerCase())}
                className="text-[10px] font-bold text-orange-600 bg-orange-100 dark:bg-orange-900/20 px-2 py-0.5 rounded-full hover:bg-orange-200"
              >
                #{t}
              </button>
            ))}
          </div>
        )}

        {/* Reaction & Comment summary bar */}
        {(totalReactions > 0 || commentCount > 0) && (
          <div className="px-3 py-1.5 flex items-center justify-between text-[11px] text-muted-foreground border-t border-b border-border/50">
            <div className="flex items-center gap-1">
              {topReactions.map(r => <span key={r}>{reactionEmoji(r)}</span>)}
              {totalReactions > 0 && <span className="ml-1 font-semibold">{totalReactions}</span>}
            </div>
            {commentCount > 0 && (
              <button
                type="button"
                onClick={toggleComments}
                className="hover:text-foreground font-medium hover:underline flex items-center gap-1 transition"
              >
                <span>{commentCount} comment{commentCount === 1 ? '' : 's'}</span>
                {showComments ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
              </button>
            )}
          </div>
        )}

        {/* Action buttons */}
        <div className="grid grid-cols-3 px-1 py-0.5 border-t border-border/50">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className={`gap-1.5 h-9 ${post.myReaction ? 'text-orange-600 font-bold' : ''}`}>
                {post.myReaction ? <span className="text-base">{reactionEmoji(post.myReaction)}</span> : <ThumbsUp className="h-4 w-4" />}
                <span className="text-[12px] truncate">
                  {post.myReaction ? REACTIONS.find(r => r.key === post.myReaction)?.label : 'Like'}
                </span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-1 flex gap-1" side="top">
              {REACTIONS.map(r => (
                <button
                  key={r.key}
                  onClick={() => onReact(post, r.key)}
                  className="text-2xl hover:scale-125 transition-transform p-1"
                  title={r.label}
                >
                  {r.emoji}
                </button>
              ))}
            </PopoverContent>
          </Popover>

          <Button
            variant="ghost"
            size="sm"
            className={`gap-1.5 h-9 text-[12px] truncate ${showComments ? 'text-orange-600 font-bold bg-orange-500/10' : ''}`}
            onClick={toggleComments}
          >
            <MessageCircle className="h-4 w-4" />
            <span>Comment</span>
            {commentCount > 0 && <span className="text-[11px] font-bold">({commentCount})</span>}
          </Button>

          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-1.5 h-9 text-[12px] truncate">
                <Share2 className="h-4 w-4" />
                <span>Share</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-52 p-2 space-y-1" side="top">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-xs font-normal"
                onClick={() => {
                  const url = `${window.location.origin}/#post-${post.id}`;
                  const text = post.content ? post.content.slice(0, 100) : 'Check this post out on GGD';
                  window.open(`https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`, '_blank');
                }}
              >
                <span className="mr-2">💬</span> WhatsApp
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-xs font-normal"
                onClick={() => {
                  const url = `${window.location.origin}/#post-${post.id}`;
                  const text = post.content ? post.content.slice(0, 100) : 'Check this post out on GGD';
                  window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, '_blank');
                }}
              >
                <span className="mr-2">🐦</span> X / Twitter
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-xs font-normal"
                onClick={() => {
                  const url = `${window.location.origin}/#post-${post.id}`;
                  window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
                }}
              >
                <span className="mr-2">📘</span> Facebook
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-xs font-normal"
                onClick={() => {
                  const url = `${window.location.origin}/#post-${post.id}`;
                  navigator.clipboard.writeText(url);
                  toast.success('Post link copied to clipboard!');
                }}
              >
                <Copy className="h-3.5 w-3.5 mr-2" /> Copy Link
              </Button>
            </PopoverContent>
          </Popover>
        </div>

        {/* Facebook-style Collapsible Comments & Threaded Replies Section */}
        {showComments && (
          <div className="px-3 py-3 border-t bg-muted/20 space-y-3">
            {/* Header with collapse button */}
            <div className="flex items-center justify-between pb-1 border-b border-border/40 text-xs">
              <span className="font-bold text-foreground flex items-center gap-1.5">
                <MessageSquare className="h-3.5 w-3.5 text-orange-600" /> Comments & Replies ({commentCount})
              </span>
              <button
                type="button"
                onClick={() => setShowComments(false)}
                className="text-[11px] text-muted-foreground hover:text-foreground font-semibold flex items-center gap-1"
              >
                Hide <ChevronUp className="h-3 w-3" />
              </button>
            </div>

            {loadingComments ? (
              <div className="text-center py-4"><Loader2 className="h-5 w-5 animate-spin inline text-orange-500" /></div>
            ) : comments.length === 0 ? (
              <p className="text-xs text-center text-muted-foreground py-2">No comments yet. Be the first to start the conversation!</p>
            ) : (
              <div className="space-y-3">
                {topLevelComments.map(c => {
                  const cn = c.author?.business_name || c.author?.display_name || 'User';
                  const ca = c.author?.business_logo_url || c.author?.avatar_url;
                  const cHref = c.author?.business_slug ? `/b/${c.author.business_slug}` : `/user/${c.user_id}`;
                  
                  const isMediaUrl = typeof c.content === 'string' && (
                    c.content.match(/^https?:\/\/.*\.(gif|png|jpe?g|webp)(\?.*)?$/i) ||
                    c.content.includes('giphy.com/media')
                  );

                  const replies = repliesByParent[c.id] || [];
                  const isThreadExpanded = expandedThreads[c.id] ?? (replies.length <= 2);
                  const isReplyingThis = inlineReplyCommentId === c.id;

                  return (
                    <div key={c.id} className="space-y-2 group/comment">
                      {/* Root Comment Row */}
                      <div className="flex gap-2 items-start">
                        <Link to={cHref} className="group shrink-0 mt-0.5">
                          <Avatar className="h-7 w-7 ring-1 ring-transparent group-hover:ring-orange-500 transition-all">
                            {ca && <AvatarImage src={ca} alt={cn} />}
                            <AvatarFallback className="text-xs bg-gradient-to-br from-orange-500 to-red-600 text-white">
                              {cn[0]?.toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </Link>

                        <div className="flex-1 min-w-0">
                          <div className="bg-background rounded-2xl px-3 py-2 inline-block max-w-full border border-border/50 shadow-2xs">
                            <div className="flex items-center gap-1.5">
                              <Link to={cHref} className="text-xs font-bold text-foreground hover:text-orange-600 hover:underline block truncate">
                                {cn}
                              </Link>
                              {c.author?.business_slug && (
                                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-orange-500/10 text-orange-600">
                                  Store
                                </span>
                              )}
                            </div>

                            {isMediaUrl ? (
                              <div className="mt-1.5 rounded-lg overflow-hidden border border-border/60 max-w-xs bg-muted/20">
                                <img loading="lazy" src={c.content} alt="Comment Media" className="max-h-48 object-cover w-full rounded" />
                              </div>
                            ) : (
                              <p className="text-[13px] whitespace-pre-wrap break-words leading-relaxed text-foreground mt-0.5">{c.content}</p>
                            )}
                          </div>

                          {/* Facebook-style Action Bar */}
                          <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground px-2">
                            <span>{timeAgo(c.created_at)}</span>
                            
                            <button
                              type="button"
                              onClick={() => handleStartReply(c)}
                              className="font-bold text-foreground/80 hover:text-orange-600 transition-colors flex items-center gap-1"
                            >
                              <Reply className="h-3 w-3" /> Reply
                            </button>

                            <button
                              type="button"
                              onClick={() => setActiveThreadModalComment(c)}
                              className="font-bold text-muted-foreground hover:text-orange-600 transition-colors flex items-center gap-1"
                              title="Open dedicated reply thread page"
                            >
                              <MessageSquare className="h-3 w-3" />
                              {replies.length > 0 ? `${replies.length} replies` : 'Thread View'}
                            </button>

                            {currentUserId === c.user_id && (
                              <button onClick={() => deleteComment(c.id)} className="hover:text-destructive text-muted-foreground transition-colors">
                                Delete
                              </button>
                            )}

                            <EmojiReactionBar targetType="comment" targetId={c.id} currentUserId={currentUserId} />
                          </div>

                          {/* Nested Replies Thread (Facebook style) */}
                          {replies.length > 0 && (
                            <div className="mt-2 ml-2 pl-3 border-l-2 border-orange-500/30 space-y-2">
                              {replies.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => toggleThreadReplies(c.id)}
                                  className="text-[11px] font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 transition"
                                >
                                  <CornerDownRight className="h-3 w-3" />
                                  {isThreadExpanded ? `Hide replies` : `View all ${replies.length} replies`}
                                </button>
                              )}

                              {isThreadExpanded && (
                                <div className="space-y-2 pt-0.5">
                                  {replies.map(rep => {
                                    const rCn = rep.author?.business_name || rep.author?.display_name || 'User';
                                    const rCa = rep.author?.business_logo_url || rep.author?.avatar_url;
                                    const rHref = rep.author?.business_slug ? `/b/${rep.author.business_slug}` : `/user/${rep.user_id}`;
                                    const rIsMedia = typeof rep.content === 'string' && (
                                      rep.content.match(/^https?:\/\/.*\.(gif|png|jpe?g|webp)(\?.*)?$/i) ||
                                      rep.content.includes('giphy.com/media')
                                    );

                                    return (
                                      <div key={rep.id} className="flex gap-2 items-start">
                                        <Link to={rHref} className="group shrink-0 mt-0.5">
                                          <Avatar className="h-6 w-6 ring-1 ring-transparent group-hover:ring-orange-500 transition-all">
                                            {rCa && <AvatarImage src={rCa} alt={rCn} />}
                                            <AvatarFallback className="text-[10px] bg-gradient-to-br from-purple-600 to-indigo-600 text-white">
                                              {rCn[0]?.toUpperCase()}
                                            </AvatarFallback>
                                          </Avatar>
                                        </Link>

                                        <div className="flex-1 min-w-0">
                                          <div className="bg-background/90 rounded-2xl px-3 py-1.5 inline-block max-w-full border border-border/40 shadow-2xs">
                                            <Link to={rHref} className="text-[11px] font-bold text-foreground hover:text-orange-600 hover:underline block truncate">
                                              {rCn}
                                            </Link>
                                            {rIsMedia ? (
                                              <div className="mt-1 rounded-lg overflow-hidden border border-border/60 max-w-xs">
                                                <img loading="lazy" src={rep.content} alt="Reply Media" className="max-h-40 object-cover w-full rounded" />
                                              </div>
                                            ) : (
                                              <p className="text-xs whitespace-pre-wrap break-words leading-relaxed text-foreground mt-0.5">{rep.content}</p>
                                            )}
                                          </div>

                                          <div className="flex items-center gap-2.5 mt-0.5 text-[10px] text-muted-foreground px-1.5">
                                            <span>{timeAgo(rep.created_at)}</span>
                                            <button
                                              type="button"
                                              onClick={() => handleStartReply(rep)}
                                              className="font-bold text-foreground/80 hover:text-orange-600 transition flex items-center gap-0.5"
                                            >
                                              <Reply className="h-2.5 w-2.5" /> Reply
                                            </button>
                                            {currentUserId === rep.user_id && (
                                              <button onClick={() => deleteComment(rep.id)} className="hover:text-destructive text-muted-foreground transition">
                                                Delete
                                              </button>
                                            )}
                                            <EmojiReactionBar targetType="comment" targetId={rep.id} currentUserId={currentUserId} />
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          )}

                          {/* Inline Reply Form attached directly under this comment */}
                          {isReplyingThis && (
                            <div className="mt-2 ml-2 pl-3 border-l-2 border-orange-500 space-y-1.5 animate-in fade-in">
                              <div className="flex items-center justify-between text-[11px] px-2.5 py-1 rounded-lg bg-orange-500/10 text-orange-600 font-semibold">
                                <span className="flex items-center gap-1">
                                  <Reply className="h-3 w-3" /> Replying to @{replyingTo?.name}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setInlineReplyCommentId(null);
                                    setReplyingTo(null);
                                    setInlineReplyText('');
                                  }}
                                  className="hover:text-foreground font-bold p-0.5"
                                >
                                  <X className="h-3.5 w-3.5" />
                                </button>
                              </div>

                              <div className="flex gap-1.5 items-center">
                                <Input
                                  ref={inlineInputRef}
                                  placeholder={`Reply to @${replyingTo?.name}...`}
                                  value={inlineReplyText}
                                  onChange={e => setInlineReplyText(e.target.value)}
                                  onKeyDown={e => {
                                    if (e.key === 'Enter' && !e.shiftKey) {
                                      e.preventDefault();
                                      submitComment(undefined, c.id);
                                    }
                                  }}
                                  className="rounded-full bg-background h-8 text-xs flex-1"
                                />

                                <GifPickerPopover
                                  onSelectGif={(gifUrl) => {
                                    submitComment(gifUrl, c.id);
                                  }}
                                />

                                <Button
                                  size="sm"
                                  onClick={() => submitComment(undefined, c.id)}
                                  className="bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-full h-8 px-3 shrink-0"
                                >
                                  <Send className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Bottom Main Comment Composer */}
            {currentUserId && (
              <div className="space-y-1.5 pt-2 border-t border-border/40">
                <div className="flex gap-1.5 items-center">
                  <Input
                    ref={commentInputRef}
                    placeholder="Write a comment or add animated GIF / Sticker..."
                    value={commentText}
                    onChange={e => setCommentText(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submitComment(); } }}
                    className="rounded-full bg-background h-9 text-xs flex-1"
                  />

                  <GifPickerPopover
                    onSelectGif={(gifUrl) => {
                      submitComment(gifUrl);
                    }}
                  />

                  <Button size="sm" onClick={() => submitComment()} className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white rounded-full h-9 px-3 shrink-0">
                    <Send className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Dedicated Reply Thread Page Modal */}
        {activeThreadModalComment && (
          <Dialog open={!!activeThreadModalComment} onOpenChange={(open) => { if (!open) setActiveThreadModalComment(null); }}>
            <DialogContent className="max-w-md w-full p-4 max-h-[85vh] flex flex-col rounded-2xl">
              <div className="flex items-center justify-between pb-2 border-b border-border">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-orange-600" />
                  <h3 className="text-sm font-black text-foreground">Reply Thread</h3>
                </div>
              </div>

              {/* Root Parent Comment Highlight */}
              <div className="py-2 overflow-y-auto flex-1 space-y-3">
                <div className="p-3 rounded-xl bg-muted/40 border border-border/60">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src={activeThreadModalComment.author?.business_logo_url || activeThreadModalComment.author?.avatar_url} />
                      <AvatarFallback className="text-xs bg-orange-500 text-white font-bold">
                        {(activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'U')[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-xs font-bold text-foreground">
                        {activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'User'}
                      </div>
                      <div className="text-[10px] text-muted-foreground">{timeAgo(activeThreadModalComment.created_at)}</div>
                    </div>
                  </div>

                  {typeof activeThreadModalComment.content === 'string' && (activeThreadModalComment.content.match(/^https?:\/\/.*\.(gif|png|jpe?g|webp)(\?.*)?$/i) || activeThreadModalComment.content.includes('giphy.com/media')) ? (
                    <img loading="lazy" src={activeThreadModalComment.content} alt="Media" className="max-h-48 rounded-lg object-cover w-full mt-1" />
                  ) : (
                    <p className="text-xs text-foreground leading-relaxed">{activeThreadModalComment.content}</p>
                  )}

                  <div className="mt-2 pt-1 border-t border-border/40 flex items-center justify-between">
                    <EmojiReactionBar targetType="comment" targetId={activeThreadModalComment.id} currentUserId={currentUserId} />
                    {currentUserId === activeThreadModalComment.user_id && (
                      <button onClick={() => deleteComment(activeThreadModalComment.id)} className="text-[11px] text-destructive hover:underline">
                        Delete
                      </button>
                    )}
                  </div>
                </div>

                {/* List of all replies to this thread */}
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-muted-foreground px-1">
                    Replies ({(repliesByParent[activeThreadModalComment.id] || []).length})
                  </div>

                  {(repliesByParent[activeThreadModalComment.id] || []).map(rep => {
                    const rCn = rep.author?.business_name || rep.author?.display_name || 'User';
                    const rCa = rep.author?.business_logo_url || rep.author?.avatar_url;
                    const rIsMedia = typeof rep.content === 'string' && (
                      rep.content.match(/^https?:\/\/.*\.(gif|png|jpe?g|webp)(\?.*)?$/i) ||
                      rep.content.includes('giphy.com/media')
                    );

                    return (
                      <div key={rep.id} className="p-2.5 rounded-xl bg-background border border-border/50 flex gap-2 items-start">
                        <Avatar className="h-6 w-6 shrink-0 mt-0.5">
                          <AvatarImage src={rCa} />
                          <AvatarFallback className="text-[10px] bg-purple-600 text-white font-bold">{rCn[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-foreground truncate">{rCn}</span>
                            <span className="text-[10px] text-muted-foreground">{timeAgo(rep.created_at)}</span>
                          </div>
                          {rIsMedia ? (
                            <img loading="lazy" src={rep.content} alt="Reply media" className="max-h-36 rounded object-cover w-full mt-1" />
                          ) : (
                            <p className="text-xs text-foreground mt-0.5">{rep.content}</p>
                          )}
                          <div className="mt-1 flex items-center justify-between">
                            <EmojiReactionBar targetType="comment" targetId={rep.id} currentUserId={currentUserId} />
                            {currentUserId === rep.user_id && (
                              <button onClick={() => deleteComment(rep.id)} className="text-[10px] text-destructive hover:underline">
                                Delete
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  {(repliesByParent[activeThreadModalComment.id] || []).length === 0 && (
                    <p className="text-xs text-center text-muted-foreground py-4">No replies yet in this thread.</p>
                  )}
                </div>
              </div>

              {/* Dedicated Reply Form inside the Thread Modal */}
              <div className="pt-2 border-t border-border flex gap-1.5 items-center">
                <Input
                  placeholder={`Reply to ${activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'thread'}...`}
                  value={threadModalReplyText}
                  onChange={e => setThreadModalReplyText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      const parentAuthorName = activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'User';
                      const prefix = threadModalReplyText.startsWith(`@${parentAuthorName}`) ? '' : `@${parentAuthorName} `;
                      submitThreadModalReply(`${prefix}${threadModalReplyText}`);
                    }
                  }}
                  className="rounded-full bg-background h-9 text-xs flex-1"
                />

                <GifPickerPopover
                  onSelectGif={(gifUrl) => {
                    const parentAuthorName = activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'User';
                    submitThreadModalReply(`@${parentAuthorName} ${gifUrl}`);
                  }}
                />

                <Button
                  size="sm"
                  onClick={() => {
                    const parentAuthorName = activeThreadModalComment.author?.business_name || activeThreadModalComment.author?.display_name || 'User';
                    const prefix = threadModalReplyText.startsWith(`@${parentAuthorName}`) ? '' : `@${parentAuthorName} `;
                    submitThreadModalReply(`${prefix}${threadModalReplyText}`);
                  }}
                  className="bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-full h-9 px-3 shrink-0"
                >
                  <Send className="h-3.5 w-3.5" />
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
};

export default CommunityFeed;
