import React, { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Send, Search, ArrowLeft, User, MessageCircle, Copy, ExternalLink,
  CheckCircle2, Upload, Pin, Briefcase, Users, Globe, ShoppingBag, Store, Zap, Sparkles, X,
} from "lucide-react";
import { buildWhatsAppLink } from "@/lib/whatsapp";
import EmojiReactionBar from "@/components/EmojiReactionBar";
import { useFeatureToggles } from "@/hooks/useFeatureToggles";
import VoiceNoteRecorder from "@/components/chat/VoiceNoteRecorder";
import VoiceNotePlayer from "@/components/chat/VoiceNotePlayer";
import WhatsAppSlideMessage from "@/components/chat/WhatsAppSlideMessage";
import BusinessConnectMargin from "@/components/chat/BusinessConnectMargin";
import { playMessageReceivedSound, playMessageSentSound, playAttentionSound } from "@/utils/audio";
import { sendQuickMessageNotification, triggerRealtimePush } from "@/services/pushNotificationService";
import { notifyNewEnquiry } from "@/services/automatedEmailNotificationService";
import { CallButton } from "@/components/call/CallButton";
import { CallHistoryList } from "@/components/call/CallHistoryList";
import { EphemeralImageSender } from "@/components/chat/EphemeralImageSender";
import { EphemeralImageBubble } from "@/components/chat/EphemeralImageBubble";
import { MessageStatusIndicator } from "@/components/chat/MessageStatusIndicator";
import { StructuredChatMessage } from "@/components/chat/StructuredChatMessage";
import { getEphemeralImagesForPeer, EphemeralImageRecord } from "@/utils/ephemeralImageDB";
import { p2pImageTransfer } from "@/services/webrtcDataChannel";
import { Phone, PhoneCall } from "lucide-react";

type Kind = "text" | "proof" | "system" | "action" | "voice";

interface Msg {
  id: string;
  sender_id: string;
  receiver_id: string;
  task_id: string | null;
  assignment_id: string | null;
  kind: Kind;
  message: string | null;
  image_url: string | null;
  action_type: string | null;
  action_payload: any;
  is_read: boolean;
  created_at: string;
}

interface Thread {
  otherId: string;
  displayName: string;
  email?: string;
  avatarUrl?: string;
  lastMessage: string;
  lastAt: string;
  lastMessageSenderId?: string;
  lastMessageIsRead?: boolean;
  unread: number;
  taskId?: string | null;
  scope: "business" | "syndicate" | "global";
}


interface Profile {
  user_id: string;
  email?: string | null;
  display_name?: string | null;
  avatar_url?: string | null;
  business_name?: string | null;
  business_phone?: string | null;
  whatsapp_number?: string | null;
}

interface AssignmentMeta {
  id: string;
  task_id: string;
  syndicate_user_id: string;
  bank_name?: string | null;
  bank_account_name?: string | null;
  bank_account_number?: string | null;
  proof_url?: string | null;
  status: string;
}

const tabTitles = {
  business: "As a Business",
  syndicate: "As a Syndicate",
  global: "Global Network",
} as const;

const GGDInbox: React.FC = () => {
  const { isEnabled } = useFeatureToggles();
  const globalChatEnabled = isEnabled("global_network_chat");
  const [me, setMe] = useState<string>("");
  const [myProfile, setMyProfile] = useState<Profile | null>(null);
  const [inboxView, setInboxView] = useState<"messages" | "calls">("messages");
  const [ephemeralImages, setEphemeralImages] = useState<EphemeralImageRecord[]>([]);
  const [tab, setTab] = useState<"business" | "syndicate" | "global">("global");
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeOther, setActiveOther] = useState<string | null>(null);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [otherProfile, setOtherProfile] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [search, setSearch] = useState("");
  const [globalResults, setGlobalResults] = useState<Profile[]>([]);
  const [assignment, setAssignment] = useState<AssignmentMeta | null>(null);
  const [taskTitle, setTaskTitle] = useState<string>("");
  const [uploading, setUploading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Msg | null>(null);
  const sendingRef = useRef(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const [searchParams] = useSearchParams();
  const [activeInquiryTag, setActiveInquiryTag] = useState<{
    type: string;
    title: string;
    price?: string;
    id?: string;
    image_url?: string;
  } | null>(null);

  // Parse search params for direct seller chat or product inquiry
  useEffect(() => {
    const targetUid = searchParams.get("chatWith");
    const tType = searchParams.get("tagType");
    const tTitle = searchParams.get("tagTitle");
    const tPrice = searchParams.get("tagPrice");
    const tId = searchParams.get("tagId");
    const tImg = searchParams.get("tagImage");

    if (tType && tTitle) {
      setActiveInquiryTag({
        type: tType,
        title: tTitle,
        price: tPrice || undefined,
        id: tId || undefined,
        image_url: tImg || undefined,
      });
      setInput(
        `Hello! I would like to inquire about your ${
          tType === "service" ? "service" : "product"
        } "${tTitle}"${tPrice ? ` (₦${Number(tPrice).toLocaleString()})` : ""}. Is this available?`
      );
    }

    if (targetUid && me && targetUid !== me) {
      openThread(targetUid, null);
    }
  }, [searchParams, me]);

  // ---- Init & load threads ----
  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      setMe(data.user.id);
      
      const { data: myProf } = await supabase
        .from("profiles")
        .select("user_id, email, display_name, avatar_url, business_name")
        .eq("user_id", data.user.id)
        .maybeSingle();
      if (myProf) setMyProfile(myProf as Profile);

      await loadThreads(data.user.id);
    })();
  }, []);

  // Realtime subscription for the current user (handles both new messages and seen/read updates)
  useEffect(() => {
    if (!me) return;
    const ch = supabase
      .channel(`inbox-${me}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "p2p_messages" }, (payload) => {
        if (payload.eventType === "INSERT") {
          const m = payload.new as Msg;
          if (m.sender_id !== me && m.receiver_id !== me) return;

          // Trigger audio chime & notification if message is addressed to me
          if (m.receiver_id === me && m.sender_id !== me) {
            playMessageReceivedSound();
            if ('vibrate' in navigator) {
              try { navigator.vibrate([30, 50, 30]); } catch {}
            }
            const preview = m.kind === "voice" ? "🎤 Sent you a voice note" : (m.message?.slice(0, 75) || "New attachment received");
            toast.info("💬 New Message", {
              description: preview,
            });
          }

          if (activeOther && (m.sender_id === activeOther || m.receiver_id === activeOther)) {
            setMessages((prev) => {
              // If already present by real DB id, ignore
              if (prev.some((x) => x.id === m.id)) return prev;

              // If we sent this, replace any matching optimistic tmp- message
              if (m.sender_id === me) {
                const tmpIdx = prev.findIndex(
                  (x) =>
                    x.id.startsWith("tmp-") &&
                    x.sender_id === m.sender_id &&
                    (x.message === m.message || (m.kind === "voice" && x.kind === "voice"))
                );
                if (tmpIdx !== -1) {
                  const next = [...prev];
                  next[tmpIdx] = m;
                  return next;
                }
              }

              return [...prev, m];
            });
            if (m.receiver_id === me) {
              supabase.from("p2p_messages").update({ is_read: true }).eq("id", m.id);
            }
          }
          loadThreads(me);
        } else if (payload.eventType === "UPDATE") {
          const updated = payload.new as Msg;
          if (updated.sender_id === me || updated.receiver_id === me) {
            setMessages((prev) =>
              prev.map((m) => (m.id === updated.id ? { ...m, is_read: updated.is_read } : m))
            );
            loadThreads(me);
          }
        }
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [me, activeOther]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const loadThreads = async (uid: string) => {
    const { data } = await supabase
      .from("p2p_messages")
      .select("*")
      .or(`sender_id.eq.${uid},receiver_id.eq.${uid}`)
      .order("created_at", { ascending: false })
      .limit(300);
    const map = new Map<string, Msg>();
    (data || []).forEach((m: any) => {
      const other = m.sender_id === uid ? m.receiver_id : m.sender_id;
      const key = `${other}:${m.task_id || ""}`;
      if (!map.has(key)) map.set(key, m);
    });
    const otherIds = Array.from(new Set(Array.from(map.values()).map((m) => (m.sender_id === uid ? m.receiver_id : m.sender_id))));
    let profileMap = new Map<string, Profile>();
    if (otherIds.length > 0) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("user_id, email, display_name, avatar_url, business_name")
        .in("user_id", otherIds);
      (profs || []).forEach((p: any) => profileMap.set(p.user_id, p));
    }

    // Classify: is `other` a business owner of the task, or syndicate?
    const taskIds = Array.from(new Set(Array.from(map.values()).map((m) => m.task_id).filter(Boolean))) as string[];
    let creatorByTask = new Map<string, string>();
    if (taskIds.length > 0) {
      const { data: ts } = await supabase.from("tasks").select("id, creator_id, title").in("id", taskIds);
      (ts || []).forEach((t: any) => creatorByTask.set(t.id, t.creator_id));
      const { data: sts } = await supabase.from("syndicate_tasks").select("id, creator_id, title").in("id", taskIds);
      (sts || []).forEach((t: any) => creatorByTask.set(t.id, t.creator_id));
    }

    // Unread counts per other
    const { data: unread } = await supabase
      .from("p2p_messages")
      .select("sender_id")
      .eq("receiver_id", uid)
      .eq("is_read", false);
    const unreadByOther = new Map<string, number>();
    (unread || []).forEach((u: any) => unreadByOther.set(u.sender_id, (unreadByOther.get(u.sender_id) || 0) + 1));

    const built: Thread[] = [];
    for (const [key, m] of map.entries()) {
      const other = m.sender_id === uid ? m.receiver_id : m.sender_id;
      const prof = profileMap.get(other);
      const creator = m.task_id ? creatorByTask.get(m.task_id) : null;
      let scope: Thread["scope"] = "global";
      if (creator) scope = creator === uid ? "business" : "syndicate";
      built.push({
        otherId: other,
        displayName: prof?.business_name || prof?.display_name || prof?.email?.split("@")[0] || "Member",
        email: prof?.email || undefined,
        avatarUrl: prof?.avatar_url || undefined,
        lastMessage: m.kind === "proof" ? "📎 Proof screenshot" : m.message || "",
        lastAt: m.created_at,
        lastMessageSenderId: m.sender_id,
        lastMessageIsRead: m.is_read,
        unread: unreadByOther.get(other) || 0,
        taskId: m.task_id,
        scope,
      });
    }


    // If chatWith was provided via searchParams, ensure it appears in thread list
    const targetUid = searchParams.get("chatWith");
    if (targetUid && targetUid !== uid && !built.some((t) => t.otherId === targetUid)) {
      const { data: targetProf } = await supabase
        .from("profiles")
        .select("user_id, email, display_name, avatar_url, business_name")
        .eq("user_id", targetUid)
        .maybeSingle();
      if (targetProf) {
        built.unshift({
          otherId: targetUid,
          displayName: (targetProf as any).business_name || (targetProf as any).display_name || "Business Member",
          email: (targetProf as any).email || undefined,
          avatarUrl: (targetProf as any).avatar_url || undefined,
          lastMessage: "Product / Business Inquiry",
          lastAt: new Date().toISOString(),
          unread: 0,
          taskId: null,
          scope: "business",
        });
      }
    }

    setThreads(built);
  };

  // ---- Global network search ----
  useEffect(() => {
    if (tab !== "global" || !search.trim()) { setGlobalResults([]); return; }
    const q = search.trim();
    const t = setTimeout(async () => {
      const { data } = await supabase
        .from("profiles")
        .select("user_id, email, display_name, avatar_url, business_name")
        .or(`display_name.ilike.%${q}%,email.ilike.%${q}%,business_name.ilike.%${q}%`)
        .limit(20);
      setGlobalResults((data || []).filter((p: any) => p.user_id !== me));
    }, 250);
    return () => clearTimeout(t);
  }, [search, tab, me]);

  // ---- Open conversation ----
  const openThread = async (otherId: string, taskId?: string | null) => {
    setActiveOther(otherId);
    setActiveTaskId(taskId || null);
    setAssignment(null);
    setTaskTitle("");

    const { data: prof } = await supabase
      .from("profiles")
      .select("user_id, email, display_name, avatar_url, business_name, business_phone, whatsapp_number")
      .eq("user_id", otherId)
      .maybeSingle();
    setOtherProfile((prof as any) || null);

    // Load ephemeral peer images from local IndexedDB (zero cloud storage)
    try {
      const p2pImgs = await getEphemeralImagesForPeer(otherId);
      setEphemeralImages(p2pImgs);
    } catch (e) {
      console.warn("Could not load ephemeral images:", e);
    }

    let msgQuery = supabase
      .from("p2p_messages")
      .select("*")
      .or(`and(sender_id.eq.${me},receiver_id.eq.${otherId}),and(sender_id.eq.${otherId},receiver_id.eq.${me})`)
      .order("created_at", { ascending: true });
    if (taskId) msgQuery = msgQuery.eq("task_id", taskId);
    const { data: msgs } = await msgQuery;
    setMessages((msgs as any) || []);

    // Mark unread as read
    await supabase
      .from("p2p_messages")
      .update({ is_read: true })
      .eq("sender_id", otherId)
      .eq("receiver_id", me)
      .eq("is_read", false);

    if (taskId) {
      // Load task title
      const { data: t1 } = await supabase.from("tasks").select("title, creator_id").eq("id", taskId).maybeSingle();
      const { data: t2 } = t1 ? { data: null } : await supabase.from("syndicate_tasks").select("title, creator_id").eq("id", taskId).maybeSingle();
      const t = t1 || t2;
      setTaskTitle((t as any)?.title || "");

      // Load latest assignment for this task+syndicate (works whether viewer is biz or syndicate)
      const syndicateId = (t as any)?.creator_id === me ? otherId : me;
      const { data: a } = await supabase
        .from("syndicate_task_assignments")
        .select("id, task_id, syndicate_user_id, proof_url, status")
        .eq("task_id", taskId)
        .eq("syndicate_user_id", syndicateId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      setAssignment((a as any) || null);
    }
  };

  const closeThread = () => {
    setActiveOther(null);
    setActiveTaskId(null);
    setOtherProfile(null);
    setMessages([]);
    setAssignment(null);
    setEphemeralImages([]);
  };

  // Real-time listener for incoming P2P images
  useEffect(() => {
    if (!activeOther) return;
    const unsub = p2pImageTransfer.onImageReceived((record) => {
      if (record.peerId === activeOther || record.senderId === activeOther) {
        setEphemeralImages((prev) => [record, ...prev.filter((x) => x.id !== record.id)]);
      }
    });
    return () => unsub();
  }, [activeOther]);

  // ---- Send text ----
  const send = async () => {
    const text = input.trim();
    if (!text || !activeOther || isSending || sendingRef.current) return;
    sendingRef.current = true;
    setIsSending(true);
    setInput("");
    playMessageSentSound();

    const currentTag = activeInquiryTag;
    const currentReply = replyingTo;
    const isTag = !!currentTag;
    const kind: Kind = isTag ? "action" : "text";
    const action_type = isTag
      ? (currentTag.type === "service" ? "service_inquiry" : "product_inquiry")
      : (currentReply ? "reply" : null);
    const action_payload: any = {};
    if (isTag) Object.assign(action_payload, currentTag);
    if (currentReply) {
      action_payload.reply_to = {
        id: currentReply.id,
        message: currentReply.message,
        sender_id: currentReply.sender_id,
        kind: currentReply.kind,
      };
    }

    const optimisticId = `tmp-${Date.now()}`;
    const optimistic: any = {
      id: optimisticId,
      sender_id: me,
      receiver_id: activeOther,
      task_id: activeTaskId,
      assignment_id: null,
      kind,
      message: text,
      image_url: null,
      action_type,
      action_payload: Object.keys(action_payload).length > 0 ? action_payload : null,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    setMessages((p) => [...p, optimistic]);
    setActiveInquiryTag(null);
    setReplyingTo(null);

    try {
      const { data, error } = await supabase
        .from("p2p_messages")
        .insert({
          sender_id: me,
          receiver_id: activeOther,
          task_id: activeTaskId,
          kind,
          message: text,
          action_type,
          action_payload: Object.keys(action_payload).length > 0 ? action_payload : null,
        })
        .select()
        .maybeSingle();

      if (error) {
        toast.error("Failed to send message");
        setMessages((p) => p.filter((x) => x.id !== optimisticId));
      } else if (data) {
        setMessages((prev) => prev.map((msg) => (msg.id === optimisticId ? (data as any) : msg)));
        
        // Dispatch quick message push notification & automated email to recipient
        sendQuickMessageNotification({
          recipientUserId: activeOther,
          senderName: myProfile?.display_name || 'GGD Member',
          messagePreview: text,
          chatUrl: `/inbox?chat=${me}`,
        });

        // Trigger automated email notification for enquiry/message
        notifyNewEnquiry({
          recipientUserId: activeOther,
          businessName: otherProfile?.business_name,
          recipientName: otherProfile?.display_name || otherProfile?.business_name,
          senderUserId: me,
          senderName: myProfile?.display_name || myProfile?.business_name || 'GGD Member',
          senderEmail: myProfile?.email,
          messageText: text,
          enquiryType: isTag ? (currentTag?.type === 'service' ? 'service_inquiry' : 'product_inquiry') : 'general',
          itemTitle: currentTag?.title || undefined,
          itemPrice: currentTag?.price || undefined,
          chatUrl: `/inbox?chat=${me}`,
        }).catch((err) => console.warn('Automated enquiry email dispatch note:', err));
      }
    } catch (err) {
      toast.error("Network error sending message");
      setMessages((p) => p.filter((x) => x.id !== optimisticId));
    } finally {
      sendingRef.current = false;
      setIsSending(false);
    }
  };

  // ---- Send 1-Tap Attention Prompt ----
  const sendAttentionRequest = async (promptText: string, label?: string) => {
    if (!activeOther || isSending || sendingRef.current) return;
    playAttentionSound();

    const optimisticId = `tmp-${Date.now()}`;
    const action_payload = { label: label || "Attention Prompt", urgent: true };
    const optimistic: any = {
      id: optimisticId,
      sender_id: me,
      receiver_id: activeOther,
      task_id: activeTaskId,
      assignment_id: null,
      kind: "action",
      message: promptText,
      image_url: null,
      action_type: "attention_prompt",
      action_payload,
      is_read: false,
      created_at: new Date().toISOString(),
    };
    setMessages((p) => [...p, optimistic]);

    try {
      const { data, error } = await supabase
        .from("p2p_messages")
        .insert({
          sender_id: me,
          receiver_id: activeOther,
          task_id: activeTaskId,
          kind: "action",
          message: promptText,
          action_type: "attention_prompt",
          action_payload,
        })
        .select()
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setMessages((prev) => prev.map((m) => (m.id === optimisticId ? (data as any) : m)));
      }

      // Dispatch urgent attention notification
      await supabase.from("notifications").insert({
        user_id: activeOther,
        title: `🚨 Urgent Attention Needed`,
        message: promptText,
        type: "urgent_message",
        nav_target: "inbox",
        is_read: false,
      });

      toast.success("🔔 Attention request sent to recipient!");
    } catch (err) {
      toast.error("Failed to send prompt");
      setMessages((p) => p.filter((x) => x.id !== optimisticId));
    }
  };

  // ---- Retain Voice Note in Chat ----
  const sendVoiceNote = async (audioDataUrl: string, durationSeconds: number) => {
    if (!activeOther || isSending || sendingRef.current) return;
    sendingRef.current = true;
    setIsSending(true);

    const optimisticId = `tmp-${Date.now()}`;
    const optimistic: any = {
      id: optimisticId,
      sender_id: me,
      receiver_id: activeOther,
      task_id: activeTaskId,
      assignment_id: null,
      kind: "voice",
      message: "Voice Note",
      image_url: audioDataUrl,
      action_type: "voice_note",
      action_payload: { audio_url: audioDataUrl, duration: durationSeconds },
      is_read: false,
      created_at: new Date().toISOString(),
    };
    setMessages((p) => [...p, optimistic]);

    try {
      const { data, error } = await supabase
        .from("p2p_messages")
        .insert({
          sender_id: me,
          receiver_id: activeOther,
          task_id: activeTaskId,
          kind: "voice",
          message: "Voice Note",
          image_url: audioDataUrl,
          action_type: "voice_note",
          action_payload: { audio_url: audioDataUrl, duration: durationSeconds },
        })
        .select()
        .maybeSingle();

      if (error) {
        toast.error("Failed to send voice note");
        setMessages((p) => p.filter((x) => x.id !== optimisticId));
      } else if (data) {
        setMessages((prev) => prev.map((msg) => (msg.id === optimisticId ? (data as any) : msg)));
        
        sendQuickMessageNotification({
          recipientUserId: activeOther,
          senderName: myProfile?.display_name || 'GGD Member',
          messagePreview: '🎙️ Voice note received',
          chatUrl: `/inbox?chat=${me}`,
        });
      }
    } catch (err) {
      toast.error("Network error sending voice note");
      setMessages((p) => p.filter((x) => x.id !== optimisticId));
    } finally {
      sendingRef.current = false;
      setIsSending(false);
    }
  };

  // ---- Upload proof screenshot & embed into chat ----
  const uploadProof = async (file: File) => {
    if (!activeOther || !activeTaskId) {
      toast.error("Open a task chat before uploading proof");
      return;
    }
    setUploading(true);
    try {
      const path = `${me}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.]/g, "_")}`;
      const { data, error } = await supabase.storage.from("syndicate-proofs").upload(path, file, { upsert: false });
      if (error) throw error;
      const { data: pub } = supabase.storage.from("syndicate-proofs").getPublicUrl(data.path);
      const proofUrl = pub.publicUrl;

      // Update the assignment record with proof if we own one
      if (assignment) {
        await supabase
          .from("syndicate_task_assignments")
          .update({ proof_url: proofUrl, status: "submitted" })
          .eq("id", assignment.id);
      }
      // Inject the proof screenshot as a system-generated chat message
      await supabase.from("p2p_messages").insert({
        sender_id: me,
        receiver_id: activeOther,
        task_id: activeTaskId,
        assignment_id: assignment?.id || null,
        kind: "proof",
        message: "Task proof submitted",
        image_url: proofUrl,
        action_type: "approve_pay",
        action_payload: { assignment_id: assignment?.id || null, task_title: taskTitle },
      });
      toast.success("Proof sent");
      if (activeTaskId) openThread(activeOther, activeTaskId);
    } catch (e: any) {
      toast.error(e.message || "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  // ---- Approve & Pay flow (business owner clicks it) ----
  const approveAndPay = async (m: Msg) => {
    const asgId = m.action_payload?.assignment_id || assignment?.id;
    if (!asgId) { toast.error("Missing assignment reference"); return; }
    const { error } = await supabase
      .from("syndicate_task_assignments")
      .update({ status: "approved", paid_at: new Date().toISOString(), paid_by: me })
      .eq("id", asgId);
    if (error) { toast.error(error.message); return; }
    toast.success("Approved. Payment marked complete.");
    await supabase.from("p2p_messages").insert({
      sender_id: me, receiver_id: activeOther!, task_id: activeTaskId,
      kind: "system", message: `✅ ${taskTitle || "Task"} approved & payment marked complete`,
    });
  };

  // ---- Unified Global Network conversations (Single source of truth) ----
  const shownThreads = useMemo(() => {
    if (!search.trim()) return threads;
    const q = search.toLowerCase().trim();
    return threads.filter(
      (t) =>
        t.displayName.toLowerCase().includes(q) ||
        (t.email && t.email.toLowerCase().includes(q)) ||
        t.lastMessage.toLowerCase().includes(q)
    );
  }, [threads, search]);

  // ---- Pinned metadata (only for Business viewer + when proof submitted) ----
  const iAmBusinessInThisTask = tab === "business" || (assignment && assignment.syndicate_user_id !== me);
  const showBankDetails = !!(iAmBusinessInThisTask && assignment?.proof_url && assignment?.bank_account_number);
  const waLink = otherProfile ? buildWhatsAppLink(otherProfile.whatsapp_number || otherProfile.business_phone, { taskName: taskTitle }) : null;

  const copy = async (text: string, label = "Copied") => {
    try { await navigator.clipboard.writeText(text); toast.success(label); }
    catch { toast.error("Copy failed"); }
  };

  // ================= UI =================
  if (activeOther) {
    return (
      <Card className="h-[calc(100vh-8rem)] flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-3 p-3 border-b bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-t-lg">
          <button onClick={closeThread} className="hover:bg-white/20 p-1.5 rounded-lg transition"><ArrowLeft className="h-5 w-5" /></button>
          <a
            href={`/user/${activeOther}`}
            target="_blank"
            rel="noopener noreferrer"
            className="h-9 w-9 rounded-full bg-white/20 flex items-center justify-center overflow-hidden shrink-0 hover:ring-2 hover:ring-white transition"
            title="View User / Business Profile"
          >
            {otherProfile?.avatar_url ? <img loading="lazy" src={otherProfile.avatar_url} className="h-full w-full object-cover" /> : <User className="h-4 w-4" />}
          </a>
          <a
            href={`/user/${activeOther}`}
            target="_blank"
            rel="noopener noreferrer"
            className="min-w-0 flex-1 hover:opacity-90 transition block"
            title="Open Business Website & Public Storefront"
          >
            <p className="font-bold text-sm truncate flex items-center gap-1.5">
              <span>{otherProfile?.business_name || otherProfile?.display_name || "Member"}</span>
              <ExternalLink className="h-3 w-3 opacity-70" />
            </p>
            {taskTitle && <p className="text-[10px] text-orange-100 truncate">{taskTitle}</p>}
          </a>

          {/* Quick Business Site / Storefront Button */}
          <a
            href={`/user/${activeOther}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white border border-white/30 text-xs font-bold transition shadow-xs shrink-0"
            title="Open Business Website & Public Storefront"
          >
            <Store className="h-3.5 w-3.5 text-amber-300" />
            <span className="hidden sm:inline">Business Site</span>
            <ExternalLink className="h-3 w-3 opacity-80" />
          </a>

          {/* WebRTC Live Audio & Video Call Buttons */}
          <div className="flex items-center gap-1.5 shrink-0">
            <CallButton
              calleeId={activeOther}
              calleeName={otherProfile?.business_name || otherProfile?.display_name || "Member"}
              calleeAvatar={otherProfile?.avatar_url || undefined}
              callType="audio"
              className="h-8 w-8 bg-white/15 hover:bg-white/30 text-white border-white/20 shadow-xs"
            />
            <CallButton
              calleeId={activeOther}
              calleeName={otherProfile?.business_name || otherProfile?.display_name || "Member"}
              calleeAvatar={otherProfile?.avatar_url || undefined}
              callType="video"
              className="h-8 w-8 bg-white/15 hover:bg-white/30 text-white border-white/20 shadow-xs"
            />
          </div>
        </div>

        {/* Pinned Metadata Box */}
        {activeTaskId && (
          <div className="border-b bg-muted/30 px-3 py-2">
            <div className="flex items-center gap-1 text-[10px] font-bold uppercase text-muted-foreground mb-1">
              <Pin className="h-3 w-3" /> Task Metadata
            </div>
            {showBankDetails ? (
              <div className="space-y-1 text-xs">
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span><b>Bank:</b> {assignment!.bank_name}</span>
                  <span><b>Name:</b> {assignment!.bank_account_name}</span>
                  <span className="font-mono"><b>#:</b> {assignment!.bank_account_number}</span>
                  <Button size="sm" variant="outline" className="h-6 text-[10px] ml-auto"
                    onClick={() => copy(assignment!.bank_account_number!, "Account number copied")}>
                    <Copy className="h-3 w-3 mr-1" /> Copy Account Number
                  </Button>
                </div>
                {waLink && (
                  <a href={waLink} target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] text-green-600 hover:underline">
                    <ExternalLink className="h-3 w-3" /> WhatsApp Chat
                  </a>
                )}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground italic">Awaiting Task Submission</p>
            )}
          </div>
        )}

        {/* Mobile Business Connect Margin Banner */}
        <div className="px-3 pt-2 lg:hidden">
          <BusinessConnectMargin
            businessUserId={activeOther}
            isCompact
            onApplyPrompt={(txt) => setInput(txt)}
            onSendAttentionPrompt={sendAttentionRequest}
          />
        </div>

        {/* Main Content Area with Desktop Business Connect Margin */}
        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 flex flex-col min-w-0">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2 bg-muted/10">
              {/* P2P Ephemeral Real-time Images */}
              {ephemeralImages.length > 0 && (
                <div className="space-y-2 pb-3 mb-2 border-b border-dashed border-amber-500/30">
                  <div className="flex items-center justify-between px-1 text-xs">
                    <span className="flex items-center gap-1.5 font-bold text-amber-600 dark:text-amber-400">
                      <Sparkles className="h-3.5 w-3.5" />
                      Real-time Ephemeral Images ({ephemeralImages.length})
                    </span>
                    <Badge variant="outline" className="text-[10px] text-amber-600 border-amber-500/40 bg-amber-500/10">
                      P2P DataChannel • 24h Expiry
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ephemeralImages.map((img) => (
                      <EphemeralImageBubble
                        key={img.id}
                        image={img}
                        onDeleted={(id) => setEphemeralImages((p) => p.filter((x) => x.id !== id))}
                      />
                    ))}
                  </div>
                </div>
              )}

              {messages.length === 0 && ephemeralImages.length === 0 && (
                <div className="text-center py-10 space-y-2">
                  <MessageCircle className="h-10 w-10 text-muted-foreground/30 mx-auto" />
                  <p className="text-xs font-semibold text-foreground">Say hello — start the conversation.</p>
                  <p className="text-[11px] text-muted-foreground max-w-xs mx-auto">
                    Check the recommendations above or type a message below.
                  </p>
                </div>
              )}
              {messages.map((m) => {
                const mine = m.sender_id === me;
                if (m.kind === "system") {
                  return (
                    <div key={m.id} className="text-center">
                      <span className="inline-block text-[10px] bg-muted rounded-full px-2 py-0.5 text-muted-foreground">
                        {m.message}
                      </span>
                    </div>
                  );
                }
                return (
                  <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[85%] sm:max-w-[78%] flex flex-col ${mine ? "items-end" : "items-start"}`}>
                      <WhatsAppSlideMessage
                        messageId={m.id}
                        currentUserId={me}
                        isMine={mine}
                        onReply={() => setReplyingTo(m)}
                      >
                        <div className={`rounded-2xl px-3 py-2 text-sm shadow-xs ${mine ? "bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-br-sm" : "bg-card border border-border/80 rounded-bl-sm"}`}>
                          {/* Quoted reply banner if this message is replying to another */}
                          {m.action_payload?.reply_to && (
                            <div className={`mb-2 p-1.5 px-2.5 rounded-lg text-xs border-l-3 ${mine ? 'bg-black/20 border-white text-white/95' : 'bg-muted border-orange-500 text-foreground'}`}>
                              <p className="text-[10px] font-black uppercase tracking-wider opacity-85">
                                {m.action_payload.reply_to.sender_id === me ? 'You' : (otherProfile?.display_name || otherProfile?.business_name || 'Contact')}
                              </p>
                              <p className="truncate text-xs mt-0.5 font-medium">
                                {m.action_payload.reply_to.message || (m.action_payload.reply_to.kind === 'voice' ? '🎤 Voice Note' : '📎 Attachment')}
                              </p>
                            </div>
                          )}

                          {/* Attention request prompt banner */}
                          {m.action_type === "attention_prompt" && (
                            <div className={`mb-2 p-2 rounded-xl border text-xs flex items-center gap-2 ${mine ? "bg-white/20 border-white/30 text-white" : "bg-amber-500/15 border-amber-500/30 text-amber-900 dark:text-amber-100"}`}>
                              <Sparkles className="h-4 w-4 text-amber-400 shrink-0" />
                              <div className="min-w-0 flex-1">
                                <span className="font-extrabold text-[10px] uppercase tracking-wider block">
                                  🚨 Attention Request
                                </span>
                                <span className="text-xs font-semibold">{m.action_payload?.label || "Direct Question"}</span>
                              </div>
                            </div>
                          )}

                          {/* Tagged product or service inquiry banner */}
                          {(m.action_type === "product_inquiry" || m.action_type === "service_inquiry" || m.action_payload?.title) && (
                            <div className={`mb-2 p-2.5 rounded-xl border text-xs flex items-center gap-2.5 ${mine ? "bg-white/15 border-white/25 text-white" : "bg-orange-500/10 border-orange-500/20 text-foreground"}`}>
                              {m.action_payload?.image_url && (
                                <img src={m.action_payload.image_url} alt="" className="h-11 w-11 rounded-lg object-cover flex-shrink-0 border border-white/20" />
                              )}
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${m.action_type === "service_inquiry" || m.action_payload?.type === 'service' ? "bg-blue-600 text-white" : "bg-emerald-600 text-white"}`}>
                                    {m.action_type === "service_inquiry" || m.action_payload?.type === 'service' ? "⚡ Service Inquiry" : "🛍️ Product Inquiry"}
                                  </span>
                                  <span className="font-bold truncate text-xs">{m.action_payload?.title || "Item Inquiry"}</span>
                                </div>
                                {m.action_payload?.price && (
                                  <p className={`font-black text-xs mt-0.5 ${mine ? "text-white font-extrabold" : "text-orange-600 font-bold"}`}>
                                    ₦{Number(m.action_payload.price).toLocaleString()}
                                  </p>
                                )}
                              </div>
                              {m.action_payload?.id && (
                                <button
                                  type="button"
                                  className={`h-7 px-2.5 text-[10px] font-bold rounded-lg flex items-center gap-1 transition-colors ${mine ? "bg-white/20 hover:bg-white/30 text-white border border-white/40" : "bg-card border border-orange-500/30 text-orange-600 hover:bg-orange-500/10"}`}
                                  onClick={() => window.open(`/product/${m.action_payload.id}`, "_blank")}
                                >
                                  <ExternalLink className="h-3 w-3" /> View
                                </button>
                              )}
                            </div>
                          )}

                          {/* Voice Note Player */}
                          {m.kind === "voice" && (
                            <div className="mb-1 min-w-[210px]">
                              <VoiceNotePlayer
                                src={m.action_payload?.audio_url || m.image_url || ''}
                                duration={m.action_payload?.duration || 0}
                                isMine={mine}
                              />
                            </div>
                          )}

                          {m.image_url && m.kind !== "voice" && (
                            <a href={m.image_url} target="_blank" rel="noreferrer" className="block mb-1">
                              <img loading="lazy" src={m.image_url} alt="proof" className="rounded-lg max-h-64 object-cover" />
                            </a>
                          )}

                          {m.message && m.kind !== "voice" && (
                            <StructuredChatMessage text={m.message} isMine={mine} />
                          )}

                          {/* Approve & Pay action button — only for the receiver (business owner) */}
                          {m.kind === "proof" && m.action_type === "approve_pay" && !mine && (
                            <Button
                              size="sm"
                              onClick={() => approveAndPay(m)}
                              className="mt-2 h-8 bg-green-500 hover:bg-green-600 text-white text-xs"
                            >
                              <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Approve & Pay
                            </Button>
                          )}
                          <div className={`mt-1 flex items-center justify-end ${mine ? "text-orange-100" : "text-muted-foreground"}`}>
                            {mine ? (
                              <MessageStatusIndicator
                                status={m.id.startsWith("tmp-") ? "sending" : m.is_read ? "seen" : "sent"}
                                timestamp={m.created_at}
                                variant="on-gradient"
                                size="xs"
                              />
                            ) : (
                              <span className="text-[9px]">
                                {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                              </span>
                            )}
                          </div>
                        </div>
                      </WhatsAppSlideMessage>
                    </div>
                  </div>
                );
              })}
              <div ref={endRef} />
            </div>

            {/* Composer */}
            <div className="p-2 border-t bg-background space-y-2">
              {/* Replying-to Preview Bar */}
              {replyingTo && (
                <div className="p-2 px-3 rounded-xl bg-muted border-l-4 border-orange-500 flex items-center justify-between gap-2 animate-in fade-in slide-in-from-bottom-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] font-bold text-orange-600">
                      Replying to {replyingTo.sender_id === me ? 'yourself' : (otherProfile?.display_name || otherProfile?.business_name || 'contact')}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {replyingTo.message || (replyingTo.kind === 'voice' ? '🎤 Voice Note' : '📎 Attachment')}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setReplyingTo(null)}
                    className="h-6 w-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted-foreground/10 shrink-0"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              {activeInquiryTag && (
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-500/30 flex items-center gap-2.5">
                  {activeInquiryTag.image_url && (
                    <img src={activeInquiryTag.image_url} alt="" className="h-10 w-10 rounded-lg object-cover border flex-shrink-0" />
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Badge className={`text-[9px] font-black uppercase px-1.5 py-0 border-0 ${activeInquiryTag.type === 'service' ? 'bg-blue-600 text-white' : 'bg-emerald-600 text-white'}`}>
                        {activeInquiryTag.type === 'service' ? '⚡ Tagged Service' : '🛍️ Tagged Product'}
                      </Badge>
                      <span className="font-bold text-xs truncate text-foreground">{activeInquiryTag.title}</span>
                    </div>
                    {activeInquiryTag.price && (
                      <p className="text-xs font-black text-orange-600 mt-0.5">₦{Number(activeInquiryTag.price).toLocaleString()}</p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveInquiryTag(null)}
                    className="h-6 w-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted"
                    title="Remove Tag"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              <div className="flex gap-2 items-center">
                {activeTaskId && (
                  <>
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadProof(f); e.currentTarget.value = ""; }}
                    />
                    <Button
                      variant="outline" size="icon"
                      disabled={uploading}
                      onClick={() => fileRef.current?.click()}
                      title="Upload proof screenshot"
                    >
                      <Upload className="h-4 w-4" />
                    </Button>
                  </>
                )}

                <VoiceNoteRecorder onSendVoice={sendVoiceNote} disabled={isSending} />

                <EphemeralImageSender
                  currentUserId={me}
                  recipientUserId={activeOther}
                  recipientUserName={otherProfile?.business_name || otherProfile?.display_name || "Contact"}
                  onImageSent={(rec) => setEphemeralImages((prev) => [rec, ...prev.filter((x) => x.id !== rec.id)])}
                  disabled={isSending}
                />

                <Input
                  value={input}
                  disabled={isSending}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && !isSending && (e.preventDefault(), send())}
                  placeholder={replyingTo ? "Type your reply..." : "Type a message..."}
                  className="flex-1"
                />
                <Button
                  onClick={send}
                  disabled={isSending || !input.trim()}
                  size="icon"
                  className="bg-orange-500 hover:bg-orange-600 shrink-0"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Desktop Right Margin: Business Connect Margin */}
          <div className="w-80 border-l p-3.5 overflow-y-auto hidden lg:block bg-card/30">
            <BusinessConnectMargin
              businessUserId={activeOther}
              onApplyPrompt={(txt) => setInput(txt)}
              onSendAttentionPrompt={sendAttentionRequest}
            />
          </div>
        </div>
      </Card>
    );
  }

  // Inbox list view
  return (
    <div className="space-y-4">
      {/* Header with Global Network & Call History Toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1 border-b">
        <div className="flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-xl bg-orange-500/10 text-orange-600 flex items-center justify-center font-bold">
            <Globe className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-black tracking-tight flex items-center gap-2">
              <span>Global Network Hub</span>
              <Badge variant="outline" className="text-[10px] text-orange-600 border-orange-500/30">
                Single Source of Truth
              </Badge>
            </h2>
            <p className="text-xs text-muted-foreground">
              Peer-to-peer conversations, calls & ephemeral image sharing
            </p>
          </div>
        </div>

        {/* View Switcher: Global Network Messages vs Call History */}
        <div className="flex items-center bg-muted/60 p-1 rounded-xl border">
          <button
            type="button"
            onClick={() => setInboxView("messages")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              inboxView === "messages"
                ? "bg-background text-foreground shadow-xs"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <MessageCircle className="h-3.5 w-3.5 text-orange-500" />
            <span>Messages ({threads.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setInboxView("calls")}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              inboxView === "calls"
                ? "bg-background text-foreground shadow-xs"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <PhoneCall className="h-3.5 w-3.5 text-emerald-500" />
            <span>Call History</span>
          </button>
        </div>
      </div>

      {inboxView === "calls" ? (
        <CallHistoryList
          userId={me}
        />
      ) : (
        <div className="space-y-3">
          {/* Global Network Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search Global Network by member, business, or recent message…"
              className="pl-9 h-11 rounded-xl"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {search && (
            <Card className="rounded-xl border-dashed">
              <CardContent className="p-0 divide-y">
                {globalResults.length === 0 ? (
                  <p className="p-4 text-xs text-muted-foreground text-center">
                    No new members found matching "{search}"
                  </p>
                ) : (
                  globalResults.map((p) => (
                    <button
                      key={p.user_id}
                      onClick={() => openThread(p.user_id, null)}
                      className="w-full text-left flex items-center gap-3 p-3 hover:bg-muted/40 transition"
                    >
                      <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center overflow-hidden shrink-0">
                        {p.avatar_url ? (
                          <img loading="lazy" src={p.avatar_url} className="h-full w-full object-cover" />
                        ) : (
                          <User className="h-5 w-5 text-orange-600" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm truncate">
                          {p.business_name || p.display_name || p.email?.split("@")[0]}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">{p.email}</p>
                      </div>
                      <Badge variant="outline" className="text-[10px] bg-orange-500/10 text-orange-600 border-orange-500/30">
                        Direct Chat
                      </Badge>
                      <a
                        href={`/user/${p.user_id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-2 rounded-lg bg-secondary hover:bg-orange-500/20 text-foreground hover:text-orange-600 transition"
                        title="View Store / Profile"
                      >
                        <Store className="h-4 w-4" />
                      </a>
                    </button>
                  ))
                )}
              </CardContent>
            </Card>
          )}

          {/* Unified Conversations List */}
          <Card className="rounded-xl overflow-hidden shadow-xs">
            <CardContent className="p-0 divide-y">
              {shownThreads.length === 0 ? (
                <div className="p-8 text-center space-y-2">
                  <div className="h-10 w-10 rounded-full bg-orange-500/10 text-orange-600 flex items-center justify-center mx-auto">
                    <Globe className="h-5 w-5" />
                  </div>
                  <p className="text-sm font-semibold text-foreground">
                    No Global Network conversations yet
                  </p>
                  <p className="text-xs text-muted-foreground max-w-sm mx-auto">
                    Search any member above to initiate a direct message, WebRTC audio/video call, or send peer-to-peer ephemeral images.
                  </p>
                </div>
              ) : (
                shownThreads.map((t) => (
                  <div
                    key={`${t.otherId}:${t.taskId || ""}`}
                    className="w-full flex items-center gap-3 p-3.5 hover:bg-muted/40 transition group cursor-pointer"
                    onClick={() => openThread(t.otherId, t.taskId)}
                  >
                    <div className="h-11 w-11 rounded-full bg-orange-100 flex items-center justify-center overflow-hidden shrink-0">
                      {t.avatarUrl ? (
                        <img loading="lazy" src={t.avatarUrl} className="h-full w-full object-cover" />
                      ) : (
                        <User className="h-5 w-5 text-orange-600" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-semibold text-sm truncate group-hover:text-orange-600 transition-colors">
                          {t.displayName}
                        </p>
                        <span className="text-[10px] text-muted-foreground shrink-0">
                          {new Date(t.lastAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {t.lastMessageSenderId === me && (
                          <MessageStatusIndicator
                            status={t.lastMessageIsRead ? "seen" : "sent"}
                            showTimestamp={false}
                            size="xs"
                            className="shrink-0"
                          />
                        )}
                        <p className="text-xs text-muted-foreground truncate">{t.lastMessage}</p>
                      </div>
                    </div>
                    {t.unread > 0 && (
                      <Badge className="bg-red-500 text-white text-[10px] rounded-full px-1.5 py-0.5">
                        {t.unread}
                      </Badge>
                    )}
                    <a
                      href={`/user/${t.otherId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="h-8 px-2.5 rounded-lg bg-orange-500/10 hover:bg-orange-500/20 text-orange-600 font-bold text-xs flex items-center gap-1 shrink-0 transition"
                      title="Open Business Website & Public Storefront"
                    >
                      <Store className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Store</span>
                    </a>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default GGDInbox;