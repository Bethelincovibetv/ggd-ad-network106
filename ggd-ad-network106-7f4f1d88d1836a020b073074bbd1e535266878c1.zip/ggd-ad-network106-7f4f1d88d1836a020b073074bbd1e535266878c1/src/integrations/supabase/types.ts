export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ad_events: {
        Row: {
          ad_id: string
          created_at: string
          event_type: string
          id: string
          viewer_id: string | null
        }
        Insert: {
          ad_id: string
          created_at?: string
          event_type: string
          id?: string
          viewer_id?: string | null
        }
        Update: {
          ad_id?: string
          created_at?: string
          event_type?: string
          id?: string
          viewer_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ad_events_ad_id_fkey"
            columns: ["ad_id"]
            isOneToOne: false
            referencedRelation: "ads"
            referencedColumns: ["id"]
          },
        ]
      }
      ad_watch_claims: {
        Row: {
          ad_id: string
          claimed_at: string
          id: string
          user_id: string
        }
        Insert: {
          ad_id: string
          claimed_at?: string
          id?: string
          user_id: string
        }
        Update: {
          ad_id?: string
          claimed_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      admin_chat_messages: {
        Row: {
          created_at: string
          id: string
          is_read: boolean | null
          message: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          message: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          message?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      ads: {
        Row: {
          ad_type: string
          approved: boolean
          budget_credits: number | null
          clicks: number | null
          created_at: string
          description: string | null
          expires_at: string | null
          id: string
          image_url: string | null
          impressions: number | null
          is_active: boolean | null
          rejection_reason: string | null
          reward_credits: number | null
          target_state: string | null
          target_url: string
          title: string
          user_id: string
          watch_duration_seconds: number | null
          youtube_url: string | null
        }
        Insert: {
          ad_type?: string
          approved?: boolean
          budget_credits?: number | null
          clicks?: number | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          image_url?: string | null
          impressions?: number | null
          is_active?: boolean | null
          rejection_reason?: string | null
          reward_credits?: number | null
          target_state?: string | null
          target_url: string
          title: string
          user_id: string
          watch_duration_seconds?: number | null
          youtube_url?: string | null
        }
        Update: {
          ad_type?: string
          approved?: boolean
          budget_credits?: number | null
          clicks?: number | null
          created_at?: string
          description?: string | null
          expires_at?: string | null
          id?: string
          image_url?: string | null
          impressions?: number | null
          is_active?: boolean | null
          rejection_reason?: string | null
          reward_credits?: number | null
          target_state?: string | null
          target_url?: string
          title?: string
          user_id?: string
          watch_duration_seconds?: number | null
          youtube_url?: string | null
        }
        Relationships: []
      }
      ai_copilot_messages: {
        Row: {
          content: Json
          created_at: string
          id: string
          role: string
          session_id: string
          user_id: string
        }
        Insert: {
          content: Json
          created_at?: string
          id?: string
          role: string
          session_id: string
          user_id: string
        }
        Update: {
          content?: Json
          created_at?: string
          id?: string
          role?: string
          session_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_copilot_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "ai_copilot_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_copilot_sessions: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      api_keys: {
        Row: {
          api_key: string
          created_at: string
          domain: string | null
          id: string
          is_active: boolean | null
          name: string
          requests_count: number | null
          user_id: string
        }
        Insert: {
          api_key?: string
          created_at?: string
          domain?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          requests_count?: number | null
          user_id: string
        }
        Update: {
          api_key?: string
          created_at?: string
          domain?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          requests_count?: number | null
          user_id?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          created_at: string
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          created_at?: string
          id?: string
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          created_at?: string
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      business_addons: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          is_free: boolean
          name: string
          price: number
          sort_order: number | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_free?: boolean
          name: string
          price?: number
          sort_order?: number | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          is_free?: boolean
          name?: string
          price?: number
          sort_order?: number | null
        }
        Relationships: []
      }
      business_categories: {
        Row: {
          banner_url: string | null
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          slug: string | null
          sort_order: number | null
        }
        Insert: {
          banner_url?: string | null
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          slug?: string | null
          sort_order?: number | null
        }
        Update: {
          banner_url?: string | null
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          slug?: string | null
          sort_order?: number | null
        }
        Relationships: []
      }
      business_listings: {
        Row: {
          business_profile_id: string
          created_at: string
          description: string | null
          extra_images: Json | null
          featured_until: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          is_featured: boolean | null
          listing_type: string | null
          long_description: string | null
          price: number | null
          title: string
          user_id: string
          video_url: string | null
        }
        Insert: {
          business_profile_id: string
          created_at?: string
          description?: string | null
          extra_images?: Json | null
          featured_until?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_featured?: boolean | null
          listing_type?: string | null
          long_description?: string | null
          price?: number | null
          title: string
          user_id: string
          video_url?: string | null
        }
        Update: {
          business_profile_id?: string
          created_at?: string
          description?: string | null
          extra_images?: Json | null
          featured_until?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_featured?: boolean | null
          listing_type?: string | null
          long_description?: string | null
          price?: number | null
          title?: string
          user_id?: string
          video_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "business_listings_business_profile_id_fkey"
            columns: ["business_profile_id"]
            isOneToOne: false
            referencedRelation: "business_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      business_profiles: {
        Row: {
          address: string | null
          business_name: string
          category_id: string | null
          created_at: string
          description: string | null
          directory_subscription_expires_at: string | null
          facebook_url: string | null
          hero_image_url: string | null
          id: string
          instagram_url: string | null
          is_directory_listed: boolean | null
          is_verified: boolean
          logo_url: string | null
          paystack_enabled: boolean | null
          paystack_public_key: string | null
          phone_number: string | null
          telegram_url: string | null
          tiktok_url: string | null
          twitter_url: string | null
          user_id: string
          verification_document_type: string | null
          verification_status: string
          verified_at: string | null
          website_link: string | null
          whatsapp_group_link: string | null
          whatsapp_link: string | null
        }
        Insert: {
          address?: string | null
          business_name: string
          category_id?: string | null
          created_at?: string
          description?: string | null
          directory_subscription_expires_at?: string | null
          facebook_url?: string | null
          hero_image_url?: string | null
          id?: string
          instagram_url?: string | null
          is_directory_listed?: boolean | null
          is_verified?: boolean
          logo_url?: string | null
          paystack_enabled?: boolean | null
          paystack_public_key?: string | null
          phone_number?: string | null
          telegram_url?: string | null
          tiktok_url?: string | null
          twitter_url?: string | null
          user_id: string
          verification_document_type?: string | null
          verification_status?: string
          verified_at?: string | null
          website_link?: string | null
          whatsapp_group_link?: string | null
          whatsapp_link?: string | null
        }
        Update: {
          address?: string | null
          business_name?: string
          category_id?: string | null
          created_at?: string
          description?: string | null
          directory_subscription_expires_at?: string | null
          facebook_url?: string | null
          hero_image_url?: string | null
          id?: string
          instagram_url?: string | null
          is_directory_listed?: boolean | null
          is_verified?: boolean
          logo_url?: string | null
          paystack_enabled?: boolean | null
          paystack_public_key?: string | null
          phone_number?: string | null
          telegram_url?: string | null
          tiktok_url?: string | null
          twitter_url?: string | null
          user_id?: string
          verification_document_type?: string | null
          verification_status?: string
          verified_at?: string | null
          website_link?: string | null
          whatsapp_group_link?: string | null
          whatsapp_link?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "business_profiles_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "business_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      business_verifications: {
        Row: {
          account_type: string
          admin_action: string
          admin_email: string | null
          admin_id: string | null
          admin_note: string | null
          business_profile_id: string | null
          document_file_url: string | null
          document_number: string
          document_type: string
          evaluated_at: string
          extraction_details: Json
          id: string
          last_updated_at: string
          match_confidence: string
          metadata: Json
          registered_profile_name: string
          rejection_reason: string | null
          reviewed_at: string | null
          status: string
          submitted_at: string
          submitted_name: string
          user_email: string | null
          user_id: string
          verified_badge_granted: boolean
        }
        Insert: {
          account_type: string
          admin_action?: string
          admin_email?: string | null
          admin_id?: string | null
          admin_note?: string | null
          business_profile_id?: string | null
          document_file_url?: string | null
          document_number?: string
          document_type: string
          evaluated_at?: string
          extraction_details?: Json
          id?: string
          last_updated_at?: string
          match_confidence?: string
          metadata?: Json
          registered_profile_name: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string
          submitted_name: string
          user_email?: string | null
          user_id: string
          verified_badge_granted?: boolean
        }
        Update: {
          account_type?: string
          admin_action?: string
          admin_email?: string | null
          admin_id?: string | null
          admin_note?: string | null
          business_profile_id?: string | null
          document_file_url?: string | null
          document_number?: string
          document_type?: string
          evaluated_at?: string
          extraction_details?: Json
          id?: string
          last_updated_at?: string
          match_confidence?: string
          metadata?: Json
          registered_profile_name?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string
          submitted_name?: string
          user_email?: string | null
          user_id?: string
          verified_badge_granted?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "business_verifications_business_profile_id_fkey"
            columns: ["business_profile_id"]
            isOneToOne: false
            referencedRelation: "business_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      co_owner_applications: {
        Row: {
          account_name: string
          account_number: string
          admin_notes: string | null
          bank_name: string
          created_at: string
          earning_percentage: number | null
          id: string
          reviewed_at: string | null
          status: string
          total_earnings: number | null
          user_id: string
        }
        Insert: {
          account_name: string
          account_number: string
          admin_notes?: string | null
          bank_name: string
          created_at?: string
          earning_percentage?: number | null
          id?: string
          reviewed_at?: string | null
          status?: string
          total_earnings?: number | null
          user_id: string
        }
        Update: {
          account_name?: string
          account_number?: string
          admin_notes?: string | null
          bank_name?: string
          created_at?: string
          earning_percentage?: number | null
          id?: string
          reviewed_at?: string | null
          status?: string
          total_earnings?: number | null
          user_id?: string
        }
        Relationships: []
      }
      community_posts: {
        Row: {
          background_template: string | null
          content: string | null
          created_at: string
          id: string
          image_url: string | null
          link_url: string | null
          tags: string[]
          updated_at: string
          user_id: string
          video_url: string | null
        }
        Insert: {
          background_template?: string | null
          content?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          link_url?: string | null
          tags?: string[]
          updated_at?: string
          user_id: string
          video_url?: string | null
        }
        Update: {
          background_template?: string | null
          content?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          link_url?: string | null
          tags?: string[]
          updated_at?: string
          user_id?: string
          video_url?: string | null
        }
        Relationships: []
      }
      credit_transfers: {
        Row: {
          amount: number
          created_at: string
          id: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      email_activity_types: {
        Row: {
          activity_key: string
          category: string
          created_at: string
          default_opt_in: boolean
          description: string | null
          id: string
          is_enabled: boolean
          label: string
          updated_at: string
        }
        Insert: {
          activity_key: string
          category?: string
          created_at?: string
          default_opt_in?: boolean
          description?: string | null
          id?: string
          is_enabled?: boolean
          label: string
          updated_at?: string
        }
        Update: {
          activity_key?: string
          category?: string
          created_at?: string
          default_opt_in?: boolean
          description?: string | null
          id?: string
          is_enabled?: boolean
          label?: string
          updated_at?: string
        }
        Relationships: []
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          recipient_user_id: string | null
          sender_user_id: string | null
          source: string
          source_ref: string | null
          status: string
          subject: string | null
          template_name: string | null
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          recipient_user_id?: string | null
          sender_user_id?: string | null
          source: string
          source_ref?: string | null
          status?: string
          subject?: string | null
          template_name?: string | null
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          recipient_user_id?: string | null
          sender_user_id?: string | null
          source?: string
          source_ref?: string | null
          status?: string
          subject?: string | null
          template_name?: string | null
        }
        Relationships: []
      }
      emoji_reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          target_id: string
          target_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          target_id: string
          target_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          target_id?: string
          target_type?: string
          user_id?: string
        }
        Relationships: []
      }
      feature_toggles: {
        Row: {
          created_at: string
          description: string | null
          feature_key: string
          feature_name: string
          id: string
          is_enabled: boolean | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          feature_key: string
          feature_name: string
          id?: string
          is_enabled?: boolean | null
        }
        Update: {
          created_at?: string
          description?: string | null
          feature_key?: string
          feature_name?: string
          id?: string
          is_enabled?: boolean | null
        }
        Relationships: []
      }
      link_clicks: {
        Row: {
          country: string | null
          created_at: string
          device: string | null
          id: string
          referrer: string | null
          short_link_id: string
          user_agent: string | null
        }
        Insert: {
          country?: string | null
          created_at?: string
          device?: string | null
          id?: string
          referrer?: string | null
          short_link_id: string
          user_agent?: string | null
        }
        Update: {
          country?: string | null
          created_at?: string
          device?: string | null
          id?: string
          referrer?: string | null
          short_link_id?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "link_clicks_short_link_id_fkey"
            columns: ["short_link_id"]
            isOneToOne: false
            referencedRelation: "short_links"
            referencedColumns: ["id"]
          },
        ]
      }
      marketing_apps: {
        Row: {
          app_link: string
          created_at: string
          credit_cost: number | null
          description: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          is_free: boolean | null
          sort_order: number | null
          title: string
        }
        Insert: {
          app_link: string
          created_at?: string
          credit_cost?: number | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_free?: boolean | null
          sort_order?: number | null
          title: string
        }
        Update: {
          app_link?: string
          created_at?: string
          credit_cost?: number | null
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          is_free?: boolean | null
          sort_order?: number | null
          title?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          is_read: boolean | null
          link_url: string | null
          message: string | null
          nav_target: string | null
          title: string
          type: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          link_url?: string | null
          message?: string | null
          nav_target?: string | null
          title: string
          type?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          link_url?: string | null
          message?: string | null
          nav_target?: string | null
          title?: string
          type?: string | null
          user_id?: string
        }
        Relationships: []
      }
      p2p_messages: {
        Row: {
          action_payload: Json | null
          action_type: string | null
          assignment_id: string | null
          created_at: string
          id: string
          image_url: string | null
          is_read: boolean
          kind: string
          message: string | null
          receiver_id: string
          sender_id: string
          task_id: string | null
        }
        Insert: {
          action_payload?: Json | null
          action_type?: string | null
          assignment_id?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          is_read?: boolean
          kind?: string
          message?: string | null
          receiver_id: string
          sender_id: string
          task_id?: string | null
        }
        Update: {
          action_payload?: Json | null
          action_type?: string | null
          assignment_id?: string | null
          created_at?: string
          id?: string
          image_url?: string | null
          is_read?: boolean
          kind?: string
          message?: string | null
          receiver_id?: string
          sender_id?: string
          task_id?: string | null
        }
        Relationships: []
      }
      platform_pricing: {
        Row: {
          created_at: string | null
          icon_url: string | null
          id: string
          is_active: boolean | null
          platform_key: string
          platform_name: string
          price_per_task: number
        }
        Insert: {
          created_at?: string | null
          icon_url?: string | null
          id?: string
          is_active?: boolean | null
          platform_key: string
          platform_name: string
          price_per_task?: number
        }
        Update: {
          created_at?: string | null
          icon_url?: string | null
          id?: string
          is_active?: boolean | null
          platform_key?: string
          platform_name?: string
          price_per_task?: number
        }
        Relationships: []
      }
      post_comments: {
        Row: {
          content: string
          created_at: string
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      post_reactions: {
        Row: {
          created_at: string
          id: string
          post_id: string
          reaction: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id: string
          reaction: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string
          reaction?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_reactions_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          business_category: string | null
          business_description: string | null
          business_location: string | null
          business_logo_url: string | null
          business_name: string | null
          business_phone: string | null
          business_slug: string | null
          business_website: string | null
          created_at: string
          credits: number
          display_name: string | null
          email: string | null
          id: string
          industry: string | null
          is_banned: boolean | null
          is_verified: boolean
          last_credit_date: string | null
          login_bonus_credits: number
          profile_setup_complete: boolean
          referral_code: string | null
          referred_by: string | null
          referred_by_user_id: string | null
          state: string | null
          user_id: string
          verification_document_type: string | null
          verification_status: string
          verified_at: string | null
          whatsapp_number: string | null
        }
        Insert: {
          avatar_url?: string | null
          business_category?: string | null
          business_description?: string | null
          business_location?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          business_phone?: string | null
          business_slug?: string | null
          business_website?: string | null
          created_at?: string
          credits?: number
          display_name?: string | null
          email?: string | null
          id?: string
          industry?: string | null
          is_banned?: boolean | null
          is_verified?: boolean
          last_credit_date?: string | null
          login_bonus_credits?: number
          profile_setup_complete?: boolean
          referral_code?: string | null
          referred_by?: string | null
          referred_by_user_id?: string | null
          state?: string | null
          user_id: string
          verification_document_type?: string | null
          verification_status?: string
          verified_at?: string | null
          whatsapp_number?: string | null
        }
        Update: {
          avatar_url?: string | null
          business_category?: string | null
          business_description?: string | null
          business_location?: string | null
          business_logo_url?: string | null
          business_name?: string | null
          business_phone?: string | null
          business_slug?: string | null
          business_website?: string | null
          created_at?: string
          credits?: number
          display_name?: string | null
          email?: string | null
          id?: string
          industry?: string | null
          is_banned?: boolean | null
          is_verified?: boolean
          last_credit_date?: string | null
          login_bonus_credits?: number
          profile_setup_complete?: boolean
          referral_code?: string | null
          referred_by?: string | null
          referred_by_user_id?: string | null
          state?: string | null
          user_id?: string
          verification_document_type?: string | null
          verification_status?: string
          verified_at?: string | null
          whatsapp_number?: string | null
        }
        Relationships: []
      }
      promoter_applications: {
        Row: {
          admin_notes: string | null
          audience_category: string | null
          created_at: string
          estimated_audience: number
          experience: string | null
          id: string
          promoter_name: string
          reviewed_at: string | null
          status: string
          target_state: string | null
          user_id: string
          whatsapp_channels: string[]
        }
        Insert: {
          admin_notes?: string | null
          audience_category?: string | null
          created_at?: string
          estimated_audience?: number
          experience?: string | null
          id?: string
          promoter_name: string
          reviewed_at?: string | null
          status?: string
          target_state?: string | null
          user_id: string
          whatsapp_channels?: string[]
        }
        Update: {
          admin_notes?: string | null
          audience_category?: string | null
          created_at?: string
          estimated_audience?: number
          experience?: string | null
          id?: string
          promoter_name?: string
          reviewed_at?: string | null
          status?: string
          target_state?: string | null
          user_id?: string
          whatsapp_channels?: string[]
        }
        Relationships: []
      }
      promoter_profiles: {
        Row: {
          account_name: string | null
          account_number: string | null
          audience_category: string | null
          bank_code: string | null
          bank_name: string | null
          created_at: string
          estimated_audience: number
          experience: string | null
          id: string
          is_suspended: boolean
          is_verified: boolean
          promoter_name: string | null
          suspended_reason: string | null
          target_state: string | null
          updated_at: string
          user_id: string
          wallet_frozen: boolean
          whatsapp_channels: string[]
          withdraw_pin_hash: string | null
        }
        Insert: {
          account_name?: string | null
          account_number?: string | null
          audience_category?: string | null
          bank_code?: string | null
          bank_name?: string | null
          created_at?: string
          estimated_audience?: number
          experience?: string | null
          id?: string
          is_suspended?: boolean
          is_verified?: boolean
          promoter_name?: string | null
          suspended_reason?: string | null
          target_state?: string | null
          updated_at?: string
          user_id: string
          wallet_frozen?: boolean
          whatsapp_channels?: string[]
          withdraw_pin_hash?: string | null
        }
        Update: {
          account_name?: string | null
          account_number?: string | null
          audience_category?: string | null
          bank_code?: string | null
          bank_name?: string | null
          created_at?: string
          estimated_audience?: number
          experience?: string | null
          id?: string
          is_suspended?: boolean
          is_verified?: boolean
          promoter_name?: string | null
          suspended_reason?: string | null
          target_state?: string | null
          updated_at?: string
          user_id?: string
          wallet_frozen?: boolean
          whatsapp_channels?: string[]
          withdraw_pin_hash?: string | null
        }
        Relationships: []
      }
      promotional_materials: {
        Row: {
          created_at: string
          description: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          target_audience: string | null
          title: string
          type: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          target_audience?: string | null
          title: string
          type?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          target_audience?: string | null
          title?: string
          type?: string | null
        }
        Relationships: []
      }
      promotional_videos: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean | null
          section: string
          sort_order: number | null
          title: string
          youtube_url: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          section?: string
          sort_order?: number | null
          title: string
          youtube_url: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          section?: string
          sort_order?: number | null
          title?: string
          youtube_url?: string
        }
        Relationships: []
      }
      referral_earnings: {
        Row: {
          created_at: string
          credits_earned: number
          id: string
          referred_user_id: string
          referrer_id: string
          source: string
          source_amount: number
        }
        Insert: {
          created_at?: string
          credits_earned?: number
          id?: string
          referred_user_id: string
          referrer_id: string
          source?: string
          source_amount?: number
        }
        Update: {
          created_at?: string
          credits_earned?: number
          id?: string
          referred_user_id?: string
          referrer_id?: string
          source?: string
          source_amount?: number
        }
        Relationships: []
      }
      referral_messages: {
        Row: {
          created_at: string
          id: string
          is_read: boolean | null
          message: string
          receiver_id: string
          sender_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          message: string
          receiver_id: string
          sender_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_read?: boolean | null
          message?: string
          receiver_id?: string
          sender_id?: string
        }
        Relationships: []
      }
      short_links: {
        Row: {
          clicks: number
          created_at: string
          id: string
          is_active: boolean
          link_type: string
          slug: string
          target_url: string
          title: string | null
          user_id: string
        }
        Insert: {
          clicks?: number
          created_at?: string
          id?: string
          is_active?: boolean
          link_type?: string
          slug: string
          target_url: string
          title?: string | null
          user_id: string
        }
        Update: {
          clicks?: number
          created_at?: string
          id?: string
          is_active?: boolean
          link_type?: string
          slug?: string
          target_url?: string
          title?: string | null
          user_id?: string
        }
        Relationships: []
      }
      slides: {
        Row: {
          created_at: string
          id: string
          image_url: string
          is_active: boolean | null
          link_url: string | null
          sort_order: number | null
          title: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          image_url: string
          is_active?: boolean | null
          link_url?: string | null
          sort_order?: number | null
          title?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          image_url?: string
          is_active?: boolean | null
          link_url?: string | null
          sort_order?: number | null
          title?: string | null
        }
        Relationships: []
      }
      syndicate_applications: {
        Row: {
          admin_notes: string | null
          created_at: string
          facebook_influence: string | null
          id: string
          other_platforms: string | null
          reviewed_at: string | null
          state: string | null
          status: string | null
          telegram_influence: string | null
          tiktok_influence: string | null
          twitter_influence: string | null
          user_id: string
          whatsapp_influence: string | null
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string
          facebook_influence?: string | null
          id?: string
          other_platforms?: string | null
          reviewed_at?: string | null
          state?: string | null
          status?: string | null
          telegram_influence?: string | null
          tiktok_influence?: string | null
          twitter_influence?: string | null
          user_id: string
          whatsapp_influence?: string | null
        }
        Update: {
          admin_notes?: string | null
          created_at?: string
          facebook_influence?: string | null
          id?: string
          other_platforms?: string | null
          reviewed_at?: string | null
          state?: string | null
          status?: string | null
          telegram_influence?: string | null
          tiktok_influence?: string | null
          twitter_influence?: string | null
          user_id?: string
          whatsapp_influence?: string | null
        }
        Relationships: []
      }
      syndicate_bank_change_requests: {
        Row: {
          admin_notes: string | null
          bank_code: string | null
          created_at: string
          current_account_name: string | null
          current_account_number: string | null
          current_bank_name: string | null
          id: string
          reason: string | null
          recipient_code: string | null
          requested_account_name: string
          requested_account_number: string
          requested_bank_name: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          bank_code?: string | null
          created_at?: string
          current_account_name?: string | null
          current_account_number?: string | null
          current_bank_name?: string | null
          id?: string
          reason?: string | null
          recipient_code?: string | null
          requested_account_name: string
          requested_account_number: string
          requested_bank_name: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          bank_code?: string | null
          created_at?: string
          current_account_name?: string | null
          current_account_number?: string | null
          current_bank_name?: string | null
          id?: string
          reason?: string | null
          recipient_code?: string | null
          requested_account_name?: string
          requested_account_number?: string
          requested_bank_name?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      syndicate_profiles: {
        Row: {
          account_name: string | null
          account_number: string | null
          approved_count: number
          avatar_url: string | null
          bank_changed_at: string | null
          bank_name: string | null
          bank_pin_hash: string | null
          created_at: string
          failed_streak: number
          id: string
          is_bank_locked: boolean
          is_suspended: boolean
          paystack_recipient_code: string | null
          ranking_score: number | null
          rejected_count: number
          state: string | null
          suspended_reason: string | null
          tasks_completed: number | null
          user_id: string
          verified_platforms: string[] | null
          wallet_frozen: boolean
          withdraw_pin_hash: string | null
        }
        Insert: {
          account_name?: string | null
          account_number?: string | null
          approved_count?: number
          avatar_url?: string | null
          bank_changed_at?: string | null
          bank_name?: string | null
          bank_pin_hash?: string | null
          created_at?: string
          failed_streak?: number
          id?: string
          is_bank_locked?: boolean
          is_suspended?: boolean
          paystack_recipient_code?: string | null
          ranking_score?: number | null
          rejected_count?: number
          state?: string | null
          suspended_reason?: string | null
          tasks_completed?: number | null
          user_id: string
          verified_platforms?: string[] | null
          wallet_frozen?: boolean
          withdraw_pin_hash?: string | null
        }
        Update: {
          account_name?: string | null
          account_number?: string | null
          approved_count?: number
          avatar_url?: string | null
          bank_changed_at?: string | null
          bank_name?: string | null
          bank_pin_hash?: string | null
          created_at?: string
          failed_streak?: number
          id?: string
          is_bank_locked?: boolean
          is_suspended?: boolean
          paystack_recipient_code?: string | null
          ranking_score?: number | null
          rejected_count?: number
          state?: string | null
          suspended_reason?: string | null
          tasks_completed?: number | null
          user_id?: string
          verified_platforms?: string[] | null
          wallet_frozen?: boolean
          withdraw_pin_hash?: string | null
        }
        Relationships: []
      }
      syndicate_task_assignments: {
        Row: {
          accepted_at: string
          created_at: string
          id: string
          paid_at: string | null
          paid_by: string | null
          payment_note: string | null
          payout_amount: number | null
          proof_hash: string | null
          proof_link: string | null
          proof_url: string | null
          reassigned_by_admin: boolean
          rejection_reason: string | null
          reviewed_at: string | null
          status: string | null
          submitted_at: string | null
          syndicate_user_id: string
          task_id: string
        }
        Insert: {
          accepted_at?: string
          created_at?: string
          id?: string
          paid_at?: string | null
          paid_by?: string | null
          payment_note?: string | null
          payout_amount?: number | null
          proof_hash?: string | null
          proof_link?: string | null
          proof_url?: string | null
          reassigned_by_admin?: boolean
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string | null
          submitted_at?: string | null
          syndicate_user_id: string
          task_id: string
        }
        Update: {
          accepted_at?: string
          created_at?: string
          id?: string
          paid_at?: string | null
          paid_by?: string | null
          payment_note?: string | null
          payout_amount?: number | null
          proof_hash?: string | null
          proof_link?: string | null
          proof_url?: string | null
          reassigned_by_admin?: boolean
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string | null
          submitted_at?: string | null
          syndicate_user_id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "syndicate_task_assignments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "syndicate_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      syndicate_tasks: {
        Row: {
          approval_mode: string
          business_user_id: string
          campaign_date: string
          cost_per_syndicate: number | null
          created_at: string
          description: string | null
          flyer_url: string | null
          id: string
          locations: string | null
          max_syndicates: number | null
          payout_amount: number | null
          placements: string[] | null
          share_link: string | null
          status: string | null
          target_state: string | null
          title: string
          total_cost: number | null
        }
        Insert: {
          approval_mode?: string
          business_user_id: string
          campaign_date?: string
          cost_per_syndicate?: number | null
          created_at?: string
          description?: string | null
          flyer_url?: string | null
          id?: string
          locations?: string | null
          max_syndicates?: number | null
          payout_amount?: number | null
          placements?: string[] | null
          share_link?: string | null
          status?: string | null
          target_state?: string | null
          title: string
          total_cost?: number | null
        }
        Update: {
          approval_mode?: string
          business_user_id?: string
          campaign_date?: string
          cost_per_syndicate?: number | null
          created_at?: string
          description?: string | null
          flyer_url?: string | null
          id?: string
          locations?: string | null
          max_syndicates?: number | null
          payout_amount?: number | null
          placements?: string[] | null
          share_link?: string | null
          status?: string | null
          target_state?: string | null
          title?: string
          total_cost?: number | null
        }
        Relationships: []
      }
      task_completions: {
        Row: {
          created_at: string
          id: string
          task_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          task_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          task_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_completions_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      task_share_clicks: {
        Row: {
          country: string | null
          created_at: string
          id: string
          referrer: string | null
          share_link_id: string
          user_agent: string | null
        }
        Insert: {
          country?: string | null
          created_at?: string
          id?: string
          referrer?: string | null
          share_link_id: string
          user_agent?: string | null
        }
        Update: {
          country?: string | null
          created_at?: string
          id?: string
          referrer?: string | null
          share_link_id?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "task_share_clicks_share_link_id_fkey"
            columns: ["share_link_id"]
            isOneToOne: false
            referencedRelation: "task_share_links"
            referencedColumns: ["id"]
          },
        ]
      }
      task_share_links: {
        Row: {
          clicks: number
          created_at: string
          id: string
          sharer_user_id: string
          slug: string
          task_id: string
        }
        Insert: {
          clicks?: number
          created_at?: string
          id?: string
          sharer_user_id: string
          slug?: string
          task_id: string
        }
        Update: {
          clicks?: number
          created_at?: string
          id?: string
          sharer_user_id?: string
          slug?: string
          task_id?: string
        }
        Relationships: []
      }
      task_wallets: {
        Row: {
          balance: number | null
          created_at: string
          id: string
          total_earned: number | null
          total_funded: number | null
          total_spent: number | null
          user_id: string
        }
        Insert: {
          balance?: number | null
          created_at?: string
          id?: string
          total_earned?: number | null
          total_funded?: number | null
          total_spent?: number | null
          user_id: string
        }
        Update: {
          balance?: number | null
          created_at?: string
          id?: string
          total_earned?: number | null
          total_funded?: number | null
          total_spent?: number | null
          user_id?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          completions_count: number
          created_at: string
          creator_id: string | null
          description: string | null
          flyer_url: string | null
          funded: boolean
          id: string
          is_active: boolean | null
          max_completions: number
          reward_credits: number | null
          share_url: string | null
          task_type: string | null
          title: string
        }
        Insert: {
          completions_count?: number
          created_at?: string
          creator_id?: string | null
          description?: string | null
          flyer_url?: string | null
          funded?: boolean
          id?: string
          is_active?: boolean | null
          max_completions?: number
          reward_credits?: number | null
          share_url?: string | null
          task_type?: string | null
          title: string
        }
        Update: {
          completions_count?: number
          created_at?: string
          creator_id?: string | null
          description?: string | null
          flyer_url?: string | null
          funded?: boolean
          id?: string
          is_active?: boolean | null
          max_completions?: number
          reward_credits?: number | null
          share_url?: string | null
          task_type?: string | null
          title?: string
        }
        Relationships: []
      }
      user_addon_purchases: {
        Row: {
          addon_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          addon_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          addon_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_addon_purchases_addon_id_fkey"
            columns: ["addon_id"]
            isOneToOne: false
            referencedRelation: "business_addons"
            referencedColumns: ["id"]
          },
        ]
      }
      user_app_redemptions: {
        Row: {
          app_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          app_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          app_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_app_redemptions_app_id_fkey"
            columns: ["app_id"]
            isOneToOne: false
            referencedRelation: "marketing_apps"
            referencedColumns: ["id"]
          },
        ]
      }
      user_email_preferences: {
        Row: {
          activity_key: string
          created_at: string
          id: string
          marketing_opt_in: boolean
          opted_in: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          activity_key: string
          created_at?: string
          id?: string
          marketing_opt_in?: boolean
          opted_in?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          activity_key?: string
          created_at?: string
          id?: string
          marketing_opt_in?: boolean
          opted_in?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          premium_expires_at: string | null
          premium_tier: number | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          premium_expires_at?: string | null
          premium_tier?: number | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          premium_expires_at?: string | null
          premium_tier?: number | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      whatsapp_campaign_applications: {
        Row: {
          campaign_id: string
          created_at: string
          id: string
          promoter_user_id: string
          proof_notes: string | null
          proof_url: string | null
          rejection_reason: string | null
          reviewed_at: string | null
          status: string
          submitted_at: string | null
        }
        Insert: {
          campaign_id: string
          created_at?: string
          id?: string
          promoter_user_id: string
          proof_notes?: string | null
          proof_url?: string | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string | null
        }
        Update: {
          campaign_id?: string
          created_at?: string
          id?: string
          promoter_user_id?: string
          proof_notes?: string | null
          proof_url?: string | null
          rejection_reason?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_campaign_applications_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_campaigns: {
        Row: {
          approved_at: string | null
          budget_credits: number
          business_user_id: string
          caption: string
          created_at: string
          creative_url: string | null
          destination_url: string
          duration_days: number
          ends_at: string | null
          id: string
          platform_fee_credits: number
          promoters_required: number
          promotion_method: string
          rejection_reason: string | null
          remaining_budget_credits: number
          requirements: string | null
          requires_approval: boolean
          reward_credits: number
          starts_at: string | null
          status: string
          target_state: string | null
          title: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          approved_at?: string | null
          budget_credits: number
          business_user_id: string
          caption: string
          created_at?: string
          creative_url?: string | null
          destination_url: string
          duration_days?: number
          ends_at?: string | null
          id?: string
          platform_fee_credits?: number
          promoters_required?: number
          promotion_method?: string
          rejection_reason?: string | null
          remaining_budget_credits: number
          requirements?: string | null
          requires_approval?: boolean
          reward_credits: number
          starts_at?: string | null
          status?: string
          target_state?: string | null
          title: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          approved_at?: string | null
          budget_credits?: number
          business_user_id?: string
          caption?: string
          created_at?: string
          creative_url?: string | null
          destination_url?: string
          duration_days?: number
          ends_at?: string | null
          id?: string
          platform_fee_credits?: number
          promoters_required?: number
          promotion_method?: string
          rejection_reason?: string | null
          remaining_budget_credits?: number
          requirements?: string | null
          requires_approval?: boolean
          reward_credits?: number
          starts_at?: string | null
          status?: string
          target_state?: string | null
          title?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      whatsapp_earnings: {
        Row: {
          amount_credits: number
          application_id: string
          approved_at: string | null
          campaign_id: string
          created_at: string
          id: string
          paid_at: string | null
          promoter_user_id: string
          review_note: string | null
          status: string
        }
        Insert: {
          amount_credits: number
          application_id: string
          approved_at?: string | null
          campaign_id: string
          created_at?: string
          id?: string
          paid_at?: string | null
          promoter_user_id: string
          review_note?: string | null
          status?: string
        }
        Update: {
          amount_credits?: number
          application_id?: string
          approved_at?: string | null
          campaign_id?: string
          created_at?: string
          id?: string
          paid_at?: string | null
          promoter_user_id?: string
          review_note?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_earnings_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: true
            referencedRelation: "whatsapp_campaign_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_earnings_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_tracking_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          metadata: Json
          referrer: string | null
          tracking_link_id: string
          user_agent: string | null
          visitor_id: string | null
        }
        Insert: {
          created_at?: string
          event_type?: string
          id?: string
          metadata?: Json
          referrer?: string | null
          tracking_link_id: string
          user_agent?: string | null
          visitor_id?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          metadata?: Json
          referrer?: string | null
          tracking_link_id?: string
          user_agent?: string | null
          visitor_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_tracking_events_tracking_link_id_fkey"
            columns: ["tracking_link_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_tracking_links"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_tracking_links: {
        Row: {
          application_id: string
          campaign_id: string
          clicks: number
          conversions: number
          created_at: string
          id: string
          promoter_user_id: string
          slug: string
        }
        Insert: {
          application_id: string
          campaign_id: string
          clicks?: number
          conversions?: number
          created_at?: string
          id?: string
          promoter_user_id: string
          slug: string
        }
        Update: {
          application_id?: string
          campaign_id?: string
          clicks?: number
          conversions?: number
          created_at?: string
          id?: string
          promoter_user_id?: string
          slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_tracking_links_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: true
            referencedRelation: "whatsapp_campaign_applications"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_tracking_links_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      withdrawal_requests: {
        Row: {
          account_name: string | null
          account_number: string | null
          admin_notes: string | null
          amount: number
          bank_name: string | null
          created_at: string
          id: string
          processed_at: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          account_name?: string | null
          account_number?: string | null
          admin_notes?: string | null
          amount: number
          bank_name?: string | null
          created_at?: string
          id?: string
          processed_at?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          account_name?: string | null
          account_number?: string | null
          admin_notes?: string | null
          amount?: number
          bank_name?: string | null
          created_at?: string
          id?: string
          processed_at?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_adjust_user_credits: {
        Args: { p_amount: number; p_reason?: string; p_target_id: string }
        Returns: Json
      }
      admin_fund_task_wallet: {
        Args: { p_amount: number; p_reason?: string; p_target_id: string }
        Returns: Json
      }
      admin_subscribe_user: {
        Args: { _tier: number; _user_id: string }
        Returns: undefined
      }
      apply_to_whatsapp_campaign: {
        Args: { p_campaign_id: string }
        Returns: Json
      }
      create_whatsapp_campaign: {
        Args: {
          p_budget_credits: number
          p_caption: string
          p_creative_url: string
          p_destination_url: string
          p_duration_days: number
          p_promoters_required: number
          p_promotion_method?: string
          p_requirements?: string
          p_requires_approval?: boolean
          p_reward_credits: number
          p_target_state?: string
          p_title: string
          p_video_url: string
        }
        Returns: Json
      }
      generate_business_slug: {
        Args: { _name: string; _user_id: string }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_feature_enabled: { Args: { _key: string }; Returns: boolean }
      record_whatsapp_click: {
        Args: { p_referrer?: string; p_slug: string; p_user_agent?: string }
        Returns: Json
      }
      request_whatsapp_promoter_withdrawal: {
        Args: {
          p_account_name: string
          p_account_number: string
          p_amount: number
          p_bank_code?: string
          p_bank_name: string
        }
        Returns: Json
      }
      review_whatsapp_application: {
        Args: {
          p_application_id: string
          p_approve: boolean
          p_reason?: string
        }
        Returns: Json
      }
      review_whatsapp_campaign: {
        Args: { p_approve: boolean; p_campaign_id: string; p_reason?: string }
        Returns: Json
      }
      review_whatsapp_promotion: {
        Args: {
          p_application_id: string
          p_approve: boolean
          p_reason?: string
        }
        Returns: Json
      }
      self_upgrade_premium: { Args: { _tier: number }; Returns: undefined }
      submit_whatsapp_promotion: {
        Args: {
          p_application_id: string
          p_notes?: string
          p_proof_url: string
        }
        Returns: Json
      }
      transfer_credits: {
        Args: { p_amount: number; p_recipient_email: string }
        Returns: Json
      }
      transfer_credits_to_user: {
        Args: { p_amount: number; p_recipient_user_id: string }
        Returns: Json
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "premium"
        | "business"
        | "syndicate"
        | "moderator"
        | "user"
        | "co_owner"
        | "promoter"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "premium",
        "business",
        "syndicate",
        "moderator",
        "user",
        "co_owner",
        "promoter",
      ],
    },
  },
} as const
