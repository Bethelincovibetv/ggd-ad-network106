import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import AdminChatWidget from "./components/AdminChatWidget";
import InstallPrompt from "./components/InstallPrompt";
import PushNotificationPrompt from "./components/PushNotificationPrompt";
import { CallProvider } from "@/contexts/CallContext";
import { IncomingCallBanner } from "@/components/call/IncomingCallBanner";
import { CallModal } from "@/components/call/CallModal";

const AdminPage = lazy(() => import("./components/AdminPage"));
const BusinessDetailPage = lazy(() => import("./pages/BusinessDetailPage"));
const UserProfilePublicPage = lazy(() => import("./pages/UserProfilePublicPage"));
const RedirectPage = lazy(() => import("./pages/RedirectPage"));
const SyndicateRegister = lazy(() => import("./pages/SyndicateRegister"));
const SharePreviewPage = lazy(() => import("./pages/SharePreviewPage"));
const ProductDetailPage = lazy(() => import("./pages/ProductDetailPage"));
const IndustryPage = lazy(() => import("./pages/IndustryPage"));
const NotificationsDedicatedPage = lazy(() => import("./pages/NotificationsDedicatedPage"));
const GuideDedicatedPage = lazy(() => import("./pages/GuideDedicatedPage"));
const VixoraCreatorPage = lazy(() => import("./pages/VixoraCreatorPage"));
const RedeemAirtimePage = lazy(() => import("./pages/RedeemAirtimePage"));
const NotFound = lazy(() => import("./pages/NotFound"));


const queryClient = new QueryClient();

const RouteFallback = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
  </div>
);

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <CallProvider>
            <Toaster />
            <Sonner />
            <Suspense fallback={<RouteFallback />}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/admin" element={<AdminPage />} />
              <Route path="/business/:id" element={<BusinessDetailPage />} />
              <Route path="/user/:id" element={<UserProfilePublicPage />} />
              <Route path="/b/:slug" element={<UserProfilePublicPage />} />
              <Route path="/r/:slug" element={<RedirectPage />} />
              <Route path="/s/:slug" element={<SharePreviewPage />} />
              <Route path="/product/:id" element={<ProductDetailPage />} />
              <Route path="/industry/:slug" element={<IndustryPage />} />
              <Route path="/syndicate-register" element={<SyndicateRegister />} />
              <Route path="/notifications" element={<NotificationsDedicatedPage />} />
              <Route path="/guide" element={<GuideDedicatedPage />} />
              <Route path="/vixora" element={<VixoraCreatorPage />} />
              <Route path="/vixora-creator" element={<VixoraCreatorPage />} />
              <Route path="/creator" element={<VixoraCreatorPage />} />
              <Route path="/studio" element={<VixoraCreatorPage />} />
              <Route path="/autopilot" element={<VixoraCreatorPage />} />
              <Route path="/voiceover" element={<VixoraCreatorPage />} />
              <Route path="/scripts" element={<VixoraCreatorPage />} />
              <Route path="/videos" element={<VixoraCreatorPage />} />
              <Route path="/bgmusic" element={<VixoraCreatorPage />} />
              <Route path="/tools" element={<VixoraCreatorPage />} />
              <Route path="/growth" element={<VixoraCreatorPage />} />
              <Route path="/contact" element={<VixoraCreatorPage />} />
              <Route path="/coach" element={<VixoraCreatorPage />} />
              <Route path="/developer" element={<VixoraCreatorPage />} />
              <Route path="/redeem" element={<RedeemAirtimePage />} />
              <Route path="/airtime" element={<RedeemAirtimePage />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}

              <Route path="*" element={<NotFound />} />
            </Routes>
            </Suspense>
            <AdminChatWidget />
            <InstallPrompt />
            <PushNotificationPrompt />
            <IncomingCallBanner />
            <CallModal />
          </CallProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
